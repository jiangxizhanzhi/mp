
rm -rf versionG.txt
echo "Git-Repo-Url: $(git remote get-url origin)" >> versionG.txt
echo "Git-Branch: $(git rev-parse --abbrev-ref HEAD)" >> versionG.txt
echo "Git-Commit-Id: $(git rev-parse HEAD)" >> versionG.txt
echo "Git-Commit-Message: $(git log -1 --pretty=%B)" >> versionG.txt
cd ..
zip -r traffic_generators.zip traffic_generators -x traffic_generators/.git/*
