# -*- coding: utf-8 -*-
import os
import sqlite3
import subprocess

import psutil


def reload():
    try:
        # 重启服务
        exec_cmd("supervisorctl restart all")
        print("restart trex server")

        # 重置数据库任务状态
        reset_db()

        # 杀掉trex相关进程
        kill_processes("trex_")
        print("kill trex threads")
    except Exception as e:
        print(f"reload trex error: {e}")


def reset_db():
    # 读取上层目录中的数据库文件
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/traffic.db'
    print(f'search db file {base_dir}')
    if not os.path.exists(base_dir):
        print("no db file exists")
        return

    database_uri = 'sqlite:///' + base_dir
    print(f'database uri is {database_uri}')
    # 连接数据库
    conn = sqlite3.connect(database_uri)

    # 创建游标对象
    cursor = conn.cursor()
    try:
        # 更新任务状态为停止
        update_logo_sql = "UPDATE task_port_manager SET status = 3;"
        cursor.execute(update_logo_sql)
        conn.commit()
        print("stop tasks")
    except Exception as e:
        print(f"reset task status error: {e}")
    finally:
        # 关闭游标和连接
        cursor.close()
        conn.close()


def kill_processes(thread_name):
    """
    杀掉包含thread_name的进程
    :param thread_name:
    :return:
    """
    for process in psutil.process_iter():
        try:
            # 获取进程的命令行参数
            cmdline = process.cmdline()

            # 检查命令行参数是否包含匹配的文本
            if any(thread_name in arg for arg in cmdline):
                process.terminate()  # 终止进程
        except Exception as e:
            pass


def exec_cmd(cmd, check_exit_code=True, return_stderr=False):
    """
    执行linux命令的方法
    :param cmd: 命令
    :param check_exit_code:
    :param return_stderr:
    :return:
    """
    obj = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    _stdout, _stderr = (obj.communicate())
    obj.stdin.close()
    msg = "cmd stdout:%s, cmd stderr:%s" % (_stdout, _stderr)
    if obj.returncode and check_exit_code:
        raise RuntimeError(msg)

    return return_stderr and (_stdout, _stderr) or _stdout


if __name__ == '__main__':
    reload()
