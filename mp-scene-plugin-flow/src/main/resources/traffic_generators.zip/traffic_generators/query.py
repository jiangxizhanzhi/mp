import sqlite3
conn = sqlite3.connect('traffic.db')
c = conn.cursor()
c.execute("update task_port_manager set status = 1")
c.execute("SELECT * FROM task_port_manager")
all_rows = c.fetchall()
for row in all_rows:
    print(row.params)
conn.close()
