from datetime import datetime

from app.ext import db
from app.ext import ma
from .common import DbManager


class TaskFlowRecords(db.Model, DbManager):
    """
    流量运行结果记录表  表名flow_records
    """
    __tablename__ = 'flow_records'
    id = db.Column(db.Integer, primary_key=True)  # 记录的uuid
    task_uuid = db.Column(db.String(64), nullable=False)  # 任务的uuid
    group_count = db.Column(db.Integer, nullable=False)  # 执行次数分组，相同表示同一次流量发生产生的数据
    second = db.Column(db.Integer, nullable=False)  # 秒数
    opackets = db.Column(db.Integer)  # 发包数量
    obytes = db.Column(db.Integer)  # 发包大小 单位byte
    tx_bps = db.Column(db.Float)  # 发包速率 单位byte/s
    oerrors = db.Column(db.Integer)  # 发包异常数量
    tx_pps = db.Column(db.Float)
    latency = db.Column(db.Integer)
    jitter = db.Column(db.Integer)
    total_tx_L2 = db.Column(db.Float)
    total_tx_L1 = db.Column(db.Float)
    total_rx = db.Column(db.Float)
    queue_full = db.Column(db.Integer)
    drop_rate = db.Column(db.Float)
    status = db.Column(db.Integer)  # 状态：0有效， 1失效
    record_time = db.Column(db.DateTime, nullable=False)  # 发包时间
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间


class TaskAttackFlowRecords(db.Model, DbManager):
    """
    攻击流量运行结果记录表  表名attack_flow_records
    """
    __tablename__ = 'attack_flow_records'
    id = db.Column(db.Integer, primary_key=True)  # 记录的uuid
    task_uuid = db.Column(db.String(64), nullable=False)  # 任务的uuid
    group_count = db.Column(db.Integer, nullable=False)  # 执行次数分组，相同表示同一次流量发生产生的数据
    second = db.Column(db.Integer, nullable=False)  # 秒数
    opackets = db.Column(db.Integer)  # 发包数量
    obytes = db.Column(db.Integer)  # 发包大小 单位byte
    tx_bps = db.Column(db.Float)  # 发包速率 单位byte/s
    oerrors = db.Column(db.Integer)  # 发包异常数量
    tx_pps = db.Column(db.Float)
    latency = db.Column(db.Integer)
    jitter = db.Column(db.Integer)
    total_tx_L2 = db.Column(db.Float)
    total_tx_L1 = db.Column(db.Float)
    total_rx = db.Column(db.Float)
    queue_full = db.Column(db.Integer)
    drop_rate = db.Column(db.Float)
    packets_sent = db.Column(db.Integer)  # 总发包数量
    bytes_sent = db.Column(db.Integer)  # 总发包大小 单位byte
    errout = db.Column(db.Integer)  # 总发包异常数量
    status = db.Column(db.Integer)  # 状态：0有效， 1失效
    record_time = db.Column(db.DateTime, nullable=False)  # 发包时间
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间


class TaskPortManagerModel(db.Model, DbManager):
    """
    流量任务网口关联表  表名task_port_manager
    """
    __tablename__ = 'task_port_manager'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.String(64), nullable=False)
    status = db.Column(db.Integer, default=0)
    port_name = db.Column(db.String(12))
    port_num = db.Column(db.Integer)
    mac = db.Column(db.String(64))
    msg = db.Column(db.String(1024), default="")
    target_ip = db.Column(db.String(64))
    params = db.Column(db.String(2048))
    create_time = db.Column(db.DateTime, default=datetime.now)
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)


class TaskPortManagerSchema(ma.ModelSchema):
    class Meta:
        model = TaskPortManagerModel


class TaskFlowRecordsSchema(ma.ModelSchema):
    class Meta:
        model = TaskFlowRecords


class TaskAttackFlowRecordsSchema(ma.ModelSchema):
    class Meta:
        model = TaskAttackFlowRecords
