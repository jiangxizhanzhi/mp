from sqlalchemy import func

from app.db.model import TaskPortManagerModel
from app.ext import db


class TaskPortManagerHandler(TaskPortManagerModel):
    """
    流量任务网口管理类
    """

    @classmethod
    def get_all_by_mac(cls, mac):
        """
        通过mac获取网口管理数据
        :param mac: mac
        :return:
        """
        return cls.query.filter(cls.mac == mac).order_by(-cls.create_time).all()

    @classmethod
    def get_max_port_num(cls):
        """
        查询最大端口号
        :return:
        """
        max_port_num = db.session.query(func.max(cls.port_num)).first()[0]
        return 0 if not max_port_num else max_port_num

    @classmethod
    def get_by_task_id(cls, task_id):
        """
        通过task_id获取网口管理数据
        :param task_id: task_id
        :return:
        """
        task_port = cls.query.filter(cls.task_id == task_id).order_by(-cls.create_time).first()
        cls.commit()
        return task_port

    @classmethod
    def get_by_task_ids(cls, task_ids):
        """
        通过task_ids获取网口管理数据
        :param task_ids: 任务id集合
        :return:
        """
        return cls.query.filter(cls.task_id.in_(task_ids)).order_by(-cls.create_time).all()

    @classmethod
    def get_running_tasks(cls):
        """
        获取运行中的任务
        :return:
        """
        return cls.query.filter(cls.status.in_([0, 1, 4, 5])).order_by(-cls.create_time).all()

    @classmethod
    def batch_update_status(cls, task_status, task_ids):
        """
        根据任务id更新状态
        :param task_status:
        :param task_ids:
        :return:
        """
        cls.query.filter(cls.task_id.in_(task_ids)).update({"status": task_status})
        cls.commit()

    @classmethod
    def update_status_by_task_id(cls, task_status, task_id):
        """
        根据任务id更新状态
        :param task_status:
        :param task_id:
        :return:
        """
        if not task_id:
            task_id = ''
        cls.query.filter(cls.task_id == task_id).update({"status": task_status})
        cls.commit()

    @classmethod
    def update_params_by_task_id(cls, params, task_id):
        """
        根据任务id更新状态
        :param task_status:
        :param task_id:
        :return:
        """
        if not task_id:
            task_id = ''
        cls.query.filter(cls.task_id == task_id).update({"params": params})
        cls.commit()

    @classmethod
    def update_status_msg_by_task_id(cls, task_status, task_id, msg):
        """
        根据任务id更新状态
        :param task_status:
        :param task_id:
        :param msg:
        :return:
        """
        if not task_id:
            task_id = ''
        cls.query.filter(cls.task_id == task_id).update({"status": task_status, "task_id": task_id, "msg": msg})
        cls.commit()

    @classmethod
    def update_status_to_stop(cls):
        """
        更新所有任务到停止状态
        :param task_status:
        :param task_id:
        :return:
        """
        cls.query.filter(cls.status.in_([0, 1, 4, 5])).update({"status": 3})
        cls.commit()
