from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from app.db.model import PcapManagerModel
from app.util.exception import PcapNotFound


class PcapHandler(PcapManagerModel):

    @classmethod
    def get_obj_by_uuid(cls, uuid):
        try:
            obj = cls.query.filter(cls.uuid == uuid).one()
        except (NoResultFound, MultipleResultsFound) as e:
            raise PcapNotFound(uuid, str(e))
        return obj

    @classmethod
    def batch_pcap_by_names(cls, names):
        qs = cls.query.filter(cls.name.in_(names)).all()
        return qs
