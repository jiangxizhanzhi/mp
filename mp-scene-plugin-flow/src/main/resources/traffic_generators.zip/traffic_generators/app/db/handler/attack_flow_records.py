from sqlalchemy import func

from app.db.model import TaskAttackFlowRecords
from app.ext import db


class TaskAttackFlowRecordsHandler(TaskAttackFlowRecords):
    """
    攻击任务流量记录结果的操作类
    """

    @classmethod
    def get_all_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取所有流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        return cls.query.filter(cls.task_uuid == task_uuid).order_by(cls.create_time).all()

    @classmethod
    def get_max_group_count_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最大执行次数
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        return 0 if not max_group_count else max_group_count

    @classmethod
    def get_last_records_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最新的流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        max_group_count = 1 if not max_group_count else max_group_count
        return cls.query.filter(cls.task_uuid == task_uuid, cls.group_count == max_group_count,
                                cls.status == 0).order_by(cls.create_time).all()

    @classmethod
    def batch_update_records_status(cls, task_status, task_uuid):
        """
        根据任务id批量更新记录状态
        :param task_status:
        :param task_uuid:
        :return:
        """
        if not task_uuid:
            task_uuid = ''

        sql_str = '''
                    update 
                        attack_flow_records
                        set `status` = :task_status
                    where `task_uuid` = :task_uuid
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_uuid": task_uuid})
        cls.commit()
        return cursor
