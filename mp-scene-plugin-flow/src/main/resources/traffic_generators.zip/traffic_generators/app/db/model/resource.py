from datetime import datetime

from .common import DbManager
from app.ext import db


class PcapManagerModel(db.Model, DbManager):
    """流量包管理表    表名pcap_manager"""

    __tablename__ = "pcap_manager"
    uuid = db.Column(db.String(64), primary_key=True)  # 流量包uuid
    name = db.Column(db.String(256))  # 流量包名称
    file_path = db.Column(db.String(256))  # 流量包保存路径
    tag_id = db.Column(db.Integer)  # tag的id
    description = db.Column(db.String(1024), default='')  # 描述信息
    type = db.Column(db.String(10))  # 流量包类型 值为： strike(武器库)或normal(普通流量)
    category_id = db.Column(db.Integer)  # category的id
    built_in = db.Column(db.Boolean, default=False)  # 是否为内置资源
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间