import datetime

from app.ext import db
from app.util.utils import generate_uuid


class DbManager:
    """
    操作数据库的一些公共方法
    """

    @classmethod
    def save(cls, object):
        """
        保存单条数据到数据库中
        :return:
        """
        db.session.add(object)
        db.session.commit()

    @classmethod
    def commit(cls):
        """
        数据库的单独提交
        :return:
        """
        db.session.commit()

    def to_dict(self, exclued=None):
        TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
        dict_ = dict()
        all = {c.name: getattr(self, c.name, None) for c in self.__table__.columns}
        if not exclued:
            for k, v in all.items():
                if isinstance(v, datetime.datetime):
                    dict_[k] = v.strftime(TIME_FORMAT)
                else:
                    dict_[k] = v
        else:
            for k, v in all.items():
                if k not in exclued:
                    if isinstance(v, datetime.datetime):
                        dict_[k] = v.strftime(TIME_FORMAT)
                    else:
                        dict_[k] = v
        return dict_

    @classmethod
    def rollback(cls):
        """
        数据库回滚操作
        :return:
        """
        db.session.rollback()
        db.session.commit()

    @classmethod
    def verify_unique_file_path(cls, file_path, exclude=None):
        """
        校验路径是否唯一
        :param file_path: 需要校验的路径
        :param exclude: 编辑时候的对象的uuid
        :return: 唯一的话返回True，否则返回False
        """
        if exclude:
            obj = cls.query.filter(cls.uuid != exclude).filter(cls.file_path == file_path).first()
        else:
            obj = cls.query.filter(cls.file_path == file_path).first()
        return True if not obj else False

    @classmethod
    def create_obj(cls, data, postfix):
        if not data["uuid"]:
            part_uuid = generate_uuid()
            uuid = f"{part_uuid}_{postfix}"
            data["uuid"] = uuid
        obj = cls(**data)
        cls.save(obj)
        return obj
