import json
import logging
import time
from logging import getLogger
from threading import Thread

from app.controller import TaskRecordsManager
from app.db import TaskPortManagerHandler
from app.ext import cache
from app.util.constant import TaskPortStatus


class TaskRunningApplication():
    """
    WS通信程序
    """
    log = getLogger('ws')

    def start_refresh_task(self,task_id):
        self.log.info(f"start new thread to refresh task for {task_id}")
        th = Thread(target=self.refresh_task, args=(task_id,))
        th.start()
        self.log.info(f"refresh task for {task_id} thread id is {th.ident}")
        time.sleep(1)
    def refresh_task(self, task_id):
        self.log.info(f"refresh task for {task_id} 1111111111")
        try:
            self.log.info(f"refresh task for {task_id} 1111111112")
            from manage import app
            self.log.info(f"refresh task for {task_id} 1111111113")
            with app.app_context():
                running = True
                count = 0
                self.log.info(f"refresh task for {task_id} 1111111114")
                while running:
                    try:
                        self.log.info(f"refresh task status {task_id}")
                        task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
                        # ws_log.info(f"======task_port_obj: {task_port_obj.to_dict()}")

                        if not task_port_obj:
                            self.log.error(f"task is not exist for [{task_id}]")
                            break

                        info = {}

                        # 1分钟，任务状态还不是准备中或运行中，则停止线程
                        if count > 60 and task_port_obj.status != TaskPortStatus.preparing and task_port_obj.status != TaskPortStatus.running:
                            self.log.error(f"[{task_id}] is not started")
                            cache.delete("TASK_RUNNING_STATUS_" + task_id)
                            break

                        # 刷新缓存时间
                        cache.set("TASK_RUNNING_STATUS_" + task_id, task_id, timeout=5)

                        # 准备中的任务，避免多余查库，直接等待
                        if task_port_obj.status == TaskPortStatus.preparing:
                            del task_port_obj
                            self.log.info(f"task is preparing ,wait to running , task id is {task_id}")
                            time.sleep(3)
                            continue

                        status = task_port_obj.status
                        # 封装流量运行结果
                        flow_records_list = TaskRecordsManager.get_flow_records_list(task_id)
                        if not flow_records_list or len(flow_records_list) == 0:
                            if count > 2 and status == TaskPortStatus.error:
                                # 流量执行失败
                                info["flow_record"] = {}
                            elif count > 2 and status == TaskPortStatus.stopped:
                                # 流量执行完成
                                info["flow_record"] = {}
                            else:
                                count = count + 2
                                # ws_log.info(f"{task_id} task is starting...")
                                del task_port_obj
                                del flow_records_list
                                time.sleep(1)
                                continue
                        else:
                            flow_records_list = flow_records_list[len(flow_records_list) - 1]
                            info["flow_record"] = flow_records_list

                        info["task_id"] = task_id
                        info["status"] = status
                        info["msg"] = task_port_obj.msg if status == TaskPortStatus.error else "success"
                        self.log.info(f"refresh task {task_id} info: {json.dumps(info)}")

                        if status == TaskPortStatus.error or status == TaskPortStatus.stopped:
                            cache.delete("TASK_RUNNING_STATUS_" + task_id)
                            break
                        del info
                        del task_port_obj
                        del flow_records_list
                        time.sleep(1)
                    except Exception as e:
                        cache.delete("TASK_RUNNING_STATUS_" + task_id)
                        self.log.error(f"refresh task error for task:{task_id}, {e}")
                        running = False
        except Exception as ea:
            self.log.error(f"refresh task error for task:{task_id}, {ea}")

