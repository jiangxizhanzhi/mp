from flask import g

from app.util.status_code import status_codes


def resp_message(data=None, code=1000, msg=None) -> dict:
    '''
    返回值包装器
    :param data: 返回的数据内容
    :param code: 状态码
    :param msg: 返回的信息
    :return:
    '''
    resp = {'code': code, 'msg': msg}
    if not msg:
        lan = g.get('lan', "zh")
        msg = status_codes[code][1][lan]
        resp.update({'msg': msg})
    if data:
        resp.update({'data': data})
    return resp