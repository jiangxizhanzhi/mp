import ctypes
import fcntl
import inspect
import random
import socket
import struct
import threading
from datetime import datetime
from logging import getLogger
from uuid import uuid4

import numpy as np
import psutil
from scipy.stats import binom
from scipy.stats import norm

from config import TREX_PORT_START, TREX_DAEMON_PORT_CACHE
from app.ext import cache

uuidChars = ("a", "b", "c", "d", "e", "f",
             "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
             "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
             "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
             "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
             "W", "X", "Y", "Z")

log = getLogger('app')

port_lock = threading.Lock()

def generate_uuid():
    return str(uuid4()).split('-')[-1]

def get_available_port():
    """获取一个可用的端口号"""
    with port_lock:
        while True:
            port = cache.get(TREX_DAEMON_PORT_CACHE)
            if port is None:
                port = TREX_PORT_START
            # 在原有端口上增加1
            port += 1
            if is_port_available(port):
                cache.set(TREX_DAEMON_PORT_CACHE, port)
                log.info(f"get_available_port : {port}")
                return port


def is_port_available(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)  # Adjust the timeout as needed
    result = sock.connect_ex(('localhost', port))
    sock.close()
    return result != 0


def _async_raise(tid, exctype):
    """raises the exception, performs cleanup if needed"""

    tid = ctypes.c_long(tid)

    if not inspect.isclass(exctype):
        exctype = type(exctype)

    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))

    if res == 0:

        raise ValueError("invalid thread id")

    elif res != 1:

        # """if it returns a number greater than one, you're in trouble,

        # and you should call it again with exc=NULL to revert the effect"""

        ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)

        raise SystemError("PyThreadState_SetAsyncExc failed")

def stop_thread(tid):
    try:
        _async_raise(tid, SystemExit)
    except Exception as e:
        log.info(f"stop thread error for {e}")


def get_ip(if_name):  # get machine ip
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,
        struct.pack('256s', if_name[:15])
    )[20:24])

def get_local_ip():
    """
    获取本地ip
    :return:
    """
    local_ip = cache.get("LOCAL_IP")
    if not local_ip:
        local_ip = get_ip(b'ens3')
        cache.set("LOCAL_IP", local_ip)
    return local_ip


def get_time_diff_second(time_from, time_to):
    """
    获取2个时间差，单位：秒
    :param time_from: 格式 "2022-10-25 11:30:26"
    :param time_to: 格式 "2022-10-25 11:30:26"
    :return:
    """
    time_from_struct = datetime.strptime(time_from, "%Y-%m-%d %H:%M:%S")
    time_to_struct = datetime.strptime(time_to, "%Y-%m-%d %H:%M:%S")
    seconds = abs(time_to_struct - time_from_struct).seconds
    return seconds


def rand(rate_min, rate_max):
    """
    随机分布
    :return:
    """
    result = []
    for i in range(0, 30):
        rate = random.randint(rate_min, rate_max)
        result.append({"time": i, "bandwidth": rate})
    return result


def binomial(rate_min, rate_max):
    """
    二项分布
    :return:
    """
    n = 29  # 试验次数
    p = 0.5  # 成功概率

    # 生成x坐标和对应的二项分布概率质量函数值
    x = np.arange(0, n + 1)
    pmf = binom.pmf(x, n, p)

    # 将y值限制在0.01到0.99之间
    pmf = np.clip(pmf, 0.01, 0.99)
    result = []
    i = 1
    for y in pmf:
        percentage = round(y * 7, 2)
        rate = rate_max * percentage
        if rate < rate_min:
            rate = rate_min
        result.append({"time": i, "bandwidth": rate})
        i += 1
    return result


def exponential(rate_min, rate_max):
    """
    指数分布
    :param rate_min:
    :param rate_max:
    :return:
    """
    result = []
    max_y = 29 ** 2
    for i in range(0, 30):
        y = i ** 2
        rate_y = (y / max_y) * rate_max
        if rate_y < rate_min:
            rate_y = rate_min
        result.append({"time": i, "bandwidth": round(rate_y, 2)})
    return result


def gaussian(rate_min, rate_max):
    """
    高斯分布
    :param rate_min:
    :param rate_max:
    :return:
    """
    # 定义均值和标准差
    mu, sigma = 15, 3

    # 生成一组x值
    x = np.linspace(0, 30, num=30)

    # 计算概率密度函数
    pdf = norm.pdf(x, mu, sigma)

    # 获取y轴坐标集合
    y_coords = pdf.tolist()
    max_y = max(y_coords)

    result = []
    for i, y in enumerate(y_coords):
        rate_y = (y / max_y) * rate_max
        if rate_y < rate_min:
            rate_y = rate_min
        result.append({"time": i, "bandwidth": round(rate_y, 2)})

    return result


def kill_processes(thread_name):
    """
    杀掉包含thread_name的进程
    :param thread_name:
    :return:
    """

    for process in psutil.process_iter():
        try:
            # 获取进程的命令行参数
            cmdline = process.cmdline()

            # 检查命令行参数是否包含匹配的文本
            if any(thread_name in arg for arg in cmdline):
                process.terminate()  # 终止进程
        except Exception as e:
            pass
