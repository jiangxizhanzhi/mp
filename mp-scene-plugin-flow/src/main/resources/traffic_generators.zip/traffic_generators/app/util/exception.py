class ServiceException(Exception):
    """
    业务逻辑引发的异常
    """

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class PcapNotFound(Exception):
    def __init__(self, project, message=''):
        self.project = project
        self.message = message

    def __str__(self):
        return "pcap info could not be found: %s,reason:%s" % (self.project, self.message)
