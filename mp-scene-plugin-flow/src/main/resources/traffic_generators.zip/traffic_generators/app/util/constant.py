# 按秒计算的一天时长
DAY = 60 * 60 * 24


class TaskResultStatus(object):
    init = 0
    running = 1
    stopping = 2
    stopped = 3
    not_started = 4

    STATUS = (
        (init, '初始化'),
        (running, '正在运行'),
        (stopping, '正在停止'),
        (stopped, '已停止'),
        (not_started, '未启动过'),
    )
    CHOICES_DICT = dict(STATUS)


class TaskPortStatus(object):
    init = 0
    running = 1
    error = 2
    stopped = 3
    pause = 4
    preparing = 5

    STATUS = (
        (init, '初始化'),
        (running, '运行中'),
        (error, '异常'),
        (stopped, '已停止'),
        (pause, '暂停'),
        (preparing, '准备中')
    )
    TASK_PORT_STATUS_DICT = dict(STATUS)


class TaskAction:
    start = 1
    stop = 2
    reset = 3

    ACTION = (
        (start, '开始'),
        (stop, '停止'),
        (reset, '重置')
    )

    TASK_ACTION_DICT = dict(ACTION)


class TaskStatus:
    success = 1
    fail = 2

    RESULT = (
        (success, '成功'),
        (fail, '失败'),
    )

    TASK_RESULT_DICT = dict(RESULT)


class ThreadingRecord:
    threads = {}