import os
import subprocess
from logging import getLogger

log = getLogger('app')


def exec_cmd(cmd, check_exit_code=True, return_stderr=False):
    """
    执行linux命令的方法
    :param cmd: 命令
    :param check_exit_code:
    :param return_stderr:
    :return:
    """
    return exec_cmd_with_path(cmd, None, check_exit_code, return_stderr)


def exec_cmd_on_path(cmd, path=None):
    """
    在某个路径执行linux命令的方法
    :param cmd: 命令
    :param path: 执行命令的路径
    :param return_stderr:
    :return:
    """
    res = None
    try:
        if not path:
            data = os.popen(cmd)
        else:
            os.chdir(path)
            data = os.popen(cmd)
        res = data.read()
        log.info(f"exec_cmd_on_path result: {res}")
    except Exception as e:
        log.error(f"exec_cmd_on_path error: {e}")
        pass

    return res

def exec_cmd_with_path(cmd, path=None, check_exit_code=True, return_stderr=False):
    """
    执行linux命令的方法
    :param path:
    :param cmd: 命令
    :param check_exit_code:
    :param return_stderr:
    :return:
    """
    if path:
        os.chdir(path)
    process = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    _stdout, _stderr = (process.communicate())
    process.stdin.close()
    if _stderr:
        log.info(f"exec_cmd_with_path error: {_stderr}")
    msg = "cmd stdout:%s, cmd stderr:%s" % (_stdout, _stderr)
    # task_info.info(f"exec cmd result: {msg}")
    if process.returncode and check_exit_code:
        raise RuntimeError(msg)

    return return_stderr and (_stdout, _stderr) or _stdout


def exec_script_on_path(cmd, path=None, return_stderr=False):
    """
    执行linux命令的方法
    :param path:
    :param cmd: 命令
    :param return_stderr:
    :return:
    """
    if path:
        os.chdir(path)
    process = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    try:
        stdout, stderr = process.communicate(timeout=30)
        exit_code = process.wait()
        if stderr:
            log.info(f"exec_script_on_path error: {stderr}")
        msg = "cmd stdout:%s, cmd stderr:%s" % (stdout, stderr)
        if exit_code != 0:
            raise RuntimeError(stderr)

        if process.returncode:
            raise RuntimeError(msg)
        return return_stderr and (stdout, stderr) or stdout
    except Exception as e:
        process.kill()
        raise RuntimeError(f"[{cmd}] command execution failed: {e}")


def exec_by_system(path, cmd):
    """
    在指定的路径下，通过os.system()来执行命令
    :param path:
    :param cmd:
    :return:
    """
    os.chdir(path)
    res = os.system(cmd)
    return True if res == 0 else False
