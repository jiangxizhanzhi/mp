import concurrent.futures
import queue
import threading
from logging import getLogger

import config
from app.util.constant import ThreadingRecord


class AsyncTaskScheduler:
    """
    异步任务调度器
    """
    log = getLogger("app")

    def __init__(self, max_workers):
        self.tasks_queue = queue.Queue()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers,
                                                              thread_name_prefix="task_thread")
        self.lock = threading.Lock()

    def add_task(self, task):
        """
        添加异步任务，首先进入队列等待执行
        """
        with self.lock:
            self.tasks_queue.put(task)

    def cancel_task(self, task_id):
        """
        撤销队列中的任务，如果已经进入线程池执行或不存在，则返回False
        """
        with self.lock:
            tasks = list(self.tasks_queue.queue)
            for t in tasks:
                if t[0] == task_id:
                    self.tasks_queue.queue.remove(t)
                    return True
            return False

    def _execute_task(self, task):
        task_id, func, args, kwargs = task
        # try:
        #     result = func(*args, **kwargs)
        #     self.log.info(f"Task {task_id} completed with result: {result}")
        # except Exception as e:
        #     self.log.info(f"Task {task_id} failed with exception: {e}")
        # 在这里启动一个独立的线程去执行任务，并且分配线程ID
        try:
            my_thread = threading.Thread(target=func, args=args, name=f"task_thread_{task_id}")
            my_thread.start()
            self.log.info(f"Task {task_id} start with thread id: {my_thread.ident}")
            # 还需要将异步流量任务的线程ID缓存，后面杀死任务时需要
            ThreadingRecord.threads[config.RUNNING_FLOW_THREAD + task_id] = my_thread.ident
            # 等待线程执行结束
            my_thread.join()
        except Exception as e:
            self.log.info(f"Task {task_id} failed with exception: {e}")

    def _worker(self):
        while True:
            task = self.tasks_queue.get()
            if task is None:
                break
            self._execute_task(task)

    def start(self):
        """
        启动异步调度线程
        """
        for _ in range(self.executor._max_workers):
            threading.Thread(target=self._worker, daemon=True).start()

    def stop(self):
        """
        关闭线程调度
        """
        for _ in range(self.executor._max_workers):
            self.tasks_queue.put(None)
        self.executor.shutdown(wait=True)


if __name__ == "__main__":
    scheduler = AsyncTaskScheduler()
    scheduler.start()

    # 添加任务
    task_id = 1
    scheduler.add_task((task_id, print, ("Hello from Task 1",), {}))

    # 添加另一个任务
    task_id += 1
    scheduler.add_task((task_id, print, ("Hello from Task 2",), {}))

    # 撤销任务
    canceled = scheduler.cancel_task(1)
    print(f"Task 1 canceled: {canceled}")

    # 添加一个新任务
    task_id += 1
    scheduler.add_task((task_id, print, ("Hello from Task 3",), {}))

    scheduler.stop()
