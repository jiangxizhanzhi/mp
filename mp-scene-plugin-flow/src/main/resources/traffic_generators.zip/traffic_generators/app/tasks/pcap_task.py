import json
import requests
from datetime import timedelta
from logging import getLogger

import yaml
import os
from scapy.all import *
from scapy.layers.inet import *
from scapy.utils import rdpcap, wrpcap
from trex.astf.api import *
from trex_stl_lib.api import *

import config
from app.util.constant import TaskPortStatus, ThreadingRecord, DAY
from app.trex import TrexDaemonHandler, TrexHandler
from app.db import PcapHandler, TaskPortManagerHandler, TaskFlowRecordsHandler, TaskFlowRecordsSchema
from app.util import status_code as sc
from app.util.exception import ServiceException
from app.util.os_util import exec_cmd
from app.util.utils import stop_thread, get_local_ip, get_available_port, rand, binomial, exponential, gaussian, \
    get_time_diff_second, kill_processes
from app.ext import cache, db
from .base import TrafficTask
from app.controller import TaskRecordsManager


class PcapTrafficTask(TrafficTask):
    """
    脚本流量发生任务
    """
    log = getLogger('app')

    # trex全局锁
    lock = threading.Lock()

    def start(self):
        from manage import app
        with app.app_context():
            task_id = self.task.get("task_id")
            callback_url = self.callback_url
            self.log.info(f'prepare to send pcap flow: {task_id},callback url is {self.callback_url}')
            flow_desc = ""
            try:
                # 生成trex配置文件
                self.log.info(f"init flow config for {task_id}")
                self.__v2_init_conf_file(self.task)

                flow_id = self.task.get("flow_id")
                self.log.info(f"kill old process for {task_id}")
                kill_processes("trex_" + task_id)
                flow_obj = PcapHandler.get_obj_by_uuid(flow_id)
                file_name = flow_obj.file_path
                flow_desc = flow_obj.description
                task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
                pcap_file = os.path.join(config.PCAP_PATH, file_name)
                new_pcap_file = os.path.join(config.PCAP_PATH, task_id + "_" + file_name)
                mac = task_port_obj.mac
                target_ip = task_port_obj.target_ip
            except Exception as e:
                self.log.error(f"init conf file error for :{e}")
                TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                    "init config failed")
                return

            # 启动服务端
            try:
                # 根据任务生成的trex启动配置文件启动trex
                self.log.info(f"try to start trex server for {task_id}")
                trex_config_path = os.path.join(config.BASE_DIR,
                                                'media/trex_configs/{}.yaml'.format(
                                                    config.TREX_SERVER_PRE_NAME + task_id))
                daemon_server_status = TrexDaemonHandler.start_task_daemon_server(task_id)
                daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)

                self.log.info(
                    f"v2 init stl server trex_daemon_port：{daemon_server_status} port:{daemon_port} task_id:{task_id}")
                if not daemon_server_status or not daemon_port:
                    self.log.error("v2 init stl server trex daemon failed")
                    return

                with self.lock:
                    # 最多尝试3次启动Server，最后一次失败后抛出异常
                    trex_handler = self.__try_start_server(task_id, daemon_port, trex_config_path, 3)

            except Exception as e:
                self.log.error(f'start stateless trex service failed for {task_id} : {e}')
                try:
                    # 关闭守护进程
                    TrexDaemonHandler.stop_task_daemon_server(task_id)
                    # 关闭服务端
                    # trex_handler.stop()
                except Exception as e2:
                    self.log.error(f'stop stateless trex service failed for {task_id}: {e2}')
                # 启动服务失败后，直接将当前任务结束
                TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                    "start stateless trex service failed")
                return

            # 启动客户端
            ports = [0]
            load_lists = []
            status_thread = None
            try:
                # 从配置文件中加载端口配置
                self.log.info(f"try to start trex client for task {task_id}")
                with open(trex_config_path, 'r', encoding='utf-8') as yaml_file:
                    trex_config = yaml.load(yaml_file, Loader=yaml.SafeLoader)
                    self.log.info(f"read trex config info for pcap: {trex_config[0]}")
                    sync_port = trex_config[0].get('zmq_rpc_port')
                    async_port = trex_config[0].get('zmq_pub_port')

                stl_client = STLClient(server='127.0.0.1', sync_port=sync_port, async_port=async_port)
                # 连接trex客户端
                self.log.info(f"try to connect trex client for task {task_id}")
                stl_client.connect()
                # 将端口全部重置，排除影响
                self.log.info(f"try to reset port for task {task_id}")
                stl_client.reset(ports=ports)
                self.log.info(f"try to acquire port for task {task_id}")
                stl_client.acquire(ports=ports)

                self.log.info(f"try to get port ip for task {task_id}")
                local_ip = get_local_ip()
                isg = 0
                ipg = None
                common_conf = self.task.get("common_conf")
                if common_conf:
                    latency = common_conf.get("latency") if common_conf.get("latency") else 0
                    jitter = common_conf.get("jitter") if common_conf.get("jitter") else 0
                    isg = (latency - random.randint(0, jitter)) * 1000
                    if isg < 0:
                        isg = 0
                    ipg = common_conf.get("ipg") if common_conf.get("ipg") else 0
                    ipg = (ipg - random.randint(0, jitter)) * 1000
                    if ipg <= 0:
                        ipg = None
                keep_running = self.task.get("keep_running")  # 持续运行：0 否，1 是

                duration = None
                if 0 == keep_running and common_conf:
                    duration = common_conf.get("duration")

                replay = self.task.get("replay")  # 是否流量重放：0 否，1 是
                if replay == 0:
                    flags = ""

                    flow_conf = self.task.get("flow_conf")
                    tcp_conf = flow_conf.get("tcp_conf")
                    mss = tcp_conf.get("mss")
                    ack = tcp_conf.get("ack")
                    ugr = tcp_conf.get("ugr")
                    psh = tcp_conf.get("psh")
                    rst = tcp_conf.get("rst")
                    syn = tcp_conf.get("syn")
                    fin = tcp_conf.get("fin")
                    sport = tcp_conf.get("sport")
                    dport = tcp_conf.get("dport")

                    if 1 == ugr:
                        flags = "U"
                    if 1 == psh:
                        flags = flags + "P"
                    if 1 == rst:
                        flags = flags + "R"
                    if 1 == syn:
                        flags = flags + "S"
                    if 1 == fin:
                        flags = flags + "F"
                    if 1 == ack:
                        flags = flags + "A"

                    ipv4_conf = flow_conf.get("ipv4_conf")
                    if ipv4_conf.get("sip"):
                        local_ip = ipv4_conf.get("sip")
                    if ipv4_conf.get("dip"):
                        target_ip = ipv4_conf.get("dip")
                    ttl = ipv4_conf.get("ttl")
                    tos = ipv4_conf.get("tos")
                    src = {"start": local_ip, "end": local_ip}
                    dst = {"start": target_ip, "end": target_ip}
                    vm = self.__create_vm(src, dst)

                    # 修改pcap包配置
                    packets = rdpcap(pcap_file)
                    # 遍历每个数据包并修改它的TCP头字段
                    for packet in packets:
                        # 检查是否为TCP数据包
                        if TCP in packet:
                            # 修改TCP头字段
                            if flags:
                                packet[TCP].flags = flags  # flags标志
                            if mss:
                                packet[TCP].options = [('MSS', mss)]  # 设置MSS选项
                            if sport:
                                packet[TCP].sport = sport
                            if dport:
                                packet[TCP].dport = dport
                            packet[TCP].checksum = None
                        if IP in packet:
                            if ttl:
                                packet[IP].ttl = ttl
                            if tos:
                                packet[IP].tos = tos
                            # packet[IP].tos |= int('111000', 2)  #set dscp
                            packet[IP].checksum = None
                    wrpcap(new_pcap_file, packets)

                    mult = "1"
                    rate_unlimited = self.task.get("rate_unlimited")  # 速率无限制：0 否，1 是
                    if 0 == rate_unlimited:
                        rate_conf = self.task.get("rate_conf")
                        load_mode = rate_conf.get("load_mode")  # 发生模式：0 均匀分布、1 随机分布、2 二项分布、3 指数分布、4 高斯分布
                        rate_min = rate_conf.get("rate_min")  # 最小速率(单位Mb/s)
                        rate_max = rate_conf.get("rate_max")  # 最大速率(单位Mb/s)
                        if rate_max:
                            mult = str(rate_max) + "mbps"
                        elif rate_min:
                            mult = str(rate_min) + "mbps"
                        if load_mode == 1:
                            load_lists = rand(rate_min, rate_max)
                        elif load_mode == 2:
                            load_lists = binomial(rate_min, rate_max)
                        elif load_mode == 3:
                            load_lists = exponential(rate_min, rate_max)
                        elif load_mode == 4:
                            load_lists = gaussian(rate_min, rate_max)

                    total_pkt_num = 20000
                    pkts = PCAPReader(new_pcap_file).read_all(None, None, 1)
                    for n, (cap, ts) in enumerate(pkts, start=0):
                        if n <= total_pkt_num:
                            try:
                                s = STLStream(packet=STLPktBuilder(pkt_buffer=cap, vm=vm),
                                              mode=STLTXCont(),
                                              isg=isg  # 延迟发送，单位：微秒
                                              )
                                stl_client.add_streams(s, ports)
                            except Exception as e1:
                                # self.log.warn(f"gen STLStream error: {e1}")
                                pass

                    # 任务状态改为运行中
                    self.log.info(f'=== start to send flow {task_id} ===')
                    TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)
                    if duration:
                        self.log.info(f"start trex client duration for task {task_id}")
                        stl_client.start(mult=mult, duration=duration, force=True, ports=ports)
                    else:
                        self.log.info(f"start trex client for task {task_id}")
                        stl_client.start(mult=mult, force=True, ports=ports)
                else:
                    self.log.info(f"local_ip: {local_ip}")
                    cmd_line = "sudo ip a | grep -A1 " + mac + " | tail -n 1 |awk '{print $2}'| cut -d '/' -f 1"
                    res = exec_cmd(cmd_line)
                    str_ip = str(res, 'utf-8').strip()
                    self.log.info(f"get local port ip result for pcap: {str_ip}")
                    if str_ip:
                        local_ip = str_ip

                    push_remote = False
                    packages = rdpcap(pcap_file)
                    if len(packages) > 10000:
                        push_remote = True

                    if push_remote:
                        tmp_pcap = []
                        for pkt in packages:
                            try:
                                if pkt.haslayer("IP"):
                                    pkt.getlayer("IP").chksum = None
                                    pkt['IP'].src = local_ip
                                    pkt['IP'].dst = target_ip
                                tmp_pcap.append(pkt)
                            except Exception as e:
                                print(f"read pcap error: {e}")
                                pass

                        tmp_pcap_file = os.path.join(config.PCAP_PATH, "TMP_" + task_id + "_" + file_name)
                        wrpcap(tmp_pcap_file, tmp_pcap)
                        self.log.info(f'replay to push remote for task: {task_id}')
                        stl_client.push_remote(pcap_filename=tmp_pcap_file,  # our local PCAP file
                                               ports=ports,  # use 'port'
                                               count=1,
                                               ipg_usec=ipg,
                                               force=True
                                               )
                    else:
                        src = {"start": local_ip, "end": local_ip}
                        dst = {"start": target_ip, "end": target_ip}
                        vm = self.__create_vm(src, dst)

                        if not ipg:
                            ipg = 1000
                        stl_client.push_pcap(pcap_filename=pcap_file,
                                             count=1,
                                             force=True,
                                             ipg_usec=ipg,
                                             vm=vm
                                             )
                        self.log.info(f'replay to push pcap for task: {task_id}')

                    # 任务状态改为运行中
                    TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)

                server_time_to = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                # 计算任务启动耗时，修正任务实际运行时间
                diff_seconds = get_time_diff_second(self.server_time_from, server_time_to)
                task_time = self.task_time + timedelta(seconds=diff_seconds)
                # 另起一个线程，轮询当前发送流量状态
                self.log.info(f"start another thread to refresh flow status for task {task_id}")
                status_thread = Thread(target=self.get_update_status_for_pcap,
                                       args=(stl_client, ports, task_id, task_time, load_lists, flow_desc, duration))
                status_thread.start()
                ThreadingRecord.threads[config.RUNNING_STATUS_THREAD + task_id] = status_thread.ident

                self.log.info(f"start another thread to notify flow status for task {task_id}")
                refresh_thread = Thread(target=self.get_update_status_for_pcap2,
                                        args=(stl_client, ports, task_id, task_time, load_lists, flow_desc, duration, callback_url))
                refresh_thread.start()

                # 流量回放
                if replay == 1:
                    if keep_running == 1 or duration:
                        # 持续运行
                        while True:
                            if push_remote:
                                stl_client.push_remote(pcap_filename=tmp_pcap_file,  # our local PCAP file
                                                       ports=ports,  # use 'port'
                                                       count=1,
                                                       ipg_usec=ipg,
                                                       force=True)
                            else:
                                stl_client.start(force=True)
                            stl_client.wait_on_traffic()
                    else:
                        if not push_remote:
                            stl_client.start(force=True)
                        stl_client.wait_on_traffic()
                else:
                    stl_client.wait_on_traffic()

                stl_client.stop()
                stl_client.release()
                stl_client.disconnect()

                TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id, "success")
                self.log.info(f'=== send flow success {task_id} ===')
            except Exception as e:
                daemon_port_now = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
                if daemon_port == daemon_port_now:
                    TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                        "start stateless trex service failed")
                self.log.error(f'{task_id} send flow failed：{e}')
                self.log.error(traceback.format_exc())
            finally:
                daemon_port_now = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
                if daemon_port == daemon_port_now:
                    try:
                        # 停止获取流量状态线程
                        stop_thread(status_thread.ident)
                        ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)
                        # 关闭服务
                        trex_handler.stop()
                        # 关闭守护进程
                        TrexDaemonHandler.stop_task_daemon_server(task_id)
                    except Exception as e2:
                        self.log.error(f'stateless trex service stop failed: {e2}')
                    # 删除缓存的守护进程
                    cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
                else:
                    kill_processes("trex_daemon_server start -p " + str(daemon_port))

    def __try_start_server(self, task_id, daemon_port, trex_config_path, times=3):
        try:
            trex_handler = TrexHandler(trex_host=config.TREX_HOST,
                                       trex_daemon_port=daemon_port,
                                       trex_args="")
            self.log.info(f"start trex service {task_id}")
            status = trex_handler.start_stateless_server({'cfg': trex_config_path})
            self.log.info(f"start trex service {task_id} result status {status}")
            return trex_handler
        except Exception as e1:
            self.log.error(f"start_stateless_server error {task_id}: {e1}")
            # 出异常时，先关闭当前实例再重试
            try:
                trex_handler.stop()
            except Exception as e2:
                self.log.error(f'stop stateless trex handler failed: {e2}')

            self.log.info(f"try to start server {task_id} {times}")
            if times > 0:
                # 启动服务端失败1秒后重试
                time.sleep(1)
                return self.__try_start_server(task_id, daemon_port, trex_config_path, times - 1)
            else:
                raise SystemError("start stateless server error")

    def __v2_init_conf_file(self, task):
        """
        生成trex任务的配置文件
        :param task: 流量任务
        :return:
        """
        task_id = task.get("task_id")
        self.log.info(f"init_task_start_file start for {task_id}")
        file_name = config.TREX_SERVER_PRE_NAME + task_id
        trex_config_path = os.path.join(config.BASE_DIR, 'media/trex_configs/{}.yaml'.format(file_name))
        # 配置文件已存在，直接删除
        if os.path.exists(trex_config_path):
            os.remove(trex_config_path)

        task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
        port_name = task_port_obj.port_name
        target_ip = task_port_obj.target_ip
        index = target_ip.rfind(".")
        gateway_ip = target_ip[0:index] + ".254"

        # 解析网络结构中的数据
        network_data = {
            'version': 2,
            'prefix': file_name,
            'low_end': True
        }
        zmq_pub_port = get_available_port()
        zmq_rpc_port = get_available_port()
        network_data['zmq_pub_port'] = zmq_pub_port
        network_data['zmq_rpc_port'] = zmq_rpc_port
        network_data['port_info'] = []
        network_data['interfaces'] = []

        # local_ip = get_local_ip()
        str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
        port_ip = str(str_ip, 'utf-8').strip()
        self.log.info(f"{port_name}===========port_ip：{port_ip}")

        count = 0
        while not port_ip:
            if count > 60:
                break
            time.sleep(2)
            str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
            port_ip = str(str_ip, 'utf-8').strip()
            self.log.info(f"{port_name}===========port_ip_again：{port_ip}")

        if not port_ip:
            raise ServiceException(code=sc.SystemError, message=f'get port ip failed for {port_name}')

        network_data['interfaces'].append(port_name)
        network_data['interfaces'].append('dummy')
        network_data['port_info'].append({
            'ip': port_ip,
            'default_gw': gateway_ip
        })
        network_data['port_limit'] = 2
        self.log.info(f"init task conf file result: {network_data}")

        # 将组合的数据序列化到yaml文件中
        with open(trex_config_path, 'w+') as f:
            yaml.dump([network_data], f, default_flow_style=False)
        self.log.info(f"init_task_start_file end for {task_id}")


    def __create_vm(self, ip_src_range, ip_dst_range):
        if not ip_src_range and not ip_dst_range:
            return None

        vm = []

        # self.log.info(f"===ip_src_range:{ip_src_range}")
        if ip_src_range:
            vm += [STLVmFlowVar(name="src",
                                min_value=ip_src_range['start'],
                                max_value=ip_src_range['end'],
                                size=4, op="inc"),
                   # STLVmWrFlowVar(fv_name="src",pkt_offset= "IP.src")
                   STLVmWrFlowVar(fv_name="src", pkt_offset=26)
                   ]

        if ip_dst_range:
            vm += [STLVmFlowVar(name="dst",
                                min_value=ip_dst_range['start'],
                                max_value=ip_dst_range['end'],
                                size=4, op="inc"),

                   # STLVmWrFlowVar(fv_name="dst",pkt_offset= "IP.dst")
                   STLVmWrFlowVar(fv_name="dst", pkt_offset=30)
                   ]

        vm += [  # STLVmFixIpv4(offset = "IP")
            STLVmFixIpv4(offset=14)
        ]

        return vm

    def get_update_status_for_pcap(self, stl_client, ports, task_id, task_time, load_lists, flow_desc, duration):
        from manage import app
        with app.app_context():
            if not ports:
                ports = [0]
            i = 1
            try:
                now = datetime.now()
                offset = timedelta(seconds=1)
                # 当前执行次数
                group_count = TaskFlowRecordsHandler.get_max_group_count_by_task_uuid(task_id) + 1
                task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
                port_name = task_port_obj.port_name
            except Exception as e:
                self.log.error(f"get_update_status_for_pcap for {e}")
                return

            # 带宽实际循环次数
            count = 1
            while stl_client.is_connected():
                try:
                    if duration and i > duration:
                        stop_task_thread = Thread(target=self.kill_task, args=(task_id,))
                        stop_task_thread.start()
                        break

                    stats = stl_client.get_stats(ports)
                    # self.log.info(f"stats['total']：{stats['total']}")
                    # self.log.info(f"{task_id} opackets：{stats['total']['opackets']}")
                    opackets = round(stats['total']['opackets'])
                    obytes = round(stats['total']['obytes'])
                    tx_bps = round(stats['total']['tx_bps'], 2)
                    oerrors = round(stats['total']['oerrors'])
                    tx_pps = round(stats['total']['tx_pps'])
                    total_tx_L2 = round(stats['total']['tx_bps'], 2)
                    total_tx_L1 = round(stats['total']['tx_bps_L1'], 2)
                    total_rx = round(stats['total']['rx_bps'], 2)
                    queue_full = round(stats['global']['queue_full'])
                    drop_rate = round(stats['global']['rx_drop_bps'], 2)
                    latency = 0
                    jitter = 0

                    if stats['latency'] and len(stats['latency']) > 1:
                        latency = stats['latency'][0]['latency']['average']
                        jitter = stats['latency'][0]['latency']['jitter']

                    protocol_objs = json.loads(flow_desc)
                    protocol_num = {}
                    for protocol in protocol_objs:
                        num = math.ceil(tx_pps * protocol_objs.get(protocol) / 100)
                        protocol_num[protocol] = num
                    cache.set("PROTOCOLS::" + task_id, protocol_num, timeout=DAY)

                    flow_record = {
                        'task_uuid': task_id,
                        'group_count': group_count,
                        'second': i,
                        'tag_id': 1,
                        'port_name': port_name,
                        'opackets': opackets,
                        'obytes': obytes,
                        'tx_bps': tx_bps,
                        'oerrors': oerrors,
                        'tx_pps': tx_pps,
                        'latency': latency,
                        'jitter': jitter,
                        'total_tx_L2': total_tx_L2,
                        'total_tx_L1': total_tx_L1,
                        'total_rx': total_rx,
                        'queue_full': queue_full,
                        'drop_rate': drop_rate,
                        'status': 0,
                        'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                        'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                    }
                    self.log.info(f"update task flow records {flow_record} for task_id {task_id} ")

                    response, errors = TaskFlowRecordsSchema().load(flow_record, session=db.session)
                    if errors:
                        # self.log.error('create task flow records error：{}'.format(errors))
                        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                    TaskFlowRecordsHandler.save(response)
                except Exception as e:
                    import traceback
                    self.log.error(f"stl_client get_stats error: {e}")
                    self.log.error(traceback.format_exc())
                    break

                if load_lists and len(load_lists) > 0:
                    load_size = len(load_lists)
                    for load in load_lists:
                        if load.get("time") == (i - ((count - 1) * load_size)):
                            bandwidth = str(round(load.get("bandwidth"))) + "mbps"
                            # self.log.debug(f"update bandwidth for {task_id} --> time:{i}, bandwidth:{bandwidth}")
                            # 动态更新带宽
                            stl_client.update(ports, mult=bandwidth)

                    # 循环次数加1
                    if (i % load_size) == 0:
                        count = count + 1

                time.sleep(1)
                i = i + 1
                task_time = task_time + offset
                now = now + offset

    def get_update_status_for_pcap2(self, stl_client, ports, task_id, task_time, load_lists, flow_desc, duration, callback_url):
        self.log.info(f"refresh task for {task_id} 1111111111 , callback_url is {callback_url}")
        try:
            self.log.info(f"refresh task for {task_id} 1111111112")
            from manage import app
            self.log.info(f"refresh task for {task_id} 1111111113")
            with app.app_context():
                running = True
                count = 0
                self.log.info(f"refresh task for {task_id} 1111111114")
                while running:
                    try:
                        self.log.info(f"refresh task status {task_id}")
                        task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
                        # ws_log.info(f"======task_port_obj: {task_port_obj.to_dict()}")

                        if not task_port_obj:
                            self.log.error(f"task is not exist for [{task_id}]")
                            break

                        info = {}

                        # 1分钟，任务状态还不是准备中或运行中，则停止线程
                        if count > 60 and task_port_obj.status != TaskPortStatus.preparing and task_port_obj.status != TaskPortStatus.running:
                            self.log.error(f"[{task_id}] is not started")
                            cache.delete("TASK_RUNNING_STATUS_" + task_id)
                            break

                        # 刷新缓存时间
                        cache.set("TASK_RUNNING_STATUS_" + task_id, task_id, timeout=5)

                        # 准备中的任务，避免多余查库，直接等待
                        if task_port_obj.status == TaskPortStatus.preparing:
                            del task_port_obj
                            self.log.info(f"task is preparing ,wait to running , task id is {task_id}")
                            time.sleep(3)
                            continue

                        status = task_port_obj.status
                        # 封装流量运行结果
                        flow_records_list = TaskRecordsManager.get_flow_records_list(task_id)
                        if not flow_records_list or len(flow_records_list) == 0:
                            if count > 2 and status == TaskPortStatus.error:
                                # 流量执行失败
                                info["flow_record"] = {}
                            elif count > 2 and status == TaskPortStatus.stopped:
                                # 流量执行完成
                                info["flow_record"] = {}
                            else:
                                count = count + 2
                                # ws_log.info(f"{task_id} task is starting...")
                                del task_port_obj
                                del flow_records_list
                                time.sleep(1)
                                continue
                        else:
                            flow_records_list = flow_records_list[len(flow_records_list) - 1]
                            info["flow_record"] = flow_records_list

                        info["task_id"] = task_id
                        info["status"] = status
                        info["msg"] = task_port_obj.msg if status == TaskPortStatus.error else "success"
                        self.log.info(f"refresh task {task_id} info: {json.dumps(info)}")

                        headers = {'Content-Type': 'application/json','clientId': '84261d495c414e','clientSecret': '2112f4b855264ad7b1a4209737fc7836'}

                        response = requests.post(callback_url, data=json.dumps(info), headers=headers)

                        if status == TaskPortStatus.error or status == TaskPortStatus.stopped:
                            cache.delete("TASK_RUNNING_STATUS_" + task_id)
                            break
                        del info
                        del task_port_obj
                        del flow_records_list
                        time.sleep(1)
                    except Exception as e:
                        cache.delete("TASK_RUNNING_STATUS_" + task_id)
                        self.log.error(f"refresh task error for task:{task_id}, {e}")
                        running = False
        except Exception as ea:
            self.log.error(f"refresh task error for task:{task_id}, {ea}")