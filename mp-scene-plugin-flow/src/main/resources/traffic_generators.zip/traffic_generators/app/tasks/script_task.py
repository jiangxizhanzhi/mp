from datetime import timedelta
from logging import getLogger

import psutil
from scapy.all import *
from scapy.layers.inet import *

import config
from app.util.constant import TaskPortStatus, ThreadingRecord, TaskResultStatus
from app.db import PcapHandler, TaskPortManagerHandler, TaskFlowRecordsHandler, TaskAttackFlowRecordsHandler, \
    TaskAttackFlowRecordsSchema
from app.util import status_code as sc
from app.util.os_util import exec_cmd_with_path
from app.util.utils import stop_thread, get_time_diff_second
from app.ext import db
from .base import TrafficTask


class ScriptTrafficTask(TrafficTask):
    """
    脚本流量发生任务
    """
    log = getLogger('app')

    def start(self):
        from manage import app
        with app.app_context():
            task_id = self.task.get("task_id")
            flow_id = self.task.get("flow_id")
            attack_confs = self.task.get("attack_confs")

            task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
            port_name = task_port_obj.port_name
            target_ip = task_port_obj.target_ip
            flow_obj = PcapHandler.get_obj_by_uuid(flow_id)
            file_name = flow_obj.file_path
            suffix = file_name.split('.')[-1]

            server_time_to = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            # 计算任务启动耗时，修正任务实际运行时间
            diff_seconds = get_time_diff_second(self.server_time_from, server_time_to)
            task_time = self.task_time + timedelta(seconds=diff_seconds)
            # 起线程获取网口流量状态
            get_port_status_th = Thread(target=self.get_port_status_for_script,
                                        args=(port_name, task_id, task_time))
            get_port_status_th.start()
            ThreadingRecord.threads[config.RUNNING_STATUS_THREAD + task_id] = get_port_status_th.ident

            try:
                # 任务状态更新为运行中
                TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)
                run_cmd = ""
                attack_flow_path = os.path.join(config.BASE_DIR, 'media/run_images_scripts/{}'.format(file_name))
                new_file_name = task_id + "_" + file_name
                new_attack_flow_path = os.path.join(config.BASE_DIR,
                                                    'media/run_images_scripts/{}'.format(new_file_name))

                # 更新配置
                # 打开文件
                with open(attack_flow_path, 'r') as f:
                    # 读取文件内容
                    file_content = f.read()
                    new_file_content = file_content

                if attack_confs:
                    for attack_conf in attack_confs:
                        if str(attack_conf.get('conf_key')) == 'ip':
                            new_file_content = new_file_content.replace("$ip", target_ip)
                        else:
                            # 替换字符串
                            new_file_content = new_file_content.replace("$" + str(attack_conf.get('conf_key')),
                                                                        str(attack_conf.get("conf_value")))
                # 保存文件
                with open(new_attack_flow_path, 'w') as f:
                    f.write(new_file_content)

                if suffix == "sh":
                    run_cmd = "bash " + new_file_name
                else:
                    run_cmd = "python " + new_file_name

                self.log.info(f"======begin to run script of task : {task_id}")
                self.log.info(f"======script run_cmd: {run_cmd}")
                exec_cmd_with_path(run_cmd, "/opt/project_dirs/traffic_generators/media/run_images_scripts")
            except Exception as e:
                err_msg = e.args[0][e.args[0].find("Exception: "):]
                if not "Exception" in err_msg:
                    err_msg = e
                # 更新任务异常状态和信息
                TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.error, task_id, err_msg)
                self.log.error('[{}] script run failed for: {}'.format(run_cmd, err_msg))
                return False
            finally:
                stop_thread(get_port_status_th.ident)
                ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)

            TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id, "success")
            self.log.info(f'run script command success of task: {task_id}')
            return True

    def get_port_status_for_script(self, port_name, task_uuid, task_time):
        """
        获取网口流量状态信息
        :param port_name: 网口名称
        :param task_uuid: 任务id
        :param task_time: 任务时间
        :return:
        """
        from manage import app
        with app.app_context():
            i = 1
            now = None
            offset = timedelta(seconds=1)
            # 当前执行次数
            group_count = TaskAttackFlowRecordsHandler.get_max_group_count_by_task_uuid(task_uuid) + 1
            pre_packets_sent = -1
            pre_bytes_sent = -1
            pre_bytes_recv = -1
            pre_errout = -1
            tx_pps = 0
            try:
                while True:
                    if i % 5 == 0:
                        task_results = TaskPortManagerHandler.get_by_task_id(task_uuid)
                        if task_results:
                            if task_results.status == TaskResultStatus.stopped:
                                # task_info.info(f"{task_uuid} task is stopped, cancel get port flow status")
                                break

                    port_flow_status = psutil.net_io_counters(pernic=True)
                    port_flow = port_flow_status.get(port_name)
                    # task_info.info(f"========port_flow: {port_flow}")
                    packets_sent = round(port_flow.packets_sent)
                    bytes_sent = round(port_flow.bytes_sent)
                    errout = round(port_flow.errout)
                    bytes_recv = round(port_flow.bytes_recv)
                    dropin = port_flow.dropin
                    # task_info.info(f"[{task_uuid}] script packets_sent: {packets_sent}")

                    if pre_packets_sent == -1:
                        pre_packets_sent = packets_sent
                        pre_bytes_sent = bytes_sent
                        pre_bytes_recv = bytes_recv
                        pre_errout = errout
                    else:
                        if packets_sent != pre_packets_sent:
                            if not now:
                                now = datetime.now()
                            opackets = packets_sent - pre_packets_sent
                            obytes = bytes_sent - pre_bytes_sent
                            oerrors = errout - pre_errout
                            # 计算平均发包速率
                            tx_bps = round(obytes / i, 2)
                            rbytes = bytes_recv - pre_bytes_recv
                            total_rx = round(rbytes / i, 2)
                            # 实时发包数
                            tx_pps = opackets

                            attack_flow_record = {
                                'task_uuid': task_uuid,
                                'group_count': group_count,
                                'second': i,
                                'opackets': opackets,
                                'obytes': obytes,
                                'tx_bps': tx_bps,
                                'oerrors': oerrors,
                                'tx_pps': tx_pps,
                                'latency': 0,
                                'jitter': 0,
                                'total_tx_L2': tx_bps,
                                'total_tx_L1': tx_bps,
                                'total_rx': total_rx,
                                'queue_full': 0,
                                'drop_rate': dropin,
                                'packets_sent': packets_sent,
                                'bytes_sent': bytes_sent,
                                'errout': errout,
                                'status': 0,
                                'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                                'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                            }
                            response, errors = TaskAttackFlowRecordsSchema().load(attack_flow_record,
                                                                                  session=db.session)
                            if errors:
                                self.log.error('create attack task flow records error：{}'.format(errors))
                                return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                            TaskFlowRecordsHandler.save(response)
                            i = i + 1
                            now = now + offset
                        time.sleep(1)
                        task_time = task_time + offset
            except Exception as e:
                self.log.error(f"get port flow status error: {e}")
                pass
