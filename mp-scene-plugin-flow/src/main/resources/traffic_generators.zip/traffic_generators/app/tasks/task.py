from logging import getLogger

from .pcap_task import PcapTrafficTask
from .script_task import ScriptTrafficTask


def v2_send_stl_flow(task, task_time, server_time_from, callback_url):
    """
    发送无状态模式的流量
    :param task: 流量任务
    :param task_time: 任务开始时间
    :param server_time_from: 任务调用时间
    :return:
    """
    log = getLogger('app')
    task_id = task.get("task_id")
    resource_type = task.get("resource_type")
    log.info(f"======run pcap or script of task: {task_id}")
    traffic_task = ScriptTrafficTask(task, task_time, server_time_from, callback_url)
    if resource_type == 0:
        traffic_task = PcapTrafficTask(task, task_time, server_time_from, callback_url)
    traffic_task.start()
