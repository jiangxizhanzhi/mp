from logging import getLogger

import config
from app.db import TaskPortManagerHandler
from app.ext import cache
from app.trex import TrexHandler, TrexDaemonHandler
from app.util.constant import ThreadingRecord, TaskPortStatus
from app.util.http_util import resp_message
from app.util.utils import stop_thread, kill_processes
from config import TREX_HOST


class TrafficTask(object):
    """
    流量发生任务基类
    """
    log = getLogger('app')

    def __init__(self, task, task_time, server_time_from, callback_url):
        self.task = task
        self.task_time = task_time
        self.server_time_from = server_time_from
        self.callback_url = callback_url

    def start(self):
        pass

    @classmethod
    def kill_task(cls, task_id):
        """
        停止任务
        :param task_id:
        :return:
        """
        from manage import app
        with app.app_context():
            try:
                cls.log.info(f"task stop for {task_id}")
                TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.stopped, task_id)

                # 停止任务状态刷新线程（启动流量发送脚本或pcap后，定时轮训任务状态和数据的线程）
                tid = ThreadingRecord.threads.get(config.RUNNING_STATUS_THREAD + task_id)
                stop_thread(tid)
                ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)
                cls.log.info(f"{task_id}: is stopped")

                # 停止trex server
                cls._stop_stl_server(task_id)
                kill_processes("trex_" + task_id)

                # 停止任务线程（controller层为每个任务启动的线程）
                tid = ThreadingRecord.threads.get(config.RUNNING_FLOW_THREAD + task_id)
                stop_thread(tid)
                ThreadingRecord.threads.pop(config.RUNNING_FLOW_THREAD + task_id, None)
            except Exception as e:
                cls.log.error(f"{task_id}: stop error for {e}")

            return resp_message()

    @classmethod
    def _stop_stl_server(cls, task_id):
        """
        停止trex服务端
        :return:
        """
        try:
            daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
            if daemon_port:
                cls.log.info(f"v2 stop stl server trex_daemon_port：{daemon_port}")
                trex_handler = TrexHandler(trex_host=TREX_HOST,
                                           trex_daemon_port=daemon_port,
                                           trex_args="")
                trex_handler.stop()
                TrexDaemonHandler.stop_task_daemon_server(task_id)
            cls.log.info(f"{task_id}: trex server stopped")
        except Exception as e:
            cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
            cls.log.error(f"{task_id} stop trex server failed: {e}")