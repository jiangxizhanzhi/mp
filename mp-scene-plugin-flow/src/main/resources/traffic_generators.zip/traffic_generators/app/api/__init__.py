from flask import Blueprint
from flask_restplus import Api

from .task import task_ns
from .resource import resource_ns

flow_blueprint = Blueprint('flow_blueprint', __name__)
flow_api = Api(flow_blueprint, version='v2')

flow_api.add_namespace(task_ns)
flow_api.add_namespace(resource_ns)
