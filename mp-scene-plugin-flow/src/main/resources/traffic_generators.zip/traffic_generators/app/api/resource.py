from logging import getLogger

from flask_restplus import Namespace, Resource
from flask import request

from config import PCAP_PATH, RUN_IMAGE_SCRIPTS_PATH
from app.util.http_util import resp_message
from app.util import status_code as sc
from app.controller import PcapManager

resource_ns = Namespace('resource', description="Endpoint to manage pcap file")


@resource_ns.route("/pcap/upload")
class FileApi(Resource):
    """
    文件资源管理
    """
    pcap = PcapManager()

    log = getLogger('app')

    def post(self):
        """
        上传pcap文件或攻击脚本文件
        """
        req_data = request.files.to_dict()
        self.log.info(f"v2 upload req_data：{req_data}")
        req_param = request.form.to_dict()
        self.log.info(f"v2 upload req_param：{req_param}")
        flow_file = req_data.get("file")

        if not flow_file:
            return resp_message(code=sc.SystemError, msg="please upload flow file")
        file_name = req_param.get("fileName")
        if not file_name:
            return resp_message(code=sc.SystemError, msg="file_name can not be empty")

        is_attack_flow = True
        flow_path = PCAP_PATH
        suffix = file_name.split('.')[-1]
        if suffix == "pcap":
            is_attack_flow = False
        elif suffix == "sh" or suffix == "py":
            flow_path = RUN_IMAGE_SCRIPTS_PATH
        else:
            return resp_message(code=sc.SystemError, msg="not flow file")

        flow_id = req_param.get("flowId")
        if not flow_id:
            return resp_message(code=sc.SystemError, msg="flow_id can not be empty")
        path_name = flow_id + "." + suffix

        protocol_rate = req_param.get("protocolRate")
        if not is_attack_flow and not protocol_rate:
            return resp_message(code=sc.SystemError, msg="protocol_rate can not be empty")

        pcap_info = {
            "uuid": flow_id,
            "name": file_name,
            "file_path": path_name,
            "description": protocol_rate
        }

        only_name = self.pcap.verify_file_path(path_name)
        if only_name is False:
            # 流量已存在，覆盖更新
            self.log.info(f"flow file {flow_id} will be overwrite")
            self.pcap.upload_flow_file(path_name, flow_file, flow_path)
            self.pcap.update_pcap_info(flow_id, pcap_info)
            return resp_message(code=sc.Success)

        self.pcap.upload_flow_file(path_name, flow_file, flow_path)
        self.log.info(f"v2 upload flow success：{file_name}")

        obj = self.pcap.create_pcap_info(pcap_info)
        data = {
            "uuid": obj.uuid,
            "file_name": file_name
        }
        self.log.info(f"v2 upload flow manage success：{file_name}")
        return resp_message(data=data)