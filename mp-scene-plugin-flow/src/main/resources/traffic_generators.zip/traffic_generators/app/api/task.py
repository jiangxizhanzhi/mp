from logging import getLogger

from flask import request
from flask_restplus import Namespace, Resource

from app.controller import NetworkManager, OpsManager, TaskManager, BatchTaskManager, TaskRecordsManager
from app.util import status_code as sc
from app.util.http_util import resp_message

task_ns = Namespace('task', description='Endpoint to manage flow task')

@task_ns.route('/v2/tasks/batch/action')
class TaskBatchApi(Resource):
    """
    任务批量操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = BatchTaskManager(params).v2_task_batch_operation()
        return resp_message(**response)


@task_ns.route('/v2/tasks/action')
class TaskApi(Resource):
    """
    任务操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = TaskManager(params).v2_task_operation()
        return resp_message(**response)


@task_ns.route('/tasks/protocols/top5')
class StatisticApi(Resource):
    """
    获取任务流量TOPN
    """

    def post(self):
        result = OpsManager.get_protocols_top5()
        data = {
            "protocols": result,
        }
        return resp_message(data=data)


@task_ns.route('/network/init')
class NetworkApi(Resource):
    """
    网口初始化api
    """
    log = getLogger('app')

    def post(self):
        """
        网口初始化
        :return:
        """
        params = request.get_json()
        network_infos = params.get('network_infos')
        self.log.info(f"network init networkInfos:{network_infos}")
        if not network_infos:
            self.log.error("networkInfos can not be empty")
            return resp_message(code=sc.ParameterError)

        return NetworkManager.init_networks(network_infos)


@task_ns.route('/tasks/init')
class TaskLegacyApi(Resource):
    """
    遗留接口适配
    """

    def post(self):
        return resp_message()
