from trex_control_plane.stf.trex_stf_lib.trex_client import CTRexClient

from config import PASSWORD, DPDK_PATH, TREX_DAEMON_SERVER_PORT_NAME
from app.ext import cache
from app.util.os_util import exec_cmd_on_path, exec_by_system
from app.util.utils import get_available_port
from logging import getLogger

log = getLogger('app')


class TrexHandler(CTRexClient):
    """
    此处的类是调用守护进程的一些rpc方法来对trex进行一些启动、停止的操作
    """

    def __init__(self, **kwargs):
        super(TrexHandler, self).__init__(**kwargs)

    def start_stateless_server(self, trex_cmd_options):
        """
        启动无状态trex服务
        :param trex_cmd_options: 启动trex服务需要的一些额外参数
        :return:
        """
        return self.start_stateless(block_to_success=True, **trex_cmd_options)

    def start_stateful_server(self, trex_cmd_options):
        """
        启动有状态trex服务
        :param trex_cmd_options: 启动trex服务需要的一些额外参数
        :return:
        """
        return self.start_astf(block_to_success=True, **trex_cmd_options)

    def stop(self):
        """
        停止trex服务
        :return:
        """
        return self.force_kill(confirm=False)


class TrexDaemonHandler:
    """
    用于启动守护进程服务来管理真正的trex进程，包括启动有状态和无状态
    """

    @classmethod
    def start_daemon_server(cls, task_name, task_type):
        """
        启动守护进程
        :param task: 任务对象
        :return:
        """
        # 无状态
        if task_type == 1:
            if not cache.get(TREX_DAEMON_SERVER_PORT_NAME):
                daemon_server_port = get_available_port()
                cache.set(TREX_DAEMON_SERVER_PORT_NAME, daemon_server_port, timeout=0)
            else:
                log.info(f"daemon_server_port:{cache.get(TREX_DAEMON_SERVER_PORT_NAME)} exist")
                return True
            log.info(f"current daemon_server_port:{daemon_server_port}")

            cmd = 'echo {} | sudo -S python3 master_daemon.py --trex-daemon-port {} --type trex_daemon_server start'.format(
                PASSWORD, daemon_server_port)
            exec_result = exec_cmd_on_path(cmd, DPDK_PATH)
            log.info(f"command {cmd} result: {exec_result}")
        # 有状态
        else:
            daemon_server_port = get_available_port()
            cache.set(task_name, daemon_server_port, timeout=0)
            cmd = 'echo {} | sudo -S python3 master_daemon.py -p {} --type master_daemon start'.format(PASSWORD,
                                                                                                       daemon_server_port)
            exec_result = exec_by_system(DPDK_PATH, cmd)

        if not exec_result:
            return False
        return True

    @classmethod
    def start_task_daemon_server(cls, task_id):
        """
        启动守护进程
        :param task_id: 任务id
        :return:
        """
        if not cache.get(TREX_DAEMON_SERVER_PORT_NAME + task_id):
            daemon_server_port = get_available_port()
            cache.set(TREX_DAEMON_SERVER_PORT_NAME + task_id, daemon_server_port, timeout=0)
            log.info(f"create new daemon_server_port:{cache.get(TREX_DAEMON_SERVER_PORT_NAME + task_id)}")
        else:
            log.info(f"daemon_server_port:{cache.get(TREX_DAEMON_SERVER_PORT_NAME + task_id)} exist")
            return True
        log.info(f"current daemon_server_port:{daemon_server_port}")

        cmd = 'echo {} | sudo -S python3 master_daemon.py --trex-daemon-port {} --type trex_daemon_server start'.format(
            PASSWORD, daemon_server_port)
        exec_result = exec_cmd_on_path(cmd, DPDK_PATH)
        log.info(f"command {cmd} result: {exec_result}")

        if not exec_result:
            return False
        return True

    @classmethod
    def stop_task_daemon_server(cls, task_id):
        """
        停止守护进程
        :param task_id: 任务id
        :return:
        """
        if cache.get(TREX_DAEMON_SERVER_PORT_NAME + task_id):
            daemon_port = cache.get(TREX_DAEMON_SERVER_PORT_NAME + task_id)
            cache.delete(TREX_DAEMON_SERVER_PORT_NAME + task_id)
        else:
            log.info(f"task daemon server has no port {task_id}")
            return True

        cmd = 'echo {} | sudo -S python3 master_daemon.py --trex-daemon-port {} --type trex_daemon_server stop'.format(
            PASSWORD, daemon_port)
        exec_result = exec_cmd_on_path(cmd, DPDK_PATH)

        if not exec_result:
            log.info(f"stop task daemon server failed {task_id}")
            return False
        log.info(f"stop task daemon server success {task_id}")
        return True

    @classmethod
    def stop_daemon_server(cls, task_name, task_type):
        """
        停止守护进程
        :param task: 任务对象
        :return:
        """
        if cache.get(TREX_DAEMON_SERVER_PORT_NAME):
            daemon_port = cache.get(TREX_DAEMON_SERVER_PORT_NAME)
        else:
            return True

        # 无状态
        if task_type == 1:
            cmd = 'echo {} | sudo -S python3 master_daemon.py --trex-daemon-port {} --type trex_daemon_server stop'.format(
                PASSWORD, daemon_port)
        # 有状态
        else:
            cmd = 'echo {} | sudo -S python3 master_daemon.py -p {} --type master_daemon stop'.format(PASSWORD,
                                                                                                      daemon_port)
        exec_result = exec_cmd_on_path(cmd, DPDK_PATH)
        if not exec_result:
            return False
        return True
