import time

from app.db import TaskFlowRecordsHandler, TaskAttackFlowRecordsHandler


class TaskRecordsManager(object):
    """
    流量任务结果管理
    """

    @classmethod
    def get_flow_records_list(cls, task_uuid):
        # 根据任务id查询最新流量记录
        flow_records = TaskFlowRecordsHandler.get_last_records_by_task_uuid(task_uuid)
        attack_flow_records = TaskAttackFlowRecordsHandler.get_last_records_by_task_uuid(task_uuid)

        flow_records_list = []
        if flow_records and not attack_flow_records:
            # 只有背景流量
            for flow_record in flow_records:
                flow_records_list.append(flow_record.to_dict())
        elif not flow_records and attack_flow_records:
            # 只有攻击流量
            for attack_flow_record in attack_flow_records:
                flow_records_list.append(attack_flow_record.to_dict())
        elif flow_records and attack_flow_records:
            # 同时有攻击、背景流量
            if len(attack_flow_records) > len(flow_records):
                max_records = attack_flow_records
                less_records = flow_records
            else:
                max_records = flow_records
                less_records = attack_flow_records

            max_left_create_time = time.strptime(max_records[0].to_dict().get("create_time"), "%Y-%m-%d %H:%M:%S")
            max_left_time = time.mktime(max_left_create_time)
            max_right_create_time = time.strptime(max_records[len(max_records) - 1].to_dict().get("create_time"),
                                                  "%Y-%m-%d %H:%M:%S")
            max_right_time = time.mktime(max_right_create_time)

            less_left_create_time = time.strptime(less_records[0].to_dict().get("create_time"), "%Y-%m-%d %H:%M:%S")
            less_left_time = time.mktime(less_left_create_time)
            less_right_create_time = time.strptime(less_records[len(less_records) - 1].to_dict().get("create_time"),
                                                   "%Y-%m-%d %H:%M:%S")
            less_right_time = time.mktime(less_right_create_time)

            # 获取时间范围
            if max_left_time < less_left_time:
                left_time = max_left_time
            else:
                left_time = less_left_time
            if max_right_time < less_right_time:
                right_time = less_right_time
            else:
                right_time = max_right_time

            # 运行结束的流量，记录最后一条
            pre_record = None
            last_max_record = max_records[len(max_records) - 1].to_dict()
            last_max_create_time = time.mktime(time.strptime(last_max_record.get("create_time"), "%Y-%m-%d %H:%M:%S"))
            last_less_record = less_records[len(less_records) - 1].to_dict()
            last_less_create_time = time.mktime(time.strptime(last_less_record.get("create_time"), "%Y-%m-%d %H:%M:%S"))
            for time_second in range(int(left_time), int(right_time)):
                current_record = None
                second = time_second - int(left_time)
                # 是否上条记录
                is_pre_record = False

                if not pre_record and time_second > int(last_max_create_time):
                    pre_record = last_max_record
                if not pre_record and time_second > int(last_less_create_time):
                    pre_record = last_less_record

                for max_record in max_records:
                    max_record_info = max_record.to_dict()
                    max_record_create_time = time.mktime(
                        time.strptime(max_record_info.get("create_time"), "%Y-%m-%d %H:%M:%S"))
                    if time_second == int(max_record_create_time):
                        current_record = max_record_info

                for less_record in less_records:
                    less_record_info = less_record.to_dict()
                    less_record_create_time = time.mktime(
                        time.strptime(less_record_info.get("create_time"), "%Y-%m-%d %H:%M:%S"))
                    if time_second == int(less_record_create_time):
                        if not current_record:
                            current_record = less_record_info
                        else:
                            current_record["opackets"] = current_record.get("opackets") + less_record_info.get(
                                "opackets")
                            current_record["obytes"] = current_record.get("obytes") + less_record_info.get("obytes")
                            current_record["tx_bps"] = round(current_record["obytes"] / second, 2)
                            current_record["oerrors"] = current_record.get("oerrors") + less_record_info.get("oerrors")

                if not current_record:
                    # 没有匹配的数据，取上一条记录
                    current_record = flow_records_list[len(flow_records_list) - 1]
                    is_pre_record = True
                if not is_pre_record and pre_record:
                    # 上一条记录，不用再加pre_record
                    current_record["opackets"] = current_record.get("opackets") + pre_record.get("opackets")
                    current_record["obytes"] = current_record.get("obytes") + pre_record.get("obytes")
                    current_record["tx_bps"] = round(current_record["obytes"] / second, 2)
                    current_record["oerrors"] = current_record.get("oerrors") + pre_record.get("oerrors")

                # 更正秒数
                current_record["second"] = second
                flow_records_list.append(current_record)
        return flow_records_list
