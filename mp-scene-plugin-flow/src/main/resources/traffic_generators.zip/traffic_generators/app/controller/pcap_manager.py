import os
from app.db import PcapHandler


class PcapManager(object):
    """
    pcap包上传管理
    """

    def flow_path(self, filename, flow_path):
        file_path = os.path.join(flow_path, filename)
        return file_path

    def create_pcap_info(self, data):
        obj = PcapHandler.create_obj(data, "pcap")
        return obj

    def verify_file_path(self, path_name, exclude_uuid=None):
        result = PcapHandler.verify_unique_file_path(path_name, exclude_uuid)
        return result

    def upload_flow_file(self, path_name, file_obj, flow_path):
        file_path = self.flow_path(path_name, flow_path)
        file_obj.save(file_path)
        return path_name

    def update_pcap_info(self, uuid, data):
        obj = PcapHandler.get_obj_by_uuid(uuid)
        obj.update(data)