import json
from datetime import datetime
from logging import getLogger

from app.db import TaskPortManagerHandler
from app.util import status_code as sc
from app.util.constant import TaskAction, TaskPortStatus
from app.util.http_util import resp_message
from .task_manager import TaskManager
from ..tasks.base import TrafficTask


class BatchTaskManager(TaskManager):
    """
    批量任务管理
    """
    log = getLogger('app')

    def v2_task_batch_operation(self):
        """
        任务批量操作
        :param params: 任务操作的一些参数，包含:任务参数，任务的动作，1：开始， 2：停止， 3：暂停， 4 恢复
        :return:
        """
        # 校验参数
        if not self.params:
            return {'code': sc.ParameterError}
        action = self.params.get('action')
        tasks = self.params.get('tasks')
        task_ids = self.params.get('task_ids')
        # 执行方式： 0 串行，1 并行
        run_type = self.params.get('run_type')
        # 传入任务调用时间，防止时区不对，时间对不上
        current_time = self.params.get('time')
        callback_url = "http://10.4.8.12:8001/api/mp/flow/task/refresh_status"

        self.log.info(f"v2 task batch operation params: {self.params}")

        if not action:
            return {'code': sc.MissingRequiredParameter}
        if not str(action).isdigit() or int(action) not in TaskAction.TASK_ACTION_DICT:
            return {'code': sc.TaskActionError}
        if action == TaskAction.start:
            task_ids = [task.get('task_id') for task in tasks]
            if not current_time or not tasks:
                return {'code': sc.MissingRequiredParameter}

        task_port_objs = TaskPortManagerHandler.get_by_task_ids(task_ids)
        if not task_port_objs or len(task_port_objs) == 0:
            self.log.error('v2 stateless tasks {} not exist'.format(task_ids))
            return {'code': sc.NotFound, 'msg': 'flow tasks not exist'}

        if action == TaskAction.start:
            running_tasks = [task_port_obj for task_port_obj in task_port_objs if
                             task_port_obj.status in [TaskPortStatus.running, TaskPortStatus.preparing]]
            if running_tasks and len(running_tasks) > 0:
                self.log.error("tasks is running, please try again later")
                return {'code': sc.TaskNotStopped, 'msg': 'tasks is running, please try again later'}


        for task in tasks:
            tmp_data = json.loads(json.dumps(self.params))
            tmp_data['tasks'] = []
            tmp_data['task'] = task
            tmp_params = json.dumps(tmp_data)
            TaskPortManagerHandler.update_params_by_task_id(tmp_params, task['task_id'])

        # 根据不同的action进行不同的操作
        if int(action) == TaskAction.start:
            # 当前任务状态设为准备中
            self.log.info("async_start_tasks prepare to update task status")
            TaskPortManagerHandler.batch_update_status(TaskPortStatus.preparing, task_ids)
            self.log.info("async_start_tasks loop to process tasks.....")

            # 异步执行调度，需要区分串行和并行
            if run_type == 0:
                self._start_tasks(current_time, tasks, self.single_pool, callback_url)
            else:
                self._start_tasks(current_time, tasks, self.scheduler, callback_url)
        elif int(action) == TaskAction.stop:
            self._stop_tasks(task_ids)

        return resp_message()

    def _start_tasks(self, current_time, tasks, pool, callback_url):
        from manage import app
        with app.app_context():
            from app.tasks.task import v2_send_stl_flow
            server_time_from = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            task_time = datetime.strptime(current_time, "%Y-%m-%d %H:%M:%S")
            for task in tasks:
                task_id = task.get("task_id")
                self.log.info(f"======batch start run task: {task_id}")
                # 新任务启动后，将之前流量记录状态设为失效
                self.update_records_status_by_task_id(task_id)
                self.log.info(f"======update records status of task to invalid: {task_id}")
                # 异步发送流量
                pool.add_task((task_id, v2_send_stl_flow, (task, task_time, server_time_from, callback_url), {}))

    def _stop_tasks(self, task_ids):
        self.log.info("async_stop_tasks loop for run task")
        # FIXME 这里去掉释放锁的逻辑，可能会导致正在启动的任务并发冲突，待优化
        # get_redis_client().release_lock(config.TREX_SERVER_IS_STARTING)
        TaskPortManagerHandler.batch_update_status(TaskPortStatus.stopped, task_ids)
        # 批量停止任务
        for task_id in task_ids:
            if not self.scheduler.cancel_task(task_id):
                # 只有已经调度的任务才需要停止动作，否则，只需要从队列中删除即可
                TrafficTask.kill_task(task_id)
