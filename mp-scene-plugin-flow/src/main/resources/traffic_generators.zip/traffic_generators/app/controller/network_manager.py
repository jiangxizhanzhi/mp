import json
from logging import getLogger

import config
from app.db import TaskPortManagerHandler, TaskPortManagerSchema
from app.util import status_code as sc
from app.util.http_util import resp_message
from app.util.os_util import exec_cmd_on_path
from app.ext import db


class NetworkManager(object):
    """
    网口管理类
    """
    log = getLogger('app')

    @classmethod
    def init_networks(cls, network_infos):
        """
        初始化网口
        """

        for networkInfo in network_infos:
            task_id = networkInfo.get("task_id")
            mac = networkInfo.get("mac")
            target_ip = networkInfo.get("target_ip")
            if not task_id:
                return {'code': sc.NotFound, 'msg': 'task_id can not be empty'}
            if not mac:
                return {'code': sc.NotFound, 'msg': 'mac can not be empty'}
            if not target_ip:
                return {'code': sc.NotFound, 'msg': 'target_ip can not be empty'}

            exist_task_ports = TaskPortManagerHandler.get_all_by_mac(mac)

            task_port = None
            port_num = None

            if exist_task_ports:
                # 遍历查找已经存在的任务网口关系
                for task_port_obj in exist_task_ports:
                    port_num = task_port_obj.to_dict().get("port_num")
                    if task_id == task_port_obj.to_dict().get("task_id"):
                        task_port = task_port_obj.to_dict()
                        task_port_obj.target_ip = target_ip
                        task_port_obj.mac = mac

                        res = exec_cmd_on_path('sudo -S ./dpdk_nic_bind.py -s --json', config.DPDK_PATH)
                        res = json.loads(res)
                        port_name = None
                        for info in res:
                            if mac == res[info]['MAC']:
                                port_name = res[info]['Interface']
                        if not port_name:
                            cls.log.error(f"{mac} is not exist")
                            return resp_message(code=sc.MacNotExist)
                        task_port_obj.port_name = port_name
                        TaskPortManagerHandler.save(task_port_obj)

            if not task_port:
                # 不存在，则新增
                res = exec_cmd_on_path('sudo -S ./dpdk_nic_bind.py -s --json', config.DPDK_PATH)
                res = json.loads(res)
                port_name = None
                for info in res:
                    if mac == res[info]['MAC']:
                        port_name = res[info]['Interface']
                if not port_name:
                    cls.log.error(f"{mac} is not exist")
                    return resp_message(code=sc.MacNotExist)

                if not port_num:
                    max_port_num = TaskPortManagerHandler.get_max_port_num()
                    port_num = max_port_num + 1
                task_port = {
                    "task_id": task_id,
                    "port_name": port_name,
                    "port_num": port_num,
                    "target_ip": target_ip,
                    "mac": mac
                }
                response, error = TaskPortManagerSchema().load(task_port, session=db.session)
                if error:
                    cls.log.error(error)
                    return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
                TaskPortManagerHandler.save(response)

        return resp_message()
