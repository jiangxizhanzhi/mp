from logging import getLogger

from app.db import TaskPortManagerHandler
from app.ext import cache


class OpsManager(object):
    """
    运维管理类
    """
    log = getLogger('app')

    @classmethod
    def get_protocols_top5(cls):
        from manage import app
        with app.app_context():
            protocols_dict = {}
            running_tasks = TaskPortManagerHandler.get_running_tasks()
            task_ids = list(set(task.task_id for task in running_tasks))
            # task_info.info(f"get protocols top5 task_ids: {task_ids}")
            total = 1
            if task_ids and len(task_ids) > 0:
                for task_id in task_ids:
                    protocl_num = cache.get("PROTOCOLS::" + task_id)
                    if protocl_num is None:
                        continue
                    for protocol, num in protocl_num.items():
                        # key = str(protocol, 'utf-8')
                        key = protocol
                        total = total + round(num)
                        if key in protocols_dict:
                            protocols_dict[key] = protocols_dict[key] + round(num)
                        else:
                            protocols_dict[key] = round(num)

            for key in protocols_dict:
                protocols_dict[key] = round(protocols_dict[key] * 100 // total)

            # 降序排列
            sorted_items = sorted(protocols_dict.items(), key=lambda x: x[1], reverse=True)
            # 取前5个值
            top5_items = [{'protocol': key, 'rate': value} for key, value in sorted_items[:5]]

            # 计算总和
            if top5_items and len(top5_items) > 0:
                total_sum = sum(item['rate'] for item in top5_items)
                if total_sum != 100:
                    # 计算缺少的值
                    missing_value = 100 - total_sum
                    # 将缺少的值添加到第一个中
                    top5_items[0]['rate'] += missing_value
                cls.log.info(f"get protocols top5 items: {top5_items}")

            return top5_items
