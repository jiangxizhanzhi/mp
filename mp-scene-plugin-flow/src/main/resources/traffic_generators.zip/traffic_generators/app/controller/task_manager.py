from datetime import datetime
from logging import getLogger

import config
from app.db import TaskPortManagerHandler, TaskFlowRecordsHandler, TaskAttackFlowRecordsHandler
from app.tasks.base import TrafficTask
from app.util import status_code as sc
from app.util.constant import TaskAction, TaskPortStatus
from app.util.http_util import resp_message
from app.util.pool import AsyncTaskScheduler


class TaskManager(object):
    """
    任务管理器
    """
    log = getLogger('app')
    # 异步调度器
    scheduler = AsyncTaskScheduler(max_workers=config.MAX_FLOW_TASK_NUM)
    scheduler.start()
    # 特殊调度器，用于执行串行任务
    single_pool = AsyncTaskScheduler(max_workers=1)
    single_pool.start()

    def __init__(self, params):
        self.params = params

    def v2_task_operation(self):
        """
        任务操作
        :param params: 任务操作的一些参数，包含:任务参数，任务的动作，1：开始， 2：停止， 3：暂停， 4 恢复
        :return:
        """
        # 校验参数
        if not self.params:
            return {'code': sc.ParameterError}
        action = self.params.get('action')
        task = self.params.get('task')
        run_type = self.params.get('run_type')
        # 传入任务调用时间，防止时区不对，时间对不上
        current_time = self.params.get('time')
        task_id = self.params.get('task_id')
        callback_url = "http://10.4.8.12:8001/api/mp/flow/task/refresh_status"

        self.log.info(f"get params for task_id {task_id} , task operation params: {self.params}")

        if not action:
            return {'code': sc.MissingRequiredParameter}
        if not str(action).isdigit() or int(action) not in TaskAction.TASK_ACTION_DICT:
            return {'code': sc.TaskActionError}
        if action == TaskAction.start:
            task_id = task.get('task_id')
            if not task or not current_time or not task_id:
                return {'code': sc.MissingRequiredParameter}
        if action == TaskAction.stop and not task_id:
            return {'code': sc.MissingRequiredParameter}

        task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
        if not task_port_obj:
            self.log.error(f"v2 stateless task {task_id} not exist")
            return {'code': sc.NotFound, 'msg': 'flow task not exist'}

        if (action == TaskAction.start) and (
                task_port_obj.status == TaskPortStatus.running or task_port_obj.status == TaskPortStatus.preparing):
            self.log.error(f"task is running, please try again later")
            return {'code': sc.TaskNotStopped, 'msg': 'task is running, please try again later'}

        if current_time:
            task_time = datetime.strptime(current_time, "%Y-%m-%d %H:%M:%S")
        # 根据不同的action进行不同的操作
        if int(action) == TaskAction.start:
            self.log.info(f"try to start task {task_id}")
            server_time_from = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            # 当前任务状态设为准备中
            self.log.info(f"update params and preparing status for task {task_id}")
            TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.preparing, task_id)
            TaskPortManagerHandler.update_params_by_task_id(f"{self.params}", task_id)
            # 新任务启动后，将之前流量记录状态设为失效
            self.log.info(f"update flow record status and attack flow record status for task {task_id}")
            self.update_records_status_by_task_id(task_id)

            # 异步发送流量
            from app.tasks.task import v2_send_stl_flow
            self.log.info(f"try to send flow for {task_id} async")
            self.scheduler.add_task((task_id, v2_send_stl_flow, (task, task_time, server_time_from, callback_url), {}))

        elif int(action) == TaskAction.stop:
            # 停止任务
            return TrafficTask.kill_task(task_id)
        return resp_message()


    @classmethod
    def update_records_status_by_task_id(cls, task_id):
        """
        更新任务的状态为1
        """
        TaskFlowRecordsHandler.batch_update_records_status(1, task_id)
        TaskAttackFlowRecordsHandler.batch_update_records_status(1, task_id)
