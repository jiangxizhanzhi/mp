# -*- coding: utf-8 -*-
import atexit
import fcntl
from threading import Thread

from flask import Flask
from flask_migrate import MigrateCommand
from flask_script import Manager
from werkzeug.routing import BaseConverter

import config
import os
from app.api import flow_blueprint
from app.db import TaskPortManagerHandler
from app.ext import init_extension, db
from app.util.constant import TaskPortStatus


class RegexConverter(BaseConverter):

    def __init__(self, url_map, *items):
        super(RegexConverter, self).__init__(url_map)
        self.regex = items[0]

def create_app(env_name):
    app = Flask(__name__, static_folder='media')
    app.config.from_object(config.profiles.get(env_name))
    app.url_map.converters['regex'] = RegexConverter
    app.register_blueprint(flow_blueprint, url_prefix='/api/v1')

    init_extension(app=app)
    manager = Manager(app=app)
    manager.add_command('db', MigrateCommand)
    return app, manager


app, manager = create_app('product')

def reset_env():
    # 创建数据库表（可选）
    with app.app_context():
        db.create_all()

    from utils.reload_trex import kill_processes
    # 清理trex任务
    kill_processes("trex_")


reset_env()

@app.before_first_request
def before_first_request():
    from logging import getLogger
    log = getLogger("app")
    log.info(f"start_log: find terminated tasks to restart when server start")
    tasks = TaskPortManagerHandler.get_running_tasks()
    log.info(f"start_log: find {len(tasks)} tasks to restart ")
    if len(tasks)>0:
        from app.controller.task_manager import TaskManager
        for task in tasks:
            log.info(f"{task.task_id} to restart")
            TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.stopped, task.task_id)
            TaskManager(eval(task.params)).v2_task_operation()


if __name__ == '__main__':
    os.system("mv /usr/local/lib/python3.6/dist-packages/scapy /usr/local/lib/python3.6/dist-packages/scapy.bak")
    os.system("cp -r /opt/project_dirs/traffic_generators/external/scapy /usr/local/lib/python3.6/dist-packages/scapy")
    manager.run()
