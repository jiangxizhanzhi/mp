# -*- coding: utf-8 -*-
import os
import sys
from datetime import timedelta
from logging.config import dictConfig

from marshmallow import fields

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_BASE_DIR = BASE_DIR + '/log'

# 日志相关配置
log_dict = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '%(levelname)s %(asctime)s [%(threadName)s] %(module)s:%(lineno)d --- %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'console': {'class': 'logging.StreamHandler', },
        'logfile': {'class': 'cloghandler.ConcurrentRotatingFileHandler',
                    'filename': os.path.join(LOG_BASE_DIR, 'flask.log'),
                    'formatter': 'standard', 'delay': True, 'maxBytes': 1024 * 1024 * 10, 'backupCount': 30},

    },

    'root': {'level': 'INFO', 'handlers': ['logfile', 'console']},
    'loggers': {}
}

# 在log_loggers = ['check', 'patch']中添加日志文件名  logging.get_logger()获取的logger名称同上
# 如果logging.getlogger()字符串不在log_loggers内, 将不会创建出日志文件记录日志
log_loggers = ['app', 'ws']

for i in log_loggers:
    log_dict['handlers'][i] = {'class': 'cloghandler.ConcurrentRotatingFileHandler',
                               'filename': os.path.join(LOG_BASE_DIR, '%s.log' % i),
                               'formatter': 'standard', 'delay': True, 'maxBytes': 1024 * 1024 * 10, 'backupCount': 30}
    log_dict['loggers'][i] = {'handlers': [i, 'console']}


class Config:
    """
    Flask应用配置
    """

    DEBUG = False

    SECRET_KEY = "110affdfghrwwqcbnyy"
    SESSION_TYPE = 'null'

    # flask_security 加密
    SECURITY_PASSWORD_SALT = 'fhasdgihwntlgy8f'

    # cache
    CACHE_TYPE = 'simple'
    CACHE_KEY_PREFIX = 'FLOW_'
    CACHE_DEFAULT_TIMEOUT = 60 * 2

    # 设置为False以禁用所有CSRF保护
    WTF_CSRF_ENABLED = False

    # sqlalchemy相关
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + BASE_DIR + '/traffic.db'
    # 如果设置成 True (默认情况)，Flask-SQLAlchemy 将会追踪对象的修改并且发送信号
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # Defaults True

    # 全局文件上传的大小限制
    MAX_CONTENT_LENGTH = 1024 * 1024 * 1024 * 2
    # 文件上传位置
    UPLOADS_DEFAULT_DEST = os.path.join(BASE_DIR, 'media/')
    SEND_FILE_MAX_AGE_DEFAULT = timedelta(seconds=1)


class ProductConfig(Config):
    """
    产品环境配置
    """
    DEBUG = False


profiles = {
    "product": ProductConfig,
}

# trex服务的端口选择范围
TREX_PORT_START = 10000
TREX_PORT_END = 65530

# pcap文件存放路径
PCAP_PATH = os.path.join(BASE_DIR, "media/pcap")
# 运行攻击脚本镜像的脚本存放路径
RUN_IMAGE_SCRIPTS_PATH = os.path.join(BASE_DIR, 'media/run_images_scripts')

#  marshmallow文字默认值
fields.Field.default_error_messages = {
    'required': u'缺少必填数据.',
    'type': u'数据类型不合法.',
    'null': u'数据不能为空.',
    'validator_failed': u'非法数据.'
}
fields.Str.default_error_messages = {
    'invalid': '不是合法文本.'
}
fields.Int.default_error_messages = {
    'invalid': u'不是合法整数.'
}
fields.Number.default_error_messages = {
    'invalid': u'不是合法数字.'
}
fields.Boolean.default_error_messages = {
    'invalid': u'不是合法布尔值.'
}

# 在导入模块路径里加上trex服务模块路径
TREX_CLIENT_PATH = "/opt/v2.88/trex_client"
TREX_PATH = "/opt/v2.88/trex_client/interactive"
TREX_DAEMON_PATH = "/opt/v2.88/automation"
TREX_SERVER_PRE_NAME = "trex_"
sys.path.append(TREX_CLIENT_PATH)
sys.path.append(TREX_PATH)
sys.path.append(TREX_DAEMON_PATH)

# 服务器密码
PASSWORD = ""
DPDK_PATH = "/opt/v2.88"
TREX_HOST = "127.0.0.1"

TREX_DAEMON_SERVER_PORT_NAME = 'TREX_DAEMON_SERVER_PORT'
# 缓存前缀，存储背景流量或攻击流量任务的状态刷新线程
RUNNING_STATUS_THREAD = "RUNNING_STATUS:"
# 缓存前缀，存储流量发送任务的异步调度线程
RUNNING_FLOW_THREAD = "RUNNING_FLOW_THREAD:"
TREX_DAEMON_PORT_CACHE = 'TREX_DAEMON_PORT_CACHE'

# 最大支持多少个流量任务并发
MAX_FLOW_TASK_NUM = 15

# 本地化 config.py, 若存在local_config.py 则在项目启动时尝试读取本地配置文件
try:
    from local_config import *
except ImportError:
    pass

if __name__ == 'config':
    # 加载本地环境创建日志文件夹 创建日志文件
    if not os.path.exists(LOG_BASE_DIR):
        os.makedirs(LOG_BASE_DIR)
    dictConfig(log_dict)
