####  项目打包
1.  首先打包项目,排除git文件
2.   cd traffic_generators
     echo "Git-Repo-Url: $(git remote get-url origin)" >> traffic_generators/versionG.txt
     echo "Git-Branch: $(git rev-parse --abbrev-ref HEAD)" >> traffic_generators/versionG.txt
     echo "Git-Commit-Id: $(git rev-parse HEAD)" >> traffic_generators/versionG.txt
     echo "Git-Commit-Message: $(git log -1 --pretty=%B)" >> traffic_generators/versionG.txt
     tar -zcvf traffic_generators.tar.gz traffic_generators --exclude=traffic_generators/.git  

####  运维使用
# 所需资源
1.  服务器系统版本： ubuntu-18.04.3-server-amd64 LTS 
2.  项目文件压缩包： traffic_generators.tar.gz
# 执行步骤
1.  安装操作系统
2.  拷贝traffic_generators.tar.gz 到服务器/opt/project_dirs目录下
3.  解压traffic_generators.tar.gz
4.	进入到解压后的文件夹setup目录下，root下执行online_traffic_generators.sh
5.	部署完成后supervisorctl  status看下服务状态，如果不是running则执行supervisorctl  restart  all
