/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.33.182
 Source Server Type    : MySQL
 Source Server Version : 50733
 Source Host           : localhost:3306
 Source Schema         : FLOW

 Target Server Type    : MySQL
 Target Server Version : 50733
 File Encoding         : 65001

 Date: 03/09/2021 10:44:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `parent_id` int(11) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cfg_flow
-- ----------------------------
DROP TABLE IF EXISTS `cfg_flow`;
CREATE TABLE `cfg_flow`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `profile` json NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cfg_networkstructures
-- ----------------------------
DROP TABLE IF EXISTS `cfg_networkstructures`;
CREATE TABLE `cfg_networkstructures`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `ip_versions` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `dut_role` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `dut_mode` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `network_config` json NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cfg_profile
-- ----------------------------
DROP TABLE IF EXISTS `cfg_profile`;
CREATE TABLE `cfg_profile`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cfg_stream
-- ----------------------------
DROP TABLE IF EXISTS `cfg_stream`;
CREATE TABLE `cfg_stream`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `profile_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `packet` json NULL,
  `mode` json NULL,
  `enabled` tinyint(1) NULL DEFAULT NULL,
  `self_start` tinyint(1) NULL DEFAULT NULL,
  `isg` float NULL DEFAULT NULL,
  `flow_stats` json NULL,
  `next` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `action_count` int(11) NULL DEFAULT NULL,
  `random_seed` int(11) NULL DEFAULT NULL,
  `vm` json NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for custom_task
-- ----------------------------
DROP TABLE IF EXISTS `custom_task`;
CREATE TABLE `custom_task`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `duration` int(11) NULL DEFAULT NULL,
  `network_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `configuration_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `latency_pps` int(11) NULL DEFAULT NULL,
  `multiplier` int(11) NULL DEFAULT NULL,
  `ipv6` tinyint(1) NULL DEFAULT NULL,
  `nc` tinyint(1) NULL DEFAULT NULL,
  `block` tinyint(1) NULL DEFAULT NULL,
  `pid_input` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `force` tinyint(1) NULL DEFAULT NULL,
  `tag_id` int(11) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for file_resources
-- ----------------------------
DROP TABLE IF EXISTS `file_resources`;
CREATE TABLE `file_resources`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `is_default` int(11) NULL DEFAULT NULL,
  `file_path` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `image_type` int(11) NULL DEFAULT NULL,
  `run_image_script_path` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `run_cmd` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `get_result_cmd` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tag_id` int(11) NULL DEFAULT NULL,
  `category_id` int(11) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for license
-- ----------------------------
DROP TABLE IF EXISTS `license`;
CREATE TABLE `license`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `value` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pcap_manager
-- ----------------------------
DROP TABLE IF EXISTS `pcap_manager`;
CREATE TABLE `pcap_manager`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `file_path` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tag_id` int(11) NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `category_id` int(11) NULL DEFAULT NULL,
  `built_in` tinyint(1) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for port_manager
-- ----------------------------
DROP TABLE IF EXISTS `port_manager`;
CREATE TABLE `port_manager`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `port` int(11) NULL DEFAULT NULL,
  `ip` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `target_ip` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `is_manager` int(11) NULL DEFAULT NULL,
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `task_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `pci` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `mac` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `broadcast` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `netmask` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `port_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for rfc_result
-- ----------------------------
DROP TABLE IF EXISTS `rfc_result`;
CREATE TABLE `rfc_result`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `rfc_task_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `round` int(11) NOT NULL,
  `frame_length` int(11) NOT NULL,
  `max_rate` float NULL DEFAULT NULL,
  `min_rate` float NULL DEFAULT NULL,
  `transmit_packets` int(11) NULL DEFAULT NULL,
  `receive_packets` int(11) NULL DEFAULT NULL,
  `result` float NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for rfc_task
-- ----------------------------
DROP TABLE IF EXISTS `rfc_task`;
CREATE TABLE `rfc_task`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `rounds` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `payload_mode` json NOT NULL,
  `network_config` json NOT NULL,
  `frame_length` json NOT NULL,
  `source_port` int(11) NOT NULL,
  `dst_port` int(11) NOT NULL,
  `source_ip` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dst_ip` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `source_mac` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `dst_mac` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `result` json NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for standard_task
-- ----------------------------
DROP TABLE IF EXISTS `standard_task`;
CREATE TABLE `standard_task`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `config` json NULL,
  `port` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `target_ip` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `source_ip` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` int(11) NULL DEFAULT NULL,
  `file_resource_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for system_resources
-- ----------------------------
DROP TABLE IF EXISTS `system_resources`;
CREATE TABLE `system_resources`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cpus` int(11) NULL DEFAULT NULL,
  `cpus_used_percent` float NULL DEFAULT NULL,
  `memory` int(11) NULL DEFAULT NULL,
  `memory_used_percent` float NULL DEFAULT NULL,
  `disk` int(11) NULL DEFAULT NULL,
  `disk_used` int(11) NULL DEFAULT NULL,
  `disk_free` int(11) NULL DEFAULT NULL,
  `disk_used_percent` float NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tag
-- ----------------------------
DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for task_result
-- ----------------------------
DROP TABLE IF EXISTS `task_result`;
CREATE TABLE `task_result`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `task_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  `status_detail` json NULL,
  `result` int(11) NULL DEFAULT NULL,
  `result_detail` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `start_time` datetime(0) NULL DEFAULT NULL,
  `end_time` datetime(0) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for task_set
-- ----------------------------
DROP TABLE IF EXISTS `task_set`;
CREATE TABLE `task_set`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tasks` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tmp_pcap
-- ----------------------------
DROP TABLE IF EXISTS `tmp_pcap`;
CREATE TABLE `tmp_pcap`  (
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `capture_id` int(11) NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `rx_port` int(11) NULL DEFAULT NULL,
  `tx_port` int(11) NULL DEFAULT NULL,
  `filter` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `limit` int(11) NULL DEFAULT NULL,
  `status` int(11) NULL DEFAULT NULL,
  `start_time` datetime(0) NULL DEFAULT NULL,
  `end_time` datetime(0) NULL DEFAULT NULL,
  `pcap_path` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `task_uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flow_records
-- ----------------------------
DROP TABLE IF EXISTS `flow_records`;
CREATE TABLE `flow_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_uuid` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '任务id',
  `group_count` int(11) NOT NULL COMMENT '执行次数分组，相同表示同一次流量发生产生的数据',
  `second` int(11) NOT NULL COMMENT '秒数',
  `opackets` int(11) NOT NULL DEFAULT '0' COMMENT '发包数量',
  `obytes` bigint(16) NOT NULL DEFAULT '0' COMMENT '发包大小 单位byte',
  `tx_bps` double(16,2) NOT NULL DEFAULT '0.00' COMMENT '发包速率(单位byte/s)',
  `oerrors` int(11) NOT NULL DEFAULT '0' COMMENT '发包异常数量',
  `tx_pps` bigint(20) NOT NULL DEFAULT '0' COMMENT '实时发包数',
  `latency` bigint(20) NOT NULL DEFAULT '0' COMMENT '延迟(单位ms)',
  `jitter` bigint(20) NOT NULL DEFAULT '0' COMMENT '抖动(单位ms)',
  `total_tx_L2` double(16,2) NOT NULL DEFAULT '0' COMMENT '发送速率L2(单位byte/s)',
  `total_tx_L1` double(16,2) NOT NULL DEFAULT '0' COMMENT '发送速率L1(单位byte/s)',
  `total_rx` double(16,2) NOT NULL DEFAULT '0' COMMENT '接收速率(单位byte/s)',
  `queue_full` bigint(20) NOT NULL DEFAULT '0' COMMENT '阻塞队列大小(单位byte)',
  `drop_rate` double(16,2) NOT NULL DEFAULT '0' COMMENT '丢包率(单位byte/s)',
  `status` int(2) NOT NULL DEFAULT '0' COMMENT '状态：0 有效，1失效',
  `record_time` datetime NOT NULL COMMENT '发包时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for attack_flow_records
-- ----------------------------
DROP TABLE IF EXISTS `attack_flow_records`;
CREATE TABLE `attack_flow_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_uuid` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '任务id',
  `group_count` int(11) NOT NULL COMMENT '执行次数分组，相同表示同一次流量发生产生的数据',
  `second` int(11) NOT NULL COMMENT '秒数',
  `opackets` int(11) NOT NULL DEFAULT '0' COMMENT '发包数量',
  `obytes` bigint(16) NOT NULL DEFAULT '0' COMMENT '发包大小 单位byte',
  `tx_bps` double(16,2) NOT NULL DEFAULT '0.00' COMMENT '发包速率',
  `oerrors` int(11) NOT NULL DEFAULT '0' COMMENT '发包异常数量',
  `tx_pps` bigint(20) NOT NULL DEFAULT '0' COMMENT '实时发包数',
  `latency` bigint(20) NOT NULL DEFAULT '0' COMMENT '延迟(单位ms)',
  `jitter` bigint(20) NOT NULL DEFAULT '0' COMMENT '抖动(单位ms)',
  `total_tx_L2` double(16,2) NOT NULL DEFAULT '0' COMMENT '发送速率L2(单位byte/s)',
  `total_tx_L1` double(16,2) NOT NULL DEFAULT '0' COMMENT '发送速率L1(单位byte/s)',
  `total_rx` double(16,2) NOT NULL DEFAULT '0' COMMENT '接收速率(单位byte/s)',
  `queue_full` bigint(20) NOT NULL DEFAULT '0' COMMENT '阻塞队列大小(单位byte)',
  `drop_rate` double(16,2) NOT NULL DEFAULT '0' COMMENT '丢包率(单位byte/s)',
  `packets_sent` int(11) NOT NULL DEFAULT '0' COMMENT '总发包数量',
  `bytes_sent` bigint(16) NOT NULL DEFAULT '0' COMMENT '总发包大小 单位byte',
  `errout` int(11) NOT NULL DEFAULT '0' COMMENT '总发包异常数量',
  `status` int(2) NOT NULL DEFAULT '0' COMMENT '状态：0 有效，1失效',
  `record_time` datetime NOT NULL COMMENT '发包时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;


-- ----------------------------
-- Table structure for task_port_manager
-- ----------------------------
DROP TABLE IF EXISTS `task_port_manager`;
CREATE TABLE `task_port_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '任务id',
  `status` int(2) DEFAULT 0 COMMENT '任务状态: 0 初始化，1 运行中，2 异常， 3 已停止，4 暂停，5 准备中',
  `port_name` varchar(12) COLLATE utf8_bin NOT NULL COMMENT '网口名称',
  `port_num` int(3) NOT NULL COMMENT '网口编号，从0开始',
  `mac` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'mac地址',
  `msg` varchar(1024) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '信息',
  `target_ip` varchar(64) COLLATE utf8_bin NOT NULL COMMENT '目标机器ip地址',
  `params` varchar(2048) COLLATE utf8_bin NOT NULL COMMENT '运行参数',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;


SET FOREIGN_KEY_CHECKS = 1;





-- 数据库清理脚本
DELETE from attack_flow_records;
DELETE from custom_task;
DELETE from file_resources;
DELETE from flow_records;
DELETE from pcap_manager;
DELETE from port_manager;
DELETE from standard_task;
DELETE from task_result;
DELETE from task_port_manager;
