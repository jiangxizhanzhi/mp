#!/usr/bin/env bash
## 编译nginx-upload-module
mkdir /nginx
mkdir /var/log/nginx
touch /var/log/nginx/access.log
cp /opt/project_dirs/traffic_generators/setup/nginx-1.10.2.tar.gz /nginx
cp /opt/project_dirs/traffic_generators/setup/nginx-upload-module.tar.gz /nginx
cp /opt/project_dirs/traffic_generators/setup/openssl-1.0.2j.tar.gz /nginx
cp /opt/project_dirs/traffic_generators/setup/pcre-8.40.tar.gz /nginx
cp /opt/project_dirs/traffic_generators/setup/zlib-1.2.11.tar.gz /nginx
cd /nginx
tar -zxf nginx-1.10.2.tar.gz
tar -zxf nginx-upload-module.tar.gz
tar -zxf openssl-1.0.2j.tar.gz
tar -zxf pcre-8.40.tar.gz
tar -zxf zlib-1.2.11.tar.gz

#cp /opt/project_dirs/traffic_generators/setup/Makefile /nginx/nginx-1.10.2/objs
cd nginx-1.10.2
./configure --add-module=../nginx-upload-module --with-openssl=../openssl-1.0.2j \
--with-http_gzip_static_module --with-http_ssl_module --with-pcre=../pcre-8.40 --with-zlib=../zlib-1.2.11
sed -i 's|-Werror||' objs/Makefile
make -j && make install
