#!/usr/bin/env bash

cd /home

# 拷贝文件夹到指定目录
mkdir -p /opt/project_dirs
tar -zxvf /home/Packages.tar.gz
mv /home/Packages /var
mv /home/Project/traffic_generators /opt/project_dirs/
mv /home/site-packages /var

# 修改仓库源
mv /etc/apt/sources.list /etc/apt/sources.list.bak
echo "deb file:/var/Packages ./" > /etc/apt/sources.list
cd /var/Packages
apt update --allow-insecure-repositories
echo "---------------------------------------------------------------------------------------------"

## 安装基础软件
apt-get  install -y gcc --allow-unauthenticated
apt-get  install -y g++ --allow-unauthenticated
apt-get  install -y cmake --allow-unauthenticated
apt-get  install -y python3.6-dev --allow-unauthenticated
apt-get  install -y python3-pip --allow-unauthenticated
apt-get  install -y python3-distutils --allow-unauthenticated
apt-get  install -y supervisor --allow-unauthenticated
apt-get  install -y redis-server --allow-unauthenticated
apt-get  install -y mysql-server mysql-common mysql-client --allow-unauthenticated
apt-get  install -y dos2unix --allow-unauthenticated
apt-get  install -y zip --allow-unauthenticated
apt-get install -y openvswitch-switch --allow-unauthenticated
echo "---------------------------------------------------------------------------------------------"

## 更新supervisor、mysql配置文件
dos2unix /opt/project_dirs/traffic_generators/setup/setup_mysql_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_mysql_conf.sh

dos2unix /opt/project_dirs/traffic_generators/setup/setup_supervisor_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_supervisor_conf.sh
echo "---------------------------------------------------------------------------------------------"

# 安装python3包
# 项目
cd /var/site-packages
pip3 install --no-index -r /opt/project_dirs/traffic_generators/requirements.txt  --find-links=/var/site-packages
echo "---------------------------------------------------------------------------------------------"

## 初始化数据库
mysql -e "
CREATE USER 'cyberpeace'@'localhost' IDENTIFIED BY '6CzZt1GUyIWmBJqS';
CREATE DATABASE FLOW DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
GRANT ALL PRIVILEGES ON FLOW.* TO 'cyberpeace'@'localhost';
"
mysql -ucyberpeace -p6CzZt1GUyIWmBJqS -DFLOW < /opt/project_dirs/traffic_generators/setup/FLOW.sql
mysql -ucyberpeace -p6CzZt1GUyIWmBJqS -DFLOW < /opt/project_dirs/traffic_generators/setup/pcap_manager.sql
echo "---------------------------------------------------------------------------------------------"

systemctl restart mysql
supervisorctl reload
supervisorctl restart all
echo "---------------------------------------------------------------------------------------------"

## 配置trex
dos2unix /opt/project_dirs/traffic_generators/setup/setup_trex_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_trex_conf.sh
echo "---------------------------------------------------------------------------------------------"

## 编译nginx—upload-module 和配置nginx
dos2unix /opt/project_dirs/traffic_generators/setup/setup_nginx_upload.sh
dos2unix /opt/project_dirs/traffic_generators/setup/setup_nginx_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_nginx_upload.sh &> nginx.log
bash /opt/project_dirs/traffic_generators/setup/setup_nginx_conf.sh
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/traffic_generator.conf
echo "---------------------------------------------------------------------------------------------"

