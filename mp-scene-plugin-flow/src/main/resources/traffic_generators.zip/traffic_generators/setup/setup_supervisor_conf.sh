#!/usr/bin/env bash
touch /etc/supervisor/conf.d/traffic_generators.conf
cat <<"EOF" > /etc/supervisor/conf.d/traffic_generators.conf
[program:traffic_generators]
#command=/usr/local/bin/gunicorn -c gunicorn.py manage:app
command=python3 ./manage.py runserver -h0.0.0.0 -p5001
directory=/opt/project_dirs/traffic_generators
autostart=true
autorestart=true
[supervisord]
nodaemon=no
[supervisorctl]
stdout_logfile=/var/log/supervisor/traffic_generators.log
EOF
