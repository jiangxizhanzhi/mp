# traffic_generators

基于trex开发的流量发生器项目

# 运行环境
- python3.6.9
- setuptools==39.0.1