import config
redis_config = config.redis_config

CELERY_RESULT_BACKEND = 'redis://:%s@127.0.0.1:6379/5' % redis_config.get('session_password')
BROKER_URL = 'redis://:%s@127.0.0.1:6379/6' % redis_config.get('session_password')

CELERY_TIMEZONE = 'Asia/Shanghai'

# 每个worker最多执行50个任务就会被销毁，可防止内存泄露
# 数量过少会报155错误 据github在celery4.40版本已修复 为更新celery版本测试
CELERYD_MAX_TASKS_PER_CHILD = 100
