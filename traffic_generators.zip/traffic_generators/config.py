# -*- coding: utf-8 -*-
import os
import sys
from cloghandler import ConcurrentRotatingFileHandler
from datetime import timedelta
from logging.config import dictConfig
from marshmallow import fields
from redis import Redis

# reids配置
redis_config = {
    'session_host': 'localhost', 'session_port': '6379', 'session_db': 1,
    'session_user': '', 'session_password': '',
    'cache_host': 'localhost', 'cache_port': '6379', 'cache_db': 2,
    'cache_user': '', 'cache_password': ''
}

# mysql配置
mysql_config = {
    'host': 'localhost', 'port': '3306',
    'user': 'cyberpeace', 'password': '6CzZt1GUyIWmBJqS',
    'db': 'FLOW'
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_BASE_DIR = BASE_DIR + '/log'

log_dict = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '%(levelname)s %(asctime)s %(module)s:%(lineno)d --- %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'console': {'class': 'logging.StreamHandler', },
        'logfile': {'class': 'cloghandler.ConcurrentRotatingFileHandler',
                    'filename': os.path.join(LOG_BASE_DIR, 'flask.log'),
                    'formatter': 'standard', 'delay': True, 'maxBytes': 1024 * 1024 * 10, 'backupCount': 30},

    },

    'root': {'level': 'INFO', 'handlers': ['logfile', 'console']},
    'loggers': {}
}

# 在log_loggers = ['check', 'patch']中添加日志文件名  logging.get_logger()获取的logger名称同上
# 如果logging.getlogger()字符串不在log_loggers内, 将不会创建出日志文件记录日志
log_loggers = ['error', 'info', 'conf_error', 'conf_info', 'monitor_error', 'monitor_info', 'resource_error',
               'resource_info', 'software_error', 'software_info', 'task_error', 'task_info', 'celery_log']

for i in log_loggers:
    log_dict['handlers'][i] = {'class': 'cloghandler.ConcurrentRotatingFileHandler',
                               'filename': os.path.join(LOG_BASE_DIR, '%s.log' % i),
                               'formatter': 'standard', 'delay': True, 'maxBytes': 1024 * 1024 * 10, 'backupCount': 30}
    log_dict['loggers'][i] = {'handlers': [i, 'console']}


class Config:
    DEBUG = False

    SECRET_KEY = "110affdfghrwwqcbnyy"
    SESSION_TYPE = 'redis'
    SESSION_REDIS = Redis(host=redis_config.get('session_host'),
                          port=int(redis_config.get('session_port')),
                          db=redis_config.get('session_db'),
                          password=redis_config.get('session_password'))

    # flask_security 加密
    SECURITY_PASSWORD_SALT = 'fhasdgihwntlgy8f'

    # cache
    CACHE_TYPE = 'redis'
    CACHE_KEY_PREFIX = 'FLOW_'
    CACHE_DEFAULT_TIMEOUT = 60 * 2
    CACHE_REDIS_URL = 'redis://:%s@%s:%s/%s' % (redis_config.get('cache_password'),
                                                redis_config.get('cache_host'),
                                                redis_config.get('cache_port'),
                                                redis_config.get('cache_db'))

    # 设置为False以禁用所有CSRF保护
    WTF_CSRF_ENABLED = False

    # sqlalchemy相关
    # 如果设置成 True (默认情况)，Flask-SQLAlchemy 将会追踪对象的修改并且发送信号
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # Defaults True
    SQLALCHEMY_POOL_SIZE = 2000
    # SQLALCHEMY_ECHO = True

    # 全局文件上传的大小限制
    MAX_CONTENT_LENGTH = 1024 * 1024 * 1024 * 2
    # 文件上传位置
    UPLOADS_DEFAULT_DEST = os.path.join(BASE_DIR, 'media/')
    SEND_FILE_MAX_AGE_DEFAULT = timedelta(seconds=1)


class ProductConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://%s:%s@%s:%s/%s' % (
        mysql_config.get('user'), mysql_config.get('password'),
        mysql_config.get('host'), mysql_config.get('port'),
        mysql_config.get('db')
    )


contest_config = {
    "product": ProductConfig,
}

PROFILE_FILE_SIZE = 1024 * 1024 * 1
# 恶意文件大小
SCRIPT_FILE_SIZE = 1024 * 1024 * 10

# trex服务的端口选择范围
TREX_PORT_START = 10000
TREX_PORT_END = 65530

# pcap文件存放路径
PCAP_PATH = os.path.join(BASE_DIR, "media/pcap")
# 恶意文件存放路径
SCRIPTS_PATH = os.path.join(BASE_DIR, 'media/scripts')
# 攻击脚本镜像存放路径
IMAGE_PATH = os.path.join(BASE_DIR, 'media/images')
# 默认镜像存放路径
DEFAULT_PATH = os.path.join(BASE_DIR, 'media/images/ubuntu.tar')
# 运行攻击脚本镜像的脚本存放路径
RUN_IMAGE_SCRIPTS_PATH = os.path.join(BASE_DIR, 'media/run_images_scripts')
# 抓取的流量包存放路径
TMP_PATH = os.path.join(BASE_DIR, 'media/tmp')
# stf yaml文件存放路径
STF_CFG_PATH = os.path.join(BASE_DIR, 'media/stf')

# 缓存时间
CACHE_TIME = 60
CACHE_SHORT_TIME = 15

#  marshmallow文字默认值
fields.Field.default_error_messages = {
    'required': u'缺少必填数据.',
    'type': u'数据类型不合法.',
    'null': u'数据不能为空.',
    'validator_failed': u'非法数据.'
}
fields.Str.default_error_messages = {
    'invalid': '不是合法文本.'
}
fields.Int.default_error_messages = {
    'invalid': u'不是合法整数.'
}
fields.Number.default_error_messages = {
    'invalid': u'不是合法数字.'
}
fields.Boolean.default_error_messages = {
    'invalid': u'不是合法布尔值.'
}

# 在导入模块路径里加上trex服务模块路径
TREX_CLIENT_PATH = "/opt/v2.88/trex_client"
TREX_PATH = "/opt/v2.88/trex_client/interactive"
TREX_DAEMON_PATH = "/opt/v2.88/automation"
TREX_SERVER_PRE_NAME = "trex_"
sys.path.append(TREX_CLIENT_PATH)
sys.path.append(TREX_PATH)
sys.path.append(TREX_DAEMON_PATH)

# 服务器密码
PASSWORD = ""
DPDK_PATH = "/opt/v2.88"

# mongo的链接字符串
MONGO_URI = 'mongodb://127.0.0.1:27017'
MONGO_DB_NAME = 'flow'
MONGO_COLLECTION_NAME = 'Global_IP'

TREX_HOST = "127.0.0.1"

FLOWRES = 'flowres:80'
TREX_DAEMON_SERVER_PORT_NAME = 'TREX_DAEMON_SERVER_PORT'
TREX_PLATFORM_NAME = 'trex_platform'
GLOBAL_CLIENT_PORT = 'GLOBAL_CLIENT_PORT'
IN_USED_PORT = 'IN_USED_PORT'
ATTACK_RUN_FINISHED_COUNT = 'ATTACK_RUN_FINISHED_COUNT'
BATCH_RUN_RESULT = 'BATCH_RUN_RESULT'
RESTARTING_TREX_SERVER = 'RESTARTING_TREX_SERVER'
RUNNING_STATUS_THREAD = "RUNNING_STATUS:"
RUNNING_FLOW_THREAD = "RUNNING_FLOW_THREAD:"
TREX_SERVER_IS_STARTING = "TREX_SERVER_IS_STARTING"
TREX_DAEMON_PORT_CACHE = 'TREX_DAEMON_PORT_CACHE'


# 本地化 config.py, 若存在local_config.py 则在项目启动时尝试读取本地配置文件
try:
    from local_config import *
except ImportError:
    pass

if __name__ == 'config':
    # 加载本地环境创建日志文件夹 创建日志文件
    if not os.path.exists(LOG_BASE_DIR):
        os.makedirs(LOG_BASE_DIR)
    dictConfig(log_dict)
