# 提前导入app模块中所有的model类，否则无法迁移成功数据库表
from .configure.models.configure import *
from .resources.models.resources import *
from .software.models.software import *
from .monitor.models.monitor import *
from .task.models.task import *