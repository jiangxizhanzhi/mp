from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from app.configure.models.configure import CfgProfile, CfgFlows
from app.configure.models.configure import CfgStream, CfgNetworkStructure
from utils.exception_tools import FlowCfgNotFound, NetworkStructureNotFound
from utils.util import generate_uuid


class ProfileHandler(CfgProfile):
    """
    Profile数据库的操作
    """

    @classmethod
    def get_all_by_name(cls, name, page, per_page):
        """
        获取profile配置文件的列表
        :param name: 配置文件的名称，如果存在，则会筛选出包含该名字的配置文件记录
        :param page: 页码
        :param per_page: 每页显示的数量
        :return:
        """
        if name:
            profile_pagination = cls.query.filter(cls.name.contains(name)).paginate(page, per_page, False)
        else:
            profile_pagination = cls.query.filter().paginate(page, per_page, False)

        return profile_pagination.items, profile_pagination.total


class StreamHandler(CfgStream):
    """
    stream数据库的操作
    """

    @classmethod
    def save_import_stream(cls, content_list, profile_uuid):
        """
        保存导入yaml配置文件中的stream流信息
        :param content_list: yaml配置文件的列表
        :param profile_uuid: profile配置文件的uuid
        :return:
        """
        for content in content_list:
            _stream = content.pop('stream')
            _uuid = generate_uuid()
            content['uuid'] = _uuid + '_stream'
            content['profile_uuid'] = profile_uuid
            stream_obj = cls(**_stream, **content)
            cls.save(stream_obj)

    @classmethod
    def get_streams_by_profile_uuid(cls, profile_uuid):
        """
        根据profile_uuid返回该profile下面的所有流记录
        :param profile_uuid: 配置文件的uuid
        :return:
        """
        return cls.query.filter(cls.profile_uuid == profile_uuid).all()

    @classmethod
    def get_stream_by_uuid(cls, uuid):
        """
        根据uuid获取stream流
        :param uuid:
        :return:
        """
        return cls.query.filter(cls.uuid == uuid).first()


class CfgFlowsHandler(CfgFlows):

    @classmethod
    def get_obj_by_uuid(cls, uuid):
        try:
            obj = cls.query.filter(cls.uuid == uuid).one()
        except (NoResultFound, MultipleResultsFound) as e:
            raise FlowCfgNotFound(uuid, str(e))
        return obj


class NetworkHandler(CfgNetworkStructure):
    """
    网络结构的数据库操作
    """

    @classmethod
    def get_obj_by_uuid(cls, uuid):
        try:
            obj = cls.query.filter(cls.uuid == uuid).one()
        except (NoResultFound, MultipleResultsFound) as e:
            raise NetworkStructureNotFound(uuid, str(e))
        return obj