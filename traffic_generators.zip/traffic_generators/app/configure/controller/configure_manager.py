from logging import getLogger

from trex_stl_lib.api import *

from app import CfgNetworkStructure
from app.configure.ops.db_handler import StreamHandler, ProfileHandler, CfgFlowsHandler, NetworkHandler
from app.configure.schema.validate import CfgProfileSchema, StreamSchema, EditStreamVmSchema
from app.resources.ops.db_handler import FileDbManager
from app.software.controller.software_manager import get_port_info_dict
from app.task.ops.db_handler import CustomTaskHandler, TaskResultHandler
from common import error_log, info_log
from common.constant import TaskResultStatus, DutRole, DutMode, NetworkStructureType
from common.mongo_handler import MongoDBClient
from config import PROFILE_FILE_SIZE, BASE_DIR
from extension import db
from utils import status_code as sc
from utils.exception_tools import ValidateException, DataException
from utils.resp_util import get_Random_String
from utils.util import ip2int, check_ip

conf_error = getLogger('conf_error')
conf_info = getLogger('conf_info')


def create_profile(params):
    """
    创建profile配置文件的业务逻辑
    :param params: 请求参数
    :return:
    """
    conf_info.info('开始创建profile配置文件')
    info_log.info('开始创建profile配置文件')
    # 校验请求参数
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    if not name:
        return {'code': sc.MissingRequiredParameter}
    if not ProfileHandler.verify_unique_name(name):
        return {'code': sc.DuplicateName}
    response, error = CfgProfileSchema().load(params, session=db.session)
    if error:
        error_log.error('profile配置文件的序列化失败：{}'.format(error))
        conf_error.error('profile配置文件的序列化失败：{}'.format(error))
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    try:
        # 保存入库
        ProfileHandler.save(response)
        conf_info.info('创建配置文件{}成功'.format(response.uuid))
        info_log.info('创建配置文件{}成功'.format(response.uuid))
        return {'code': sc.Success, 'data': response.uuid}
    except Exception as e:
        error_log.error('保存配置文件失败:{}'.format(e))
        conf_error.error('保存配置文件失败:{}'.format(e))
        return {'code': sc.AddFailed}


def get_profile_list(name, page, per_page):
    """
    获取配置文件的列表
    :param name: 配置文件的名称
    :param page: 页码
    :param per_page: 每页显示的数量
    :return:
    """
    page = int(page) if str(page).isdigit() else 1
    per_page = int(per_page) if str(per_page).isdigit() else 10
    profiles, total = ProfileHandler.get_all_by_name(name, page, per_page)
    response, error = CfgProfileSchema(many=True, only=['uuid', 'name', 'description']).dump(profiles)
    if error:
        error_log.error('profile配置文件反序列化失败：{}'.format(error))
        conf_error.error('profile配置文件反序列化失败：{}'.format(error))
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    data = {
        'rows': response,
        'total': total
    }
    conf_info.info('获取配置文件列表成功')
    info_log.info('获取配置文件列表成功')
    return {'code': sc.Success, 'data': data}


def delete_profiles(params):
    """
    删除配置文件
    :param params: 配置文件的uuid列表
    :return:
    """
    uuids = params.get('uuids')
    if not uuids:
        return {'code': sc.DeleteItemNotEmpty}
    for profile_uuid in uuids:
        profile_status = query_profile_used_status(profile_uuid)
        if not profile_status:
            error_log.error('删除配置文件{}信息失败，被正在运行的任务占用'.format(profile_uuid))
            conf_error.error('删除配置文件{}信息失败，被正在运行的任务占用'.format(profile_uuid))
            return {'code': sc.EditFailed, 'msg': '被正在运行的任务占用，请停止任务之后重试'}
    ProfileHandler.batch_delete_by_uuids(uuids)
    conf_info.info('删除配置文件:{}成功'.format(uuids))
    info_log.info('删除配置文件:{}成功'.format(uuids))
    return {'code': sc.Success}


def import_profile_file(name, file):
    """
    导入profile配置文件
    :param name: 配置文件的名称
    :param file: 配置文件的路径
    :return:
    """
    # 校验请求参数
    if not name or not file:
        return {'code': sc.ParameterError}
    if not ProfileHandler.verify_unique_name(name):
        return {'code': sc.DuplicateName}
    filename, type = os.path.splitext(file.filename)
    if type not in {'.yaml'}:
        return {'code': sc.FileFormatError, 'msg': '只能上传yaml格式的文件'}
    if not check_file_size(file, PROFILE_FILE_SIZE):
        return {'code': sc.FileSizeExceedsLimit}
    # 首先在profile数据库中生成一条记录
    response, error = CfgProfileSchema().load({"name": name}, session=db.session)
    try:
        ProfileHandler.save(response)
        conf_info.info('导入配置文件入Profile数据库{}成功'.format(response.uuid))
        info_log.info('导入配置文件入Profile数据库{}成功'.format(response.uuid))
        content_list = yaml.load(file)
        StreamHandler.save_import_stream(content_list, response.uuid)
        return {'code': sc.Success, 'data': response.uuid}
    except Exception as e:
        error_log.error('导入yaml配置文件入库错误：{}'.format(e))
        conf_error.error('导入yaml配置文件入库错误：{}'.format(e))
        # 入库时发生错误将profile和stream同时删除
        ProfileHandler.delete_one(response)
        StreamHandler.rollback()
        return {'code': sc.ImportYamlFail}


def export_profile(profile_uuid):
    """
    导出yaml配置文件
    :param profile_uuid: profile配置文件的uuid
    :return:
    """
    if not profile_uuid:
        return {'code': sc.ParameterError}
    profile = ProfileHandler.get_one_by_uuid(profile_uuid)
    if not profile:
        return {'code': sc.NotFound, 'msg': '配置文件不存在'}
    streams = StreamHandler.get_streams_by_profile_uuid(profile_uuid)
    responses, _ = StreamSchema(many=True).dump(streams)
    _stream_list = []
    for _stream in responses:
        _stream_dict = {}
        # 删除trex无法识别的字段值
        del _stream['uuid'], _stream['profile_uuid']
        # 整理成trex可以识别的格式
        _stream_dict['name'] = _stream.pop('name')
        _stream_dict['stream_id'] = _stream.pop('stream_id')
        _stream_dict['stream'] = _stream
        _stream_list.append(_stream_dict)

    profile_files_path = os.path.join(BASE_DIR, 'media/export_profiles')
    if not os.path.exists(profile_files_path):
        os.makedirs(profile_files_path)
    yaml_path = os.path.join(BASE_DIR, 'media/export_profiles/{}.yaml'.format(profile.name))
    with open(yaml_path, 'w+') as f:
        yaml.dump(_stream_list, f, default_flow_style=False)
    conf_info.info('导出配置文件：{}成功'.format(profile.name))
    info_log.info('导出配置文件：{}成功'.format(profile.name))
    return yaml_path


def check_file_size(file, max_size):
    """
    校验文件的大小
    :param file: 文件FileStore对象
    :param max_size: 最大限制的大小
    :return:
    """
    file_length = file.stream._file.read()
    if len(file_length) == 0 or len(file_length) > max_size:
        return False
    file.stream._file.seek(0)
    return True


def create_stream(params):
    """
    创建stream流记录
    :param params: stream流中需要的参数
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    profile_uuid = params.get('profile_uuid')
    if not name or not profile_uuid:
        return {'code': sc.MissingRequiredParameter}
    profile = ProfileHandler.get_one_by_uuid(profile_uuid)
    if not profile:
        return {'code': sc.NotFound, 'msg': '配置文件不存在'}
    if not StreamHandler.verify_unique_name(name):
        return {'code': sc.DuplicateName}
    response, error = StreamSchema().load(params, session=db.session)
    if error:
        error_log.error(error)
        conf_error.error(error)
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    try:
        # 保存入库
        response.vm = {"cache": 5000, "instructions": []}
        StreamHandler.save(response)
        conf_info.info('创建配置文件中stream流{}成功'.format(response.uuid))
        return {'code': sc.Success, 'data': response.uuid}
    except Exception as e:
        error_log.error(e)
        conf_error.error(e)
        return {'code': sc.AddFailed}


def get_streams(profile_uuid):
    """
    获取指定配置文件的所有stream流记录
    :param profile_uuid: 配置文件的uuid
    :return: {'code': }
    """
    if not profile_uuid:
        return {'code': sc.ParameterError}
    profile = ProfileHandler.get_one_by_uuid(profile_uuid)
    if not profile:
        return {'code': sc.NotFound, 'msg': '配置文件不存在'}
    streams = StreamHandler.get_streams_by_profile_uuid(profile_uuid)
    responses, _ = StreamSchema(many=True).dump(streams)
    conf_info.info('获取{}配置文件的stream流记录成功'.format(profile.name))
    info_log.info('获取{}配置文件的stream流记录成功'.format(profile.name))
    return {'code': sc.Success, 'data': responses}


def update_stream(params):
    """
    更新stream流的信息
    :param params: stream流中需要的参数
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    stream_uuid = params.get('stream_uuid')
    profile_uuid = params.get('profile_uuid')
    if not name or not profile_uuid or not stream_uuid:
        return {'code': sc.MissingRequiredParameter}
    if not StreamHandler.verify_unique_name(name, stream_uuid):
        return {'code': sc.DuplicateName}
    profile = ProfileHandler.get_one_by_uuid(profile_uuid)
    if not profile:
        return {'code': sc.NotFound, 'msg': '配置文件不存在'}
    stream = StreamHandler.get_one_by_uuid(stream_uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'Stream流不存在'}

    # 检查该配置文件对应的任务是否正在运行，如果正在运行的话不能修改
    profile_status = query_profile_used_status(profile_uuid)
    if not profile_status:
        error_log.error('更新stream流{}信息失败，被正在运行的任务占用'.format(stream_uuid))
        conf_error.error('更新stream流{}信息失败，被正在运行的任务占用'.format(stream_uuid))
        return {'code': sc.EditFailed, 'msg': '被正在运行的任务占用，请停止任务之后重试'}

    response, error = StreamSchema(exclude=['uuid']).load(params, session=db.session, instance=stream)
    if error:
        error_log.error('stream流的序列化失败：{}'.format(error))
        conf_error.error('stream流的序列化失败：{}'.format(error))
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    try:
        # 保存入库
        StreamHandler.save(response)
        conf_info.info('修改配置文件中stream流{}成功'.format(response.uuid))
        info_log.info('修改配置文件中stream流{}成功'.format(response.uuid))
        return {'code': sc.Success}
    except Exception as e:
        error_log.error('修改配置文件中stream流信息保存失败：{}'.format(e))
        conf_error.error('修改配置文件中stream流信息保存失败：{}'.format(e))
        return {'code': sc.EditFailed}


def delete_streams(params):
    """
    删除stream流记录
    :param params: stream流的uuid的列表
    :return:
    """
    stream_uuids = params.get('uuids')
    if not stream_uuids:
        return {'code': sc.DeleteItemNotEmpty}

    # 根据stream流的uuid找到对应的profile配置文件的uuid
    for stream_uuid in stream_uuids:
        stream = StreamHandler.get_one_by_uuid(stream_uuid)
        if not stream:
            return {'code': sc.NotFound, 'msg': f'{stream_uuid}不存在'}

        # 检查该配置文件对应的任务是否正在运行，如果正在运行的话不能修改
        profile_status = query_profile_used_status(stream.profile_uuid)
        if not profile_status:
            error_log.error('删除stream流{}信息失败，被正在运行的任务占用'.format(stream_uuid))
            conf_error.error('删除stream流{}信息失败，被正在运行的任务占用'.format(stream_uuid))
            return {'code': sc.EditFailed, 'msg': '被正在运行的任务占用，请停止任务之后重试'}
    StreamHandler.batch_delete_by_uuids(stream_uuids)
    conf_info.info('删除stream流记录成功')
    info_log.info('删除stream流记录成功')
    return {'code': sc.Success}


def get_stream_detail(uuid):
    """
    获取指定stream流的详细信息
    :param uuid:
    :return:
    """
    stream = StreamHandler.get_one_by_uuid(uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'stream流不存在'}
    response, _ = StreamSchema().dump(stream)
    conf_info.info('获取{}stream流的详细信息成功'.format(uuid))
    info_log.info('获取{}stream流的详细信息成功'.format(uuid))
    return {'code': sc.Success, 'data': response}


def edit_stream_vm(req_data):
    errors = EditStreamVmSchema().validate(req_data)
    if errors:
        return {'code': sc.ParameterError, 'msg': errors[list(errors)[0]][0]}
    stream_uuid = req_data.get('stream_uuid')
    stream = StreamHandler.get_one_by_uuid(stream_uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'Stream流不存在'}
    instructions = req_data.get('instructions')
    update_data = {
        "vm": {
            "instructions": instructions,
            "cache": req_data.get('cache', 5000)
        }
    }
    stream.update(update_data)
    return {'code': sc.Success}


def add_packet_to_stream(params):
    """
    pakcet信息添加进stream流
    :param params:
    :return:
    """
    # 校验参数
    stream_uuid = params.get('stream_uuid')
    packet = params.get('packet')
    if not stream_uuid:
        return {'code': sc.ParameterError}
    stream = StreamHandler.get_stream_by_uuid(stream_uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'stream流不存在'}
    # 如果packet为空，更新表中字段值为{}
    if not packet:
        try:
            stream.packet = {}
            StreamHandler.save(stream)
        except DataException as e:
            StreamHandler.rollback()
            error_log.error(f'添加stream表失败，msg：{e}')
            conf_error.error(f'添加stream表失败，msg：{e}')
            return {'code': sc.AddFailed, 'msg': e}
        return {'code': sc.Success}
    # 组包,解析packet信息
    try:
        base_pkt = eval(make_packet(packet))
        print(base_pkt)
        pkt = STLPktBuilder(base_pkt)
        pkt = pkt.dump_pkt()
    except Exception as e:
        error_log.error(f'组包失败，msg：{e}')
        conf_error.error(f'组包失败，msg：{e}')
        return {'code': sc.PacketConstructFailed, 'msg': e}
    # packet信息写进stream表中uuid对应的stream流的packet字段
    stream = StreamHandler.get_stream_by_uuid(stream_uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'stream流不存在'}
    try:
        stream.packet = pkt
        StreamHandler.save(stream)
    except DataException as e:
        StreamHandler.rollback()
        error_log.error(f'添加stream表失败，msg：{e}')
        conf_error.error(f'添加stream表失败，msg：{e}')
        return {'code': sc.AddFailed, 'msg': e}
    info_log.info('添加stream表成功')
    conf_info.info('添加stream表成功')
    return {'code': sc.Success}


def make_packet(packet):
    """
    根据传递的参数构建packet包
    :param packet:
    :return: base_pkt
    """
    layers_list = []
    for layer in packet:
        d = ''
        for key1, value1 in layer.items():
            if key1 == 'Ethernet' and not value1:
                a = 'Ether()'
            else:
                # 拿到每层协议名称a
                a = f'{key1}('
                # 第一层协议名称Ethernet换成Ether，要不然找不到包执行报错
                if 'Ethernet' in a:
                    a = f'Ether('
                num, b, c = 0, '', ''
                for key2, value2 in value1.items():
                    # 拿到每层第二个参数及值
                    if num == 0:
                        if 'Text' in key2 and not value2:
                            if len(value2.encode(encoding='utf8')) < 0 or len(value2.encode(encoding='utf8')) > 65535:
                                return {'code': sc.AddPayLoadFailed, 'msg': '载荷字节长度在0-65535'}
                            b = f'load={value2})'
                        elif 'File' in key2 and not value2:
                            from manage import app
                            with app.app_context():
                                file_uuid = value2
                                file = FileDbManager.get_script_by_uuid(file_uuid)
                                with open(file.file_path, 'rb') as f:
                                    content = f.read()
                                    if len(content) < 0 or len(content) > 65536:
                                        return {'code': sc.AddPayLoadFailed, 'msg': '载荷字节长度在0-65535'}
                            b = f'load={content})'
                        elif 'Random ascii' in key2 and not value2:
                            length = int(value2)
                            salt = get_Random_String(length)
                            b = f'load="{salt}")'
                        elif 'sport' in key2 or 'dport' in key2:
                            b = f'{key2}={int(value2)}, '
                        else:
                            b = f'{key2}="{value2}", '
                    # 拿到每层第一个参数及值
                    else:
                        if 'sport' in key2 or 'dport' in key2:
                            c = f'{key2}={int(value2)})'
                        else:
                            c = f'{key2}="{value2}")'
                    # 拼接组包公式每层括号内参数及值
                    d = b + c
                    num += 1
            # 拼接组包公式
            a = a + d
            layers_list.append(a)
        a = a + ' / ' + a
    base_pkt = ' / '.join(layers_list)
    return base_pkt


def get_stream_packet(params):
    """
    根据stream_uuid获取stream流的packet信息
    :param params:
    :return:
    """
    # 校验参数
    uuid = params.get('stream_uuid')
    if not uuid:
        return {'code': sc.ParameterError}
    # 根据uuid获取stream流的packet字段值和vm字段值
    stream = StreamHandler.get_stream_by_uuid(uuid)
    if not stream:
        return {'code': sc.NotFound, 'msg': 'stream流不存在'}
    packet = stream.packet
    vm = stream.vm
    # packet字段值和vm字段值
    PK = {}
    PK['packet'] = packet
    PK['vm'] = vm
    # 组包
    base_pkt = STLPktBuilder()
    pkt = base_pkt.from_json(PK)
    # 获取包的层数，解析各层属性
    layer_list = pkt.pkt_layers_desc().split(':')
    # 获取最初属性
    first_attr = Ether(pkt.pkt_raw).show2(dump=True)
    # 解析各层属性，并组装数据，返回
    data = {}
    data['packet'] = []
    try:
        # 遍历每一层
        for layer in layer_list:
            dict = {}
            # 按固定格式切分为对应的每层
            for layer_attr in first_attr.split('###['):
                # 根据每层协议找出对应层数属性
                if layer in layer_attr[0:10]:
                    # 组装每层数据
                    dict[layer] = {}
                    for attr in layer_attr.split('\n'):
                        if 'dst' in attr or 'src' in attr or 'dport' in attr or 'sport' in attr:
                            # 去除多余空格
                            kk = [k.strip(' ') for k in attr.split('=')]
                            dict[layer][kk[0]] = kk[1]
                        if 'load' in attr:
                            kk = [k.strip(' ') for k in attr.split('=')]
                            dict[layer][kk[0]] = kk[1]
            data['packet'].append(dict)
    except Exception as e:
        error_log.error(f'获取stream流的packet包信息失败，msg：{e}')
        conf_error.error(f'获取stream流的packet包信息失败，msg：{e}')
        return {'code': sc.GetFailed, 'msg': e}
    info_log.info('获取stream流的packet包信息成功')
    conf_info.info('获取stream流的packet包信息成功')
    return {'code': sc.Success, 'data': data}


def get_ips_by_country(country, page, per_page):
    """
    获取指定国家的ip列表
    :param country: 国家名称
    :param page: 页码
    :param per_page: 每页显示的数量
    :return:
    """
    page = int(page) if str(page).isdigit() else 1
    per_page = int(per_page) if str(per_page).isdigit() else 10
    count = MongoDBClient().get_count({'area': country})
    results = MongoDBClient().get_all({'area': country}, per_page=per_page, page=page)
    conf_info.info('获取{}国家的ip列表成功'.format(country))
    info_log.info('获取{}国家的ip列表成功'.format(country))
    return {'code': 1000, 'data': {'rows': results, 'total': count}}


def get_country_by_ip(req_ip):
    """
    通过ip获取一个国家的地址
    :param req_ip:
    :return:
    """
    if not req_ip:
        return {'code': sc.ParameterError}
    # 判断ip是否正确
    _req_ip = check_ip(req_ip)
    if not _req_ip:
        error_log.error('输入ip格式错误')
        conf_error.error('输入ip格式错误')
        return {'code': sc.IPFormatError}
    # 将ip转换成int类型
    int_ip = ip2int(req_ip)
    result = MongoDBClient().get_one_between_fields('startIp_int', 'endIp_int', int_ip)
    if not result:
        error_log.error('未匹配出对应的国家信息')
        conf_error.error('未匹配出对应的国家信息')
        return {'code': sc.NotFound, 'msg': '未匹配出对应的国家信息'}
    conf_info.info('获取{}对应的国家信息成功'.format(req_ip))
    info_log.info('获取{}对应的国家信息成功'.format(req_ip))
    return {'code': sc.Success, 'data': result}


def query_profile_used_status(profile_uuid):
    """
    查询使用该profile配置文件的任务的运行状态
    :param profile_uuid: profile配置文件的uuid
    :return:
    """
    task_uuids = CustomTaskHandler.get_tasks_by_configure_uuid(profile_uuid)
    task_status = TaskResultHandler.get_task_status_by_task_uuids(task_uuids)
    if TaskResultStatus.running in task_status:
        # 正在运行中的状态返回False
        return False
    return True


class FlowCfgManager(object):

    def verify_cfg_name(self, name, exclude_uuid=None):
        result = CfgFlowsHandler.verify_unique_name(name, exclude_uuid)
        return result

    def create_flow_cfg(self, data):
        obj = CfgFlowsHandler.create_obj(data, "flow")
        return obj

    def flow_cfg_list(self, page, per_page):
        paginate_data = CfgFlowsHandler.paginate(page, per_page)
        data = [i.to_dict(exclued=["profile"]) for i in paginate_data["items"]]
        total = paginate_data.get("total")
        return data, total

    def get_cfg(self, uuid):
        detail = CfgFlowsHandler.get_obj_by_uuid(uuid).to_dict()
        return detail

    def update_flow_cfg(self, uuid, data):
        obj = CfgFlowsHandler.get_obj_by_uuid(uuid)
        obj.update(data)

    def batch_delete_cfg(self, uuids):
        CfgFlowsHandler.batch_delete_by_uuids(uuids)


class NetworkStructureManager(object):

    def verify_network_structure_name(self, name, exclude_uuid=None):
        result = NetworkHandler.verify_unique_name(name, exclude_uuid)
        return result

    def create_network_structure(self, data):
        obj = NetworkHandler.create_obj(data, "network")
        return obj

    def network_structure_list(self, page, per_page, req_args):
        name = req_args.get("name")
        filters = []
        if name:
            filters.append(CfgNetworkStructure.name.contains(name))
        paginate_data = NetworkHandler.paginate(page, per_page, filters)
        data = [i.to_dict(exclued=["profile"]) for i in paginate_data["items"]]
        total = paginate_data.get("total")
        return data, total

    def get_network_structure(self, uuid):
        port_info_dict = get_port_info_dict()

        def replace_port_num(network_info_list):
            for net_info in network_info_list:
                port_num = str(net_info["port"])
                port_info = port_info_dict.get(port_num)
                net_info["port"] = port_info

        network_structure = NetworkHandler.get_obj_by_uuid(uuid).to_dict()
        network_config = network_structure.get("network_config")
        client = network_config.get("client")
        server = network_config.get("server")
        if client:
            replace_port_num(client)
        if server:
            replace_port_num(server)
        return network_structure

    def update_network_structure(self, uuid, data):
        obj = NetworkHandler.get_obj_by_uuid(uuid)
        obj.update(data)

    def batch_delete_network_structure(self, uuids):
        NetworkHandler.batch_delete_by_uuids(uuids)

    def check_network_structure(self, data, old_data=None):
        '''
        校验network_structure数据
        当dut_role为gateway，network_config里的client和server之间的对应关系由相同索引实现
        {
            "name": "caitt4",                 // 必填 str
            "dut_role": "gateway",            // 必填 str
            "ip_versions": "ipv4",            // 必填 str
            "dut_mode": "TP",                 // 非必填 str
            "network_config": {               // 必填 dict
                "client": [{                  // 必填 list
                    "ip": "192.168.3.3",      // 必填 str
                    "default_gw": "192.168.3.3", // 必填 str
                    "port": 1,                 // 必填 int
                    "capture": true,          //  必填 bool
                    "capture_limit": 1000     // 非必填 int
                }],
                "server": [{                  // 非必填 list
                    "ip": "192.168.3.4",      // 必填 str
                    "default_gw": "192.168.3.3", // 必填 str
                    "port": 2                 // 必填 int
                }]
            }
        }
        '''
        # 校验dut_mode参数
        dut_role = data.get("dut_role")
        dut_mode = data.get("dut_mode", "")
        ip_versions = data.get("ip_versions")
        # 已经创建的网络结构不能更改dut_role
        if old_data:
            if old_data.get("dut_role") != dut_role:
                raise ValidateException("不能更改测试设备模式")
            if old_data.get("ip_versions") != ip_versions:
                raise ValidateException("不能更改ip版本")
            if old_data.get("dut_mode", "") != dut_mode:
                raise ValidateException("不能更改dut_mode")
        if dut_role == DutRole.gateway:
            if dut_mode not in DutMode.CHOICES_DICT:
                raise ValidateException("被测设备模式错误")
        else:
            if dut_mode:
                raise ValidateException("服务器设备不能选择测试模式")
        # 校验network_config参数
        network_config = data.get("network_config")
        if not network_config:
            raise ValidateException("网络结构配置不能为空")
        client = network_config.get("client", [])
        server = network_config.get("server", [])
        if dut_role == DutRole.gateway:
            if not (client and server):
                raise ValidateException("被测为网关设备需要客户端和服务端的网络信息")
            if len(client) != len(server):
                raise ValidateException("客户端和服务端的网络数量不一致")
            all_port_count = len(client) + len(server)
            if all_port_count * ["dummy"] == client + server:
                raise ValidateException("不能所有端口为dummy")
            network_structure_type = NetworkStructureType.astf
        else:
            if not client:
                raise ValidateException("被测为应用服务需要客户端网络信息")
            if server:
                raise ValidateException("被测为应用服务不需要服务端网络信息")
            network_structure_type = NetworkStructureType.stl
        all_network_list = client + server
        used_port_list = []
        for item in all_network_list:
            # 只有app task 使用
            if item == "dummy":
                continue
            capture = item.get("capture")
            if dut_role == DutRole.gateway and capture:
                raise ValidateException("网关模式不能捕获")
            capture_limit = item.get("capture_limit")
            if capture and not capture_limit:
                item["capture_limit"] = 1000
            default_gw = item.get("default_gw")
            if not default_gw:
                raise ValidateException("default_gw是必填项")
            port = item.get("port")
            if not port:
                raise ValidateException("port是必填项")
            if port in used_port_list:
                raise ValidateException(f"port:{port}被重复选择")
            used_port_list.append(port)
        # 校验port是否在数据库里
        port_info_dict = get_port_info_dict()
        for p in used_port_list:
            if str(p) not in port_info_dict:
                raise ValidateException(f"port:{p}不存在")
        data["type"] = network_structure_type
        return data
