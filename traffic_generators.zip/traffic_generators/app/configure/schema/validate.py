from marshmallow import fields, ValidationError, validate, pre_load

from app.configure.models.configure import CfgProfile, CfgStream
from common.constant import AllStreamVM, IpVersions, DutRole, DutMode
from extension import ma
from utils.util import generate_uuid


class CfgProfileSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(1, 50, error="Profile配置文件的名称在1-50个字符之间")])
    description = fields.Str(required=False, validate=validate.Length(0, 256, error="Profile配置文件的描述信息在0-256个字符之间"))
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = CfgProfile
        fields = ('uuid', 'name', 'description', 'create_time', 'update_time')

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_profile'
        return params


class StreamSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(min=1, max=50, error='stream流的名称在1-50个字符之间')])
    mode = fields.Dict(required=True)
    self_start = fields.Bool(required=True)
    flow_stats = fields.Dict(required=False)  # 使用情况不明，暂时不对外提供
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = CfgStream

    @pre_load
    def clean_data(self, params):
        params["flow_stats"] = {
            "enabled": False
        }

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_stream'
        return params


class EditFlowCfgSchema(ma.ModelSchema):
    '''
    {
        "name": "",
        "description": "",
        "profile": {
            "client": {     # 通用的客户端配置  必填
                "ip_range": "16.0.0.0-16.0.0.255",
                "distribution": "seq"
            },
            "server": {     # 通用的服务端配置  必填
                "ip_range": "48.0.0.0-48.0.0.255",
                "distribution": "seq"
            },
            "cap_list": [{
                "pcap_uuid": "uuid",
                "cps": 1,
                "client": {  # 指定的客户端端配置
                    "ip_range": "16.0.0.0-16.0.0.255",
                    "distribution": "seq"
                },
                "server": {  # 指定的服务端配置
                    "ip_range": "48.0.0.0-48.0.0.255",
                    "distribution": "seq"
                }
            }]
        }
    }
    '''
    name = fields.Str(required=True, validate=[
        validate.Length(min=1, max=50, error='{input} 长度在 {min} 和 {max} 之间')
    ])
    description = fields.Str(required=False,validate=validate.Length(min=0, max=256, error='{input} 长度在 {min} 和 {max} 之间'))
    profile = fields.Method(required=True, deserialize='load_profile', error_messages={"required": "请填写flow配置"})

    @staticmethod
    def load_profile(profile_data):
        if not profile_data:
            raise ValidationError("flow配置不能为空")
        cap_list = profile_data.get("cap_list")
        if not cap_list:
            raise ValidationError("请填写使用的流量信息")
        client = profile_data.get("client")
        server = profile_data.get("server")
        if not client or not server:
            raise ValidationError("flow配置中的clent和server字段是必填项")

        # 此处导入，避免循环引用
        from app.resources.controller.resource_manager import PcapManagement
        from utils.exception_tools import PcapNotFound

        pcap_management = PcapManagement()
        for cap in cap_list:
            pcap_uuid = cap.get("pcap_uuid")
            if not pcap_uuid:
                raise ValidationError("请选择要使用的流量包")
            try:
                pcap_management.get_pcap(pcap_uuid)
            except PcapNotFound as e:
                raise ValidationError(f"pcap包中不存在pcap_uuid:{pcap_uuid}")
        return profile_data


class EditStreamVmSchema(ma.ModelSchema):
    stream_uuid = fields.Str(required=True, validate=validate.Length(1, 64, error="stream_uuid 长度错误"))
    # cache = fields.Int(required=False, deserialize='load_cache', default=5000)
    instructions = fields.Method(required=True, deserialize='load_instructions', error_messages={"required": "请填写使用的指令集"})

    @staticmethod
    def load_instructions(data):
        if not isinstance(data, list):
            raise ValidationError("指令集为一个列表")
        for instruction in data:
            ins_type = instruction.get("type")
            if ins_type not in AllStreamVM.vm_type:
                raise ValidationError(f"不支持{ins_type}指令")
        return data


class EditNetworkSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[
        validate.Length(min=1, max=50, error='{input} 长度在 {min} 和 {max} 之间')
    ])
    dut_role = fields.Str(required=True, validate=validate.OneOf(DutRole.CHOICES_DICT))
    ip_versions = fields.Str(required=True, validate=validate.OneOf(IpVersions.CHOICES_DICT))
    dut_mode = fields.Str(required=False, validate=validate.OneOf(DutMode.CHOICES_DICT))
    network_config = fields.Method(required=True, error_messages={"required": "请填写网络结构配置"})