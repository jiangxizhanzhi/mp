from flask import request
from flask_restplus import Namespace, Resource
from logging import getLogger

from utils.resp_util import resp_message
from utils.exception_tools import NetworkStructureNotFound, ValidateException
from utils import status_code as sc
from common import error_log, info_log
from ..schema.validate import EditNetworkSchema
from ..controller.configure_manager import NetworkStructureManager


ns_network_structure = Namespace('network_structure', description="Endpoint to manage network structure")
network_manager = NetworkStructureManager()

conf_error = getLogger('conf_error')
conf_info = getLogger('conf_info')


@ns_network_structure.route("/list")
class NetworkList(Resource):

    def get(self):
        per_page = int(request.args.get('per_page')) if request.args.get('per_page') and str(
            request.args.get('per_page')).isdigit() else 10
        page = int(request.args.get('page')) if request.args.get('page') and str(
            request.args.get('page')).isdigit() else 1
        req_args = request.args
        rows, total = network_manager.network_structure_list(page, per_page, req_args)
        data = {
            "rows": rows,
            "total": total
        }
        info_log.info("成功获取网络结构列表")
        return resp_message(data=data)


@ns_network_structure.route("")
class NetworkOperation(Resource):

    def post(self):
        conf_info.info("新增网络结构")
        info_log.info("新增网络结构")
        req_data = request.get_json()
        errors = EditNetworkSchema().validate(req_data)
        if errors:
            error_log.error('新增网络结构参数错误：{}'.format(errors))
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        try:
            network_manager.check_network_structure(req_data)
        except ValidateException as e:
            error_log.error('新增网络结构参数错误：{}'.format(str(e)))
            return resp_message(code=sc.ParameterError, msg=str(e))
        name = req_data["name"]
        only_name = network_manager.verify_network_structure_name(name)
        if only_name is False:
            error_log.error('新增网络结构参数错误：{}'.format("名称重复"))
            return resp_message(code=sc.DuplicateName)
        obj = network_manager.create_network_structure(req_data)
        data = {
            "uuid": obj.uuid
        }
        info_log.info("成功新增网络结构")
        return resp_message(data=data)

    def delete(self):
        req_data = request.get_json()
        uuids = req_data.get("uuids", [])
        network_manager.batch_delete_network_structure(uuids)
        info_log.info("成功删除网络结构信息")
        return resp_message()


@ns_network_structure.route("/<string:uuid>")
class NetworkDetail(Resource):

    def get(self, uuid):
        try:
            detail = network_manager.get_network_structure(uuid)
        except NetworkStructureNotFound as e:
            return resp_message(code=sc.NotFound)
        info_log.info("成功获取网络结构信息")
        return resp_message(data=detail)

    def patch(self, uuid):
        req_data = request.get_json()
        errors = EditNetworkSchema().validate(req_data)
        if errors:
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        try:
            network_structure = network_manager.get_network_structure(uuid)
        except NetworkStructureNotFound as e:
            return resp_message(code=sc.NotFound)
        try:
            network_manager.check_network_structure(req_data, network_structure)
        except ValidateException as e:
            return resp_message(code=sc.ParameterError, msg=str(e))
        name = req_data["name"]
        only_name = network_manager.verify_network_structure_name(name, uuid)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        network_manager.update_network_structure(uuid, req_data)
        info_log.info("成功修改网络结构信息")
        return resp_message()