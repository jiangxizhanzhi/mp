from flask import request
from flask_restplus import Namespace, Resource
from logging import getLogger

from utils.resp_util import resp_message, code_mag
from utils.exception_tools import FlowCfgNotFound
from utils import status_code as sc
from common import error_log, info_log
from ..schema.validate import EditFlowCfgSchema
from ..controller.configure_manager import FlowCfgManager, query_profile_used_status


ns_flow = Namespace('', description="Endpoint to manage configure flow")
flow_cfg_manager = FlowCfgManager()

conf_error = getLogger('conf_error')
conf_info = getLogger('conf_info')


@ns_flow.route("/flows")
class FlowsOperation(Resource):

    def post(self):
        # 新增flow配置文件
        info_log.info("新增flow配置文件")
        req_data = request.get_json()
        errors = EditFlowCfgSchema().validate(req_data)
        if errors:
            error_log.error('新增flow配置文件参数错误：{}'.format(errors))
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        name = req_data["name"]
        only_name = flow_cfg_manager.verify_cfg_name(name)
        if only_name is False:
            error_log.error('新增flow配置文件参数错误：{}'.format("名称重复"))
            return resp_message(code=sc.DuplicateName)
        obj = flow_cfg_manager.create_flow_cfg(req_data)
        data = {
            "uuid": obj.uuid
        }
        info_log.info("新增flow配置文件成功")
        return resp_message(data=data)

    def get(self):
        # flow配置文件列表
        per_page = int(request.args.get('per_page')) if request.args.get('per_page') and str(
            request.args.get('per_page')).isdigit() else 10
        page = int(request.args.get('page')) if request.args.get('page') and str(
            request.args.get('page')).isdigit() else 1
        rows, total = flow_cfg_manager.flow_cfg_list(page, per_page, )
        data = {
            "rows": rows,
            "total": total
        }
        return resp_message(data=data)

    def delete(self):
        info_log.info("删除flow配置文件")
        req_data = request.get_json()
        uuids = req_data.get("uuids", [])
        for profile_uuid in uuids:
            profile_status = query_profile_used_status(profile_uuid)
            if not profile_status:
                conf_error.error('删除flow配置文件{}信息失败，被正在运行的任务占用'.format(profile_uuid))
                return resp_message(code=sc.FailDelete, msg='被正在运行的任务占用，请停止任务之后重试')
        flow_cfg_manager.batch_delete_cfg(uuids)
        info_log.info("成功删除flow配置文件")
        return resp_message()


@ns_flow.route("/flows/<string:uuid>")
class FlowsDetail(Resource):
    def get(self, uuid):
        info_log.info("获取flow配置文件")
        try:
            detail = flow_cfg_manager.get_cfg(uuid)
        except FlowCfgNotFound as e:
            error_log.error(f'flow {uuid}配置文件不存在')
            return resp_message(code=sc.NotFound)
        info_log.info("成功获取flow配置文件")
        return resp_message(data=detail)

    def patch(self, uuid):
        info_log.info("修改flow配置文件")
        req_data = request.get_json()
        errors = EditFlowCfgSchema().validate(req_data)
        if errors:
            error_log.error('修改flow配置文件参数错误：{}'.format(errors))
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        try:
            flow_cfg_manager.get_cfg(uuid)
        except FlowCfgNotFound as e:
            return resp_message(code=sc.NotFound)
        name = req_data["name"]
        only_name = flow_cfg_manager.verify_cfg_name(name, uuid)
        if only_name is False:
            error_log.error('修改flow配置文件参数错误：{}'.format("名称重复"))
            return resp_message(code=sc.DuplicateName)
        flow_cfg_manager.update_flow_cfg(uuid, req_data)
        info_log.info("成功修改flow配置文件")
        return resp_message()