from flask import Blueprint
from flask_restplus import Api

from app.configure.api_v1.flow import ns_flow
from app.configure.api_v1.global_ip import ip_namespace
from app.configure.api_v1.profile import cfg_profile
from app.configure.api_v1.stream import stream_packet
from app.configure.api_v1.network_structure import ns_network_structure

configure_blueprint = Blueprint('configure_blueprint', __name__)
configure_api = Api(configure_blueprint, version='v1')

# 添加配置文件中的每个命名空间url, 也就是每个大模块下面的每个小模块分成不同的url
# configure_api.add_namespace('', '')
configure_api.add_namespace(ns_flow)
configure_api.add_namespace(cfg_profile)
configure_api.add_namespace(stream_packet)
configure_api.add_namespace(ip_namespace)
configure_api.add_namespace(ns_network_structure)