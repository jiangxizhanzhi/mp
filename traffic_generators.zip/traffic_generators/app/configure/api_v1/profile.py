from flask import request, send_file
from flask_restplus import Namespace, Resource

from app.configure.controller.configure_manager import create_profile, get_profile_list, delete_profiles, \
    import_profile_file, export_profile, get_streams, create_stream, update_stream, delete_streams, get_stream_detail, \
    edit_stream_vm
from utils.resp_util import resp_message
from common.constant import AllStreamsProtocol, AllStreamVM

cfg_profile = Namespace('', description="Endpoint to manage configure profile")


@cfg_profile.route('/profiles')
class ProfileApi(Resource):
    """
    profile配置文件的api类
    """

    def get(self):
        """
        获取配置文件的列表
        :return:
        """
        name = request.args.get('name')
        page = request.args.get('page')
        per_page = request.args.get('per_page')
        response = get_profile_list(name, page, per_page)
        return resp_message(**response)

    def post(self):
        """
        创建配置文件
        :return:
        """
        params = request.get_json()
        response = create_profile(params)
        return resp_message(**response)

    def delete(self):
        """
        删除配置文件
        :return:
        """
        uuids = request.get_json()
        response = delete_profiles(uuids)
        return resp_message(**response)


@cfg_profile.route('/import_profile')
class ImportProfileApi(Resource):
    """
    导入profile配置文件的api类
    """

    def post(self):
        """
        导入配置文件
        :return:
        """
        name = request.form.get('name')
        file = request.files.get('file_path')
        response = import_profile_file(name, file)
        return resp_message(**response)


@cfg_profile.route('/export_profile')
class ExportProfileApi(Resource):
    """
    导出profile配置文件的api类
    """

    def get(self):
        """
        导出配置文件
        :return:
        """
        profile_uuid = request.args.get('profile_uuid')
        file_path = export_profile(profile_uuid)
        return send_file(file_path, as_attachment=True)


@cfg_profile.route('/profiles/streams')
class StreamApi(Resource):
    """
    profile配置文件中stream流的api类
    """

    def get(self):
        """
        获取profile配置文件中stream流的列表
        :return:
        """
        profile_uuid = request.args.get('profile_uuid')
        response = get_streams(profile_uuid)
        return resp_message(**response)

    def post(self):
        """
        新增profile配置文件中stream流
        :return:
        """
        params = request.get_json()
        response = create_stream(params)
        return resp_message(**response)

    def patch(self):
        """
        修改profile配置文件中的stream流信息
        :return:
        """
        params = request.get_json()
        response = update_stream(params)
        return resp_message(**response)

    def delete(self):
        """
        删除profile配置文件中stream流记录
        :return:
        """
        params = request.get_json()
        response = delete_streams(params)
        return resp_message(**response)


@cfg_profile.route('/profiles/streams/<string:uuid>')
class StreamDetailApi(Resource):
    """
    获取单个stream流的详细信息
    """

    def get(self, uuid):
        """
        获取单个stream流的详细信息
        :param uuid: stream流的uuid
        :return:
        """
        response = get_stream_detail(uuid)
        return resp_message(**response)


@cfg_profile.route('/profiles/streams/protocol')
class PacketProtocol(Resource):

    def get(self):
        """
        获取编辑streams支持的协议
        """
        data = AllStreamsProtocol().all_protocol_info
        return resp_message(data)


@cfg_profile.route('/profiles/streams/vm')
class StreamVm(Resource):

    def get(self):
        data = AllStreamVM().all_vm_info
        return resp_message(data)

    def post(self):
        """
        编辑streams vm
        """
        req_data = request.get_json()
        response = edit_stream_vm(req_data)
        return resp_message(**response)
