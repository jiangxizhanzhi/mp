from flask import request

from flask_restplus import Namespace, Resource

from app.configure.controller.configure_manager import get_ips_by_country, get_country_by_ip
from utils.resp_util import resp_message

ip_namespace = Namespace('', description="Endpoint to manage Global IP")


# @ip_namespace.route('/ips')
class IPManageApi(Resource):
    """
    获取指定国家的ip列表api
    """

    def get(self):
        """
        获取指定国家的ip列表
        :return:
        """
        country = request.args.get('country')
        page = request.args.get('page')
        per_page = request.args.get('per_page')
        response = get_ips_by_country(country, page, per_page)
        return resp_message(**response)


# @ip_namespace.route('/ips/country')
class IPCountryManageApi(Resource):
    """
    获取ip对应的国家地址
    """

    def get(self):
        """
        获取ip对应的国家地址
        :return:
        """
        req_ip = request.args.get('ip')
        response = get_country_by_ip(req_ip)
        return resp_message(**response)
