from flask import request
from flask_restplus import Namespace, Resource

from app.configure.controller.configure_manager import add_packet_to_stream, get_stream_packet
from utils.resp_util import resp_message

stream_packet = Namespace('', description="Endpoint to manage configure profile")


@stream_packet.route('/profiles/streams/packet')
class StreamPacketApi(Resource):

	def get(self):
		"""
		获取stream流中的packet包信息
		:return:
		"""
		params = request.args.to_dict()
		response = get_stream_packet(params)
		return resp_message(**response)

	def post(self):
		"""
		新增stream流中的packet包信息
		:return:
		"""
		params = request.get_json()
		response = add_packet_to_stream(params)
		return resp_message(**response)
