from datetime import datetime

from common.db_manage import DbManager
from extension import db


class CfgProfile(db.Model, DbManager):
    """profile配置文件表    表名cfg_profile"""

    __tablename__ = "cfg_profile"
    uuid = db.Column(db.String(64), primary_key=True)  # 文件uuid
    name = db.Column(db.String(100))  # 文件名称
    description = db.Column(db.String(1024), default='')  # 文件描述信息
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class CfgStream(db.Model, DbManager):
    """stream流数据表    表名cfg_stream"""

    __tablename__ = "cfg_stream"
    uuid = db.Column(db.String(64), primary_key=True)  # stream流uuid
    profile_uuid = db.Column(db.String(64))  # stream关联的profile的uuid
    name = db.Column(db.String(100))  # stream流名称
    packet = db.Column(db.JSON)  # stream中的packet
    mode = db.Column(db.JSON)  # stream流模式，分三种，值为各个模式的json字符串：  continuous(连续流)    burst(突发流)   multi-burst(多突发流)
    enabled = db.Column(db.Boolean, default=True)  # stream流是否可用
    self_start = db.Column(db.Boolean, default=True)  # 是否自启流，如果是False，则另一个流会激活它
    isg = db.Column(db.Float, default=0.0)  # usec中的流间间隙，等待流发送第一个数据包的时间
    flow_stats = db.Column(db.JSON)  # 定义每个流的基本统计信息stats + 延迟latency、抖动、数据包重新排序/丢失
    next = db.Column(db.String(100))  # 关联的下一个流的name  如果为空，则默认这个流结束后停止
    # stream_id = db.Column(db.Integer)  # stream流的id，针对每个profile而定义
    action_count = db.Column(db.Integer, default=0)  # 如果有下一个流，停止前的循环数，默认无限制
    random_seed = db.Column(db.Integer, default=0)  # 如果给定，此流的种子将是此值
    vm = db.Column(db.JSON)  # 操作数据包字段的指令列表
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class CfgFlows(db.Model, DbManager):
    """flow配置文件表    表名cfg_flow"""

    __tablename__ = "cfg_flow"
    uuid = db.Column(db.String(64), primary_key=True)  # 文件uuid
    name = db.Column(db.String(100))  # 文件名称
    description = db.Column(db.String(1024), default='')  # 文件描述信息
    profile = db.Column(db.JSON)
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class CfgNetworkStructure(db.Model, DbManager):
    """网络结构表    表名cfg_networkStructures"""

    __tablename__ = "cfg_networkstructures"
    uuid = db.Column(db.String(64), primary_key=True)  # 网络结构uuid
    name = db.Column(db.String(100))  # 网络结构名称
    type = db.Column(db.Integer)  # 网络结构类型  1:无状态  2：有状态
    ip_versions = db.Column(db.String(10))  # ip版本  值为：ipv4或ipv6
    dut_role = db.Column(db.String(10))  # 被测设备类型   gateway：网关设备  server：应用服务
    dut_mode = db.Column(db.String(10), default='')  # 被测设备为网关填   TP：透明模式   NAT：路由模式
    network_config = db.Column(db.JSON)  # 配置参数
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间
