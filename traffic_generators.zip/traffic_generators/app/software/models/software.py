from common.db_manage import DbManager
from datetime import datetime

from extension import db


class PortManager(db.Model, DbManager):
    """端口管理表    表名port_manager"""

    __tablename__ = "port_manager"
    uuid = db.Column(db.String(64), primary_key=True)  # 端口uuid
    port = db.Column(db.Integer)  # 端口号
    ip = db.Column(db.String(100))  # 端口ip
    target_ip = db.Column(db.String(100))  # 端口ip
    is_manager = db.Column(db.Integer)  # 是否是管理口  1:是  0：否
    status = db.Column(db.String(10))  # 端口状态  值为： acquire或release
    task_uuid = db.Column(db.String(64))  # 任务uuid
    pci = db.Column(db.String(100))  # 端口识别号
    mac = db.Column(db.String(100))  # 端口mac地址
    broadcast = db.Column(db.String(100))  # 广播地址
    netmask = db.Column(db.String(100))  # 掩码
    port_name = db.Column(db.String(100))  # 端口名
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
