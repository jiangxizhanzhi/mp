import copy
import json
import os
import time
from logging import getLogger

import netifaces
import yaml

import config
from app.software.ops.db_handler import PortHandler
from app.software.schema.validate import PortManagerSchema, TaskPortManagerSchema
from app.task.ops.db_handler import TaskPortManagerHandler
from common import error_log, info_log
from common.constant import PortStatus, LogType
from extension import db
from utils import status_code as sc
from utils.exception_tools import DataException, UpdatePortException
from utils.resp_util import exec_cmd_on_path, exec_cmd, resp_message
from utils.util import get_available_port

software_error = getLogger('software_error')
software_info = getLogger('software_info')
task_info = getLogger('task_info')

def update_ports():
    """
	更新网口
	:return: dict
	"""

    # 获取所有网口
    all_ports = PortHandler.get_all_ports()
    # 网口状态都为release才可以更新网口，更新网口需要先删除原来的网口数据
    for port in all_ports:
        if port.status == PortStatus.acquire:
            return {"code": sc.PortAcquired, "data": port.uuid}
    PortHandler.delete_all()
    ports_info_dict = get_ports_info()
    # 写入数据库
    data, errors = PortManagerSchema(many=True).load(ports_info_dict, session=db.session)
    try:
        PortHandler.save_all(data)
    except DataException as e:
        PortHandler.rollback()
        error_log.error(f'update port failed, msg：{e}')
        software_error.error(f'update port failed, msg：{e}')
        return {"code": sc.AddFailed, "msg": e}
    info_log.info(f'update port success')
    return {"code": sc.Success, "data": ports_info_dict}


def get_ports_info():
    """"
	执行命令获取所有网口信息
	:return: list
	"""

    # 获取dpdk网口信息
    res = exec_cmd_on_path('echo %s | sudo -S ./dpdk_nic_bind.py -s --json' % config.PASSWORD, config.DPDK_PATH)
    res = json.loads(res)
    port_list, num = [], -1
    for info in res:
        port_info = {}
        interface = res[info]['Interface']
        # 中台每次创建新任务要更新网口，对于已经被使用的口获取不到Interface，就不记录了
        if not interface:
            continue
        data = netifaces.ifaddresses(interface)
        try:
            port_info['ip'] = data[2][0]['addr']
            port_info['netmask'] = data[2][0]['netmask']
            # port_info['broadcast'] = data[2][0]['broadcast']
        except Exception:
            pass
        port_info['status'] = ''
        port_info['is_manager'] = 1
        port_info['port'] = num
        port_info['pci'] = res[info]['Slot_str']
        port_info['mac'] = res[info]['MAC']
        port_info['port_name'] = res[info]['Interface']
        if num:
            port_info['status'] = 'release'
            port_info['is_manager'] = 0
        num += 1
        port_list.append(port_info)

    return port_list


def get_ports():
    """
	获取trex所有的端口信息
	:return: dict
	"""
    all_ports = PortHandler.get_all_ports()
    data, errors = PortManagerSchema(many=True).dump(all_ports)
    if errors:
        for key, message in errors.items():
            for i in message:
                return {"code": sc.GetPortFailed, "data": i}

    return {"code": sc.Success, "data": data}


def get_port_info_dict():
    '''
	普通端口详情与端口号的映射
	:return:
	{
		0: {},
		1: {}
	}
	'''
    port_obj_list = PortHandler.get_all_usual_ports()
    port_info_dict = {}
    for obj in port_obj_list:
        port_num = str(obj.port)
        port_detail = obj.to_dict()
        port_info_dict[port_num] = port_detail
    return port_info_dict


def port_info_dict_of_key_mac():
    '''
	普通端口详情与mac的映射
	:return:
	{
		"aa:bb:cc:dd:ff:ee": {},
	}
	'''
    port_obj_list = PortHandler.get_all_usual_ports()
    port_info_dict = {}
    for obj in port_obj_list:
        port_mac = str(obj.mac)
        port_detail = obj.to_dict()
        port_info_dict[port_mac] = port_detail
    return port_info_dict


def read_log(params):
    """
	读取日志信息
	:param params:
	:return:
	"""
    data = {}
    type = params.get('type')
    limit = int(params.get('limit')) if str(params.get('limit')).isdigit() else 20
    if not type or type not in LogType.LOG_TYPE_RESULT.keys():
        return {'code': sc.ParameterError}
    if type == LogType.error:
        log_file = 'error.log'
    if type == LogType.info:
        log_file = 'info.log'
    if type == LogType.system:
        log_file = 'flask.log'
    file_path = os.path.join(config.LOG_BASE_DIR, log_file)
    with open(file_path) as f:
        lines = f.readlines()
        lines = [i.replace('\n', '') for i in lines[-1:-1 - int(limit):-1]]
    data['type'] = type
    data['limit'] = len(lines)
    data['lines'] = lines
    return {'code': sc.Success, 'data': data}


def add_port_to_nic_conf_file2(add_ports_list):
    '''
	将网口配置写入netplan管理文件,并启动网卡
	:param add_ports_list:
	:return:
	'''
    conf_file_name = os.listdir("/etc/netplan/")[0]
    file_path = os.path.join("/etc/netplan/", conf_file_name)
    with open(file_path, 'r') as f:
        content = yaml.load(f.read())
        network = content["network"]
        all_ethernet = network.get("ethernets", {})
        for item in add_ports_list:
            port_name = item["port_name"]
            all_ethernet[port_name] = {"dhcp4": False}
        network["ethernets"] = all_ethernet
    yaml_file = open(file_path, 'w')
    yaml.dump(content, yaml_file, default_flow_style=False)
    yaml_file.close()
    exec_cmd("sudo netplan apply")


def add_port_to_nic_conf_file(add_ports_list):
    for item in add_ports_list:
        port_name = item["port_name"]
        exec_cmd(f"ip link set {port_name} up")


def ports_check_and_info(macs, is_out_net=False):
    ports_info_dict = get_ports_info()
    mac_port_info_mapping = {item["mac"]: item for item in ports_info_dict}
    add_ports_info, not_found_macs_from_server = [], []

    for i, mac in enumerate(macs):
        software_info.info(f"mac: {mac}")
        data = copy.copy(mac_port_info_mapping.get(mac))
        software_info.info(f"data: {data}")
        if not data:
            not_found_macs_from_server.append(mac)
        else:
            data['port'] = i
            add_ports_info.append(data)
    return add_ports_info, not_found_macs_from_server


def add_ports_for_middleground(macs):
    """
	添加网口 用于app task任务
	:return: dict
	"""
    add_ports_info, not_found_macs_from_server = ports_check_and_info(macs)
    if not_found_macs_from_server:
        raise UpdatePortException(code=sc.AddFailed, message=f"no port on the server:{not_found_macs_from_server}")

    add_port_to_nic_conf_file(add_ports_info)
    added_ports_info, _ = ports_check_and_info(macs)
    data, errors = PortManagerSchema(many=True).load(added_ports_info, session=db.session)
    try:
        PortHandler.save_all(data)
    except DataException as e:
        PortHandler.rollback()
        error_log.error(f'update port failed, msg：{e}')
        software_error.error(f'update port failed, msg：{e}')
        raise UpdatePortException(code=sc.AddFailed, message=str(e))
    info_log.info(f'update port success')
    return added_ports_info


def init_ports(network_infos):
    """
	初始化网口 用于流量task任务
	:return: dict
	"""
    macs = []
    is_out_net = False
    for networkInfo in network_infos:
        if networkInfo.get("mac"):
            macs.append(networkInfo.get("mac"))
        else:
            str_mac = exec_cmd(f"sudo ifconfig ens3|grep ether|tr -s ' ' |cut -d' ' -f3")
            mac = str(str_mac, 'utf-8').strip()
            networkInfo['mac'] = mac
            macs.append(mac)
            is_out_net = True

    add_ports_info, not_found_macs_from_server = ports_check_and_info(macs, is_out_net)
    if not_found_macs_from_server:
        raise UpdatePortException(code=sc.AddFailed, message=f"no port on the server:{not_found_macs_from_server}")

    add_port_to_nic_conf_file(add_ports_info)
    added_ports_info, _ = ports_check_and_info(macs, is_out_net)
    # 添加目标网口ip信息
    used_ips = []
    used_broadcast = []
    for port_info in added_ports_info:
        for networkInfo in network_infos:
            if networkInfo.get("mac") and networkInfo.get("mac") == port_info['mac']:
                # if not networkInfo.get("ip") in used_ips and not port_info.get("target_ip"):
                #     used_ips.append(networkInfo.get("ip"))
                #     port_info['target_ip'] = networkInfo.get("ip")
                #     port_info['netmask'] = networkInfo.get("networkId")
                if not networkInfo.get("nodeName") in used_broadcast and not port_info.get("broadcast"):
                    used_broadcast.append(networkInfo.get("nodeName"))
                    port_info['broadcast'] = networkInfo.get("nodeName")
                    port_info['target_ip'] = networkInfo.get("ip")
                    port_info['netmask'] = networkInfo.get("networkId")
    data, errors = PortManagerSchema(many=True).load(added_ports_info, session=db.session)
    try:
        PortHandler.delete_all()
        PortHandler.save_all(data)
    except DataException as e:
        PortHandler.rollback()
        error_log.error(f'update port failed, msg：{e}')
        software_error.error(f'update port failed, msg：{e}')
        raise UpdatePortException(code=sc.AddFailed, message=str(e))

    info_log.info(f'update port success')
    return added_ports_info, is_out_net


def init_networks(network_infos):
    """
    初始化网口
    """

    for networkInfo in network_infos:
        task_id = networkInfo.get("task_id")
        mac = networkInfo.get("mac")
        target_ip = networkInfo.get("target_ip")
        if not task_id:
            return {'code': sc.NotFound, 'msg': 'task_id can not be empty'}
        if not mac:
            return {'code': sc.NotFound, 'msg': 'mac can not be empty'}
        if not target_ip:
            return {'code': sc.NotFound, 'msg': 'target_ip can not be empty'}

        exist_task_ports = TaskPortManagerHandler.get_all_by_mac(mac)

        new_task_port = None
        port_num = None

        if exist_task_ports:
            # 遍历查找已经存在的任务网口关系
            for task_port_obj in exist_task_ports:
                port_num = task_port_obj.to_dict().get("port_num")
                if task_id == task_port_obj.to_dict().get("task_id"):
                    new_task_port = task_port_obj.to_dict()
                    task_port_obj.target_ip = target_ip
                    task_port_obj.mac = mac

                    res = exec_cmd_on_path('sudo -S ./dpdk_nic_bind.py -s --json', config.DPDK_PATH)
                    res = json.loads(res)
                    port_name = None
                    for info in res:
                        if mac == res[info]['MAC']:
                            port_name = res[info]['Interface']
                    if not port_name:
                        task_info.error(f"{mac} is not exist")
                        return resp_message(code=sc.MacNotExist)
                    task_port_obj.port_name = port_name
                    TaskPortManagerHandler.save(task_port_obj)

        if not new_task_port:
            # 不存在，则新增
            res = exec_cmd_on_path('sudo -S ./dpdk_nic_bind.py -s --json', config.DPDK_PATH)
            res = json.loads(res)
            port_name = None
            for info in res:
                if mac == res[info]['MAC']:
                    port_name = res[info]['Interface']
            if not port_name:
                task_info.error(f"{mac} is not exist")
                return resp_message(code=sc.MacNotExist)

            if not port_num:
                max_port_num = TaskPortManagerHandler.get_max_port_num()
                port_num = max_port_num + 1
            new_task_port = {
                "task_id": task_id,
                "port_name": port_name,
                "port_num": port_num,
                "target_ip": target_ip,
                "mac": mac
            }
            response, error = TaskPortManagerSchema().load(new_task_port, session=db.session)
            if error:
                task_info.error(error)
                return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
            TaskPortManagerHandler.save(response)

    return resp_message()


# def init_task_start_file(task_ports):
#     """
#     生成trex任务的配置文件
#     :param task_ports: 网络信息
#     :return:
#     """
#     task_info.info("=====init_task_start_file")
#     task_id = task_ports[0].get("task_id")
#     port_num = len(task_ports)
#     file_name = config.TREX_SERVER_PRE_NAME + task_id
#
#     # 解析网络结构中的数据
#     network_data = {
#         'version': 2,
#         'prefix': file_name,
#         'low_end': True
#     }
#     zmq_pub_port = get_available_port()
#     zmq_rpc_port = get_available_port()
#     network_data['zmq_pub_port'] = zmq_pub_port
#     network_data['zmq_rpc_port'] = zmq_rpc_port
#     network_data['port_info'] = []
#     network_data['interfaces'] = []
#
#     # local_ip = get_local_ip()
#     for i, task_port in enumerate(task_ports):
#         port_name = task_port.get("port_name")
#         target_ip = task_port.get("target_ip")
#         str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
#         port_ip = str(str_ip, 'utf-8').strip()
#         task_info.info(f"{port_name}===========port_ip：{port_ip}")
#         while not port_ip:
#             time.sleep(1)
#             str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
#             port_ip = str(str_ip, 'utf-8').strip()
#             task_info.info(f"{port_name}===========port_ip_again：{port_ip}")
#         # index = port_ip.rfind(".")
#         # gateway_ip = port_ip[0:index] + ".254"
#         network_data['interfaces'].append(port_name)
#         network_data['port_info'].append({
#             'ip': port_ip,
#             'default_gw': target_ip
#         })
#
#     # 网口不是偶数，补充一个"dummy"网口
#     if port_num % 2 != 0:
#         network_data['port_limit'] = port_num + 1
#         network_data['interfaces'].append('dummy')
#     else:
#         network_data['port_limit'] = port_num
#     task_info.info(f"init task start file result: {network_data}")
#
#     # 将组合的数据序列化到yaml文件中
#     new_trex_config_file_dir = os.path.join(config.BASE_DIR, 'media/trex_configs')
#     if not os.path.exists(new_trex_config_file_dir):
#         os.makedirs(new_trex_config_file_dir)
#     new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(file_name))
#     with open(new_trex_config_file_path, 'w+') as f:
#         yaml.dump([network_data], f, default_flow_style=False)
#     task_info.info("=====init_task_start_file end")