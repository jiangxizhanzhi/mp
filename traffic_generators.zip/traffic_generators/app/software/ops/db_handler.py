from sqlalchemy import desc

from app.software.models.software import PortManager


class PortHandler(PortManager):
    """
    PortManager数据库的操作
    """

    @classmethod
    def get_all_ports(cls):
        """"
        查询数据库获取所有网口
        """
        return cls.query.all()

    @classmethod
    def get_all_usual_ports(cls):
        """
        获取所有非管理口的端口
        :return:
        """
        return cls.query.filter(cls.is_manager == 0).all()

    @classmethod
    def get_ports_by_pci(cls, pci_list):
        """
        通过pci列表来获取对应的port对象
        :param pci_list: 端口的pci列表
        :return:
        """
        return cls.query.filter(cls.pci.in_(pci_list)).all()

    @classmethod
    def get_obj_by_port(cls, port):
        """
        通过网口获取port对象
        :param port: 网口
        :return:
        """
        port_obj = cls.query.filter(cls.port == port, cls.is_manager == 0, cls.status == 'acquire').first()
        return port_obj

    @classmethod
    def get_one_by_port(cls, port):
        """
        通过网口的序号获取port对象
        :param port: 网口
        :return:
        """
        return cls.query.filter(cls.port == port).first()

    @classmethod
    def get_one_by_port_mac(cls, mac):
        """
        通过网口mac获取port对象
        :param mac: 网口
        :return:
        """
        return cls.query.filter(cls.mac == mac).order_by(desc('create_time')).first()

    @classmethod
    def get_one_by_target_ip_and_mac(cls, target_ip, mac):
        """
        通过目标ip获取port对象
        :param target_ip: 网口
        :param mac: mac
        :return:
        """
        return cls.query.filter(cls.target_ip == target_ip, cls.mac == mac).order_by(desc('create_time')).first()

    @classmethod
    def get_one_by_node_name_and_mac(cls, node_name, mac):
        """
        通过目标节点名称获取port对象
        :param node_name: 节点名称
        :param mac: mac
        :return:
        """
        return cls.query.filter(cls.broadcast == node_name, cls.mac == mac).order_by(desc('create_time')).first()

    @classmethod
    def update_by_port(cls, port, values):
        cls.query.filter(cls.port == port).update(values)
        cls.commit()

    @classmethod
    def get_manager_port(cls):
        return cls.query.filter(cls.is_manager == 1).first()

    @classmethod
    def get_port_by_taskuuid_pci(cls, task_uuid, pci):
        return cls.query.filter(cls.task_uuid == task_uuid, cls.pci == pci, cls.status == 'acquire', cls.is_manager == 0).first()