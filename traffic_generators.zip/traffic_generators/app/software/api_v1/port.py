from flask_restplus import Namespace, Resource

from app.software.controller.software_manager import update_ports, get_ports
from utils.resp_util import resp_message

sw_port = Namespace('', description="Endpoint to manage ports")


@sw_port.route("/trex_ports")
class PortsManager(Resource):

	def get(self):
		"""
		获取trex所有的端口信息
		:param: 无
		:return: {
					"code": 1000,
					"msg": "success",
					"data": [
						{
						“uuid”:” ef023adbac0e_port”,
						“port”: 0,
						“is_manage”: 1,
						“pci”: “02:01.0”,
						“status”: “”,
						“ip”: ”192.168.33.183”,
						“netmask”: ”255.255.255.0”,
						“broadcast”: ”192.168.33.255”,
						“mac”: ” 00:0c:29:67:6a:1f”,
						"port_name": "ens33"
						“create_time”: “2021-04-08 11:17:51”,
						},
						......
					]
				}
		"""

		response = get_ports()
		return resp_message(**response)


	def post(self):
		"""
		更新端口并返回最新端口列表
		:param: 无
		:return: {
					"code": 1000,
					"msg": "success",
					"data": [
						{
						“uuid”:” ef023adbac0e_port”,
						“port”: 0,
						“is_manage”: 1,
						“pci”: “02:01.0”,
						“status”: “”,
						“ip”: ”192.168.33.183”,
						“netmask”: ”255.255.255.0”,
						“broadcast”: ”192.168.33.255”,
						“mac”: ” 00:0c:29:67:6a:1f”,
						"port_name": "ens33"
						“create_time”: “2021-04-08 11:17:51”,
						},
						......
					]
				}
		"""

		response = update_ports()
		return resp_message(**response)
