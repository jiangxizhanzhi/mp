from flask import request
from flask_restplus import Namespace, Resource

from app.software.controller.software_manager import read_log
from utils.resp_util import resp_message

sw_log = Namespace('', description="Endpoint to manage log file")


@sw_log.route('/read_log')
class LogManageApi(Resource):

    def get(self):
        """
        获取日志信息
        :return:
        """
        params = request.args.to_dict()
        response = read_log(params)
        return resp_message(**response)
