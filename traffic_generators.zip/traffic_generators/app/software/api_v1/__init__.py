from flask import Blueprint
from flask_restplus import Api

from app.software.api_v1.log_manage import sw_log
from app.software.api_v1.port import sw_port

software_blueprint = Blueprint('software_blueprint', __name__)
software_api = Api(software_blueprint, version='v1')

# 添加系统管理中的每个命名空间url, 也就是每个大模块下面的每个小模块分成不同的url
software_api.add_namespace(sw_port)
software_api.add_namespace(sw_log)

