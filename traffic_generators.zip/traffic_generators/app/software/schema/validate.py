from marshmallow import pre_load

from app import TaskPortManager
from app.software.models.software import PortManager
from extension import ma
from utils.util import generate_uuid


class PortManagerSchema(ma.ModelSchema):

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_port'
        return params

    class Meta:
        model = PortManager


class TaskPortManagerSchema(ma.ModelSchema):
    class Meta:
        model = TaskPortManager
