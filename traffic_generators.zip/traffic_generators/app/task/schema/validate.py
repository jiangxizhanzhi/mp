from marshmallow import fields, validate, pre_load, post_dump

from app.task.models.task import CustomTask, TaskResult, StandardTask, RFCTask, TaskFlowRecords, TaskAttackFlowRecords
from common.constant import DDosType, ValueSolution
from extension import ma
from utils.util import generate_uuid

IP_RE = '^((25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$'
MAC_RE = '^[A-Fa-f0-9]{2}(-[A-Fa-f0-9]{2}){5}$|^[A-Fa-f0-9]{2}(:[A-Fa-f0-9]{2}){5}$'


class CustomTaskSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(min=1, max=50, error='自定义任务的名称在1-50个字符之间')])
    description = fields.Str(required=False, validate=validate.Length(min=0, max=256, error='任务的描述信息在0-256个字符之间'))
    duration = fields.Int(required=False, default=-1)
    type = fields.Int(required=True, validate=validate.OneOf([1, 2], error='任务类型错误'))
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = CustomTask

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_task'
        return params


class TaskResultSchema(ma.ModelSchema):
    class Meta:
        model = TaskResult

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_taskResult'
        return params


class StandardTaskSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(min=1, max=50, error='标准任务的名称在1-50个字符之间')])
    description = fields.Str(required=False, validate=validate.Length(min=0, max=256, error='标准任务的描述信息在0-256个字符之间'))
    type = fields.Int(required=True, validate=validate.OneOf([1, 2, 3, 4], error='标准任务类型错误'))
    target_ip = fields.Str(required=False, validate=validate.Regexp(IP_RE, error='ip地址格式错误'))
    source_ip = fields.Str(required=False, validate=validate.Regexp(IP_RE, error='ip地址格式错误'))
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = StandardTask

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_standardTask'
        return params


# class EditDDosTaskSchema(ma.ModelSchema):
#     name = fields.Str(required=True, validate=[
#         validate.Length(min=1, max=100, error='{input} 长度在 {min} 和 {max} 之间'),
#         validate.Regexp(r'^[a-zA-Z0-9_]+$', error='名字只能为字母，数字或下划线.')
#     ])
#     config = fields.Method(required=True, deserialize='load_config', error_messages={"required": "请填写config配置"})

DDosTaskSchema = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "minLength": 1,
            "maxLength": 50,
            "pattern": r"^[a-zA-Z0-9_\u4e00-\u9fa5]+$"
        },
        "config": {
            "type": "object",
            "properties": {
                "network_structure": {
                    "type": "object",
                },
                "specifics": {
                    "type": "object",
                    "properties": {
                        "DDos_type": {
                            "type": "string",
                            "enum": list(DDosType.CHOICES_DICT.keys())
                        },
                        "duration": {
                            "type": "integer",
                        },
                        "src_ip_range": {
                            "type": "string",
                        },
                        "dst_ip": {
                            "type": "string",
                        },
                        "ip_op": {
                            "type": "integer",
                            "enum": list(ValueSolution.CHOICES_DICT.keys())
                        },
                        "src_port_range": {
                            "type": "string",
                        },
                        "port_op": {
                            "type": "integer",
                            "enum": list(ValueSolution.CHOICES_DICT.keys())
                        },
                        "DDos_mode": {
                            "type": "object",
                        },
                        "dst_port": {
                            "type": "integer",
                        },
                    },
                    'required': ["DDos_type", "duration", "src_ip_range", "dst_ip", "dst_port",
                                 "DDos_mode"],
                },
            },
            "required": ["network_structure", "specifics"],
        }
    },
    "required": ["name", "config"],
}

AppTaskSchema = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "minLength": 1,
            "maxLength": 50,
            "pattern": r"^[a-zA-Z0-9_\u4e00-\u9fa5]+$"
        },
        "config": {
            "type": "object",
            "properties": {
                "network_structure": {
                    "type": "object",
                },
                "specifics": {
                    "type": "object",
                    "properties": {
                        "duration": {
                            "type": "number",
                            "minimum": 0,
                            "exclusiveMaximum": 3600
                        },
                        "src_ip_range": {
                            "type": "string",
                        },
                        "dst_ip_range": {
                            "type": "string",
                        },
                        "cap_list": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "cps": {
                                        "type": "integer",
                                        "minimum": 1
                                    }
                                },
                                'required': ["name", "cps"],
                            },
                        },
                    },
                    'required': ["duration", "src_ip_range", "dst_ip_range", "cap_list"],
                },
            },
            "required": ["network_structure", "specifics"],
        }
    },
    "required": ["name", "config"],
}


class RFCTaskSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(min=1, max=50, error='rfc2544任务的名称在1-50个字符之间')])
    description = fields.Str(required=False, validate=[validate.Length(min=0, max=1024, error='任务的描述信息在0-1024个字符之间')])
    duration = fields.Int(required=True)
    rounds = fields.Int(required=True)
    type = fields.Int(required=True, validate=validate.OneOf([1, 2, 3, 4], error='测试类型错误'))
    source_port = fields.Int(required=True, validate=validate.Range(min=1, max=65535, error='源端口号应该在1-65535之间'))
    dst_port = fields.Int(required=True, validate=validate.Range(min=1, max=65535, error='目的端口号应该在1-65535之间'))
    source_ip = fields.Str(required=True, validate=validate.Regexp(regex=IP_RE, error='源IP地址格式不正确'))
    dst_ip = fields.Str(required=True, validate=validate.Regexp(regex=IP_RE, error='目的IP地址格式不正确'))
    source_mac = fields.Str(required=True, validate=validate.Regexp(regex=MAC_RE, error='源mac地址格式不正确'))
    dst_mac = fields.Str(required=True, validate=validate.Regexp(regex=MAC_RE, error='目的mac地址格式不正确'))
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = RFCTask

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_rfc'
        return params

    @post_dump
    def replace_null(self, data):
        """
        将数据库中为null的替换成空字符串
        :param data: 反序列化之后的字典
        :return:
        """
        return {k: v if v else '' for k, v in data.items()}


class TaskFlowRecordsSchema(ma.ModelSchema):
    class Meta:
        model = TaskFlowRecords


class TaskAttackFlowRecordsSchema(ma.ModelSchema):
    class Meta:
        model = TaskAttackFlowRecords
