import os
from datetime import datetime
from logging import getLogger
from threading import Thread

from openpyxl import Workbook

from app.software.ops.db_handler import PortHandler
from app.task.controller.task_manager import generate_start_file
from app.task.ops.db_handler import RFCTaskHandler, TaskResultHandler, RFCTaskResultHandler
from app.task.schema.validate import RFCTaskSchema, TaskResultSchema
from common import error_log, info_log
from common.constant import RFCType, TaskResultStatus, TaskAction, PortStatus, NetworkStructureType, ThreadingRecord, \
    TaskStatus, TrexClientRecord
from common.trex_handler import TrexDaemonHandler, TrexHandler
from config import TREX_HOST, BASE_DIR
from extension import db, cache
from utils import status_code as sc
from utils.exception_tools import DataException
from utils.util import stop_thread

task_error = getLogger('task_error')
task_info = getLogger('task_info')


def get_rfc_task_list(name, page, per_page, _type):
    """
    获取rfc2544任务的列表
    :param name: 任务的名称
    :param page: 页码
    :param per_page: 每页显示的数量
    :param _type: 测试类型
    :return:
    """
    page = int(page) if str(page).isdigit() else 1
    per_page = int(per_page) if str(per_page).isdigit() else 10
    _type = int(_type) if str(_type).isdigit() else None
    if _type and _type not in {RFCType.throughput, RFCType.frame_loss_rate, RFCType.latecy, RFCType.back_to_back_frame}:
        return {'code': sc.ParameterError, 'msg': '测试项类型错误'}
    task_items, total = RFCTaskHandler.get_all_by_filter(name, _type, page, per_page)
    response, error = RFCTaskSchema(many=True).dump(task_items)
    if error:
        error_log.error('RFC2544任务反序列化失败：{}'.format(error))
        task_error.error('RFC2544任务反序列化失败：{}'.format(error))
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    data = {
        'rows': response,
        'total': total
    }
    task_info.info('获取RFC2544任务的列表成功')
    info_log.info('获取RFC2544任务的列表成功')
    return {'code': sc.Success, 'data': data}


def create_rfc_task(req_data):
    """
    创建rfc2544任务
    :param req_data: 创建任务时的请求参数
    :return:
    """
    task_info.info('开始创建rfc2544任务')
    info_log.info('开始创建rfc2544任务')
    name = req_data.get('name')
    network_config = req_data.get('network_config')
    payload_mode = req_data.get('payload_mode')

    if not all([name, network_config, payload_mode]):
        return {'code': sc.MissingRequiredParameter}
    if not RFCTaskHandler.verify_unique_name(name):
        return {'code': sc.DuplicateName}
    response, error = RFCTaskSchema().load(req_data, session=db.session)

    if error:
        task_error.error('序列化RFC2544任务数据失败：{}'.format(error))
        error_log.error('序列化RFC2544任务数据失败：{}'.format(error))
        return {'code': sc.DataSerializationFailed, 'msg': error[list(error)[0]][0]}
    try:
        # 保存数据库
        RFCTaskHandler.save(response)
        task_info.info('创建RFC2544任务{}数据库记录成功'.format(response.uuid))
        info_log.info('创建RFC2544任务{}数据库记录成功'.format(response.uuid))
    except Exception as e:
        error_log.error('创建RFC2544任务保存入库失败：{}'.format(e))
        task_error.error('创建RFC2544任务保存入库失败：{}'.format(e))
        return {'code': sc.AddFailed}

    # 生成trex启动的配置文件
    generate_start_file(network_config, name)
    task_info.info('RFC2544任务成功生成trex启动的配置文件')
    info_log.info('RFC2544任务成功生成trex启动的配置文件')
    return {'code': sc.Success, 'data': response.uuid}


def delete_rfc_task(req_data):
    """
    删除rfc任务
    :param req_data:任务的uuid列表
    :return:
    """
    if not req_data:
        return {'code': sc.ParameterError}
    task_uuids = req_data.get('uuids')
    if not task_uuids:
        return {'code': sc.ParameterError, 'msg': '请选择需要删除的任务'}
    # 首先应该判断要删除的任务是否正在运行
    for _uuid in task_uuids:
        task = RFCTaskHandler.get_one_by_uuid(_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(_uuid)
        if task_result_obj and task_result_obj.status == TaskResultStatus.running:
            task_error.error('任务:{}正在运行中，无法删除'.format(task.name))
            error_log.error('任务:{}正在运行中，无法删除'.format(task.name))
            return {'code': sc.TaskRunning, 'msg': '任务正在运行中，无法删除'}
        else:
            # 删除生成的配置文件及缓存
            RFCTaskHandler.delete_trex_config_by_task_uuid(_uuid)
            # 删除缓存
            cache.delete(task.name + '_zmq_port')
            # 删除单个记录
            RFCTaskHandler.delete_one(task)
    task_info.info('删除RFC2544任务：{}成功'.format(task_uuids))
    info_log.info('删除RFC2544任务：{}成功'.format(task_uuids))
    return {'code': sc.Success}


def get_rfc_task_detail(uuid):
    """
    获取rfc2544任务的详情信息
    :param uuid: 任务的uuid
    :return:
    """
    task = RFCTaskHandler.get_one_by_uuid(uuid)
    if not task:
        return {'code': sc.NotFound, 'msg': '任务不存在'}
    response, _ = RFCTaskSchema().dump(task)
    task_info.info('获取RFC2544任务{}详情成功'.format(uuid))
    info_log.info('获取RFC2544任务{}详情成功'.format(uuid))
    return {'code': sc.Success, 'data': response}


def update_rfc_task(uuid, req_data):
    """
    更新rfc2544任务的信息
    :param uuid: 任务的uuid
    :return:
    """
    task_info.info('开始更新rfc2544任务')
    info_log.info('开始更新rfc2544任务')
    name = req_data.get('name')
    network_config = req_data.get('network_config')
    payload_mode = req_data.get('payload_mode')
    _type = req_data.get('type')
    task = RFCTaskHandler.get_one_by_uuid(uuid)
    if not task:
        return {'code': sc.NotFound, 'msg': '任务不存在'}
    if task.type != int(_type):
        return {'code': sc.ParameterError, 'msg': '测试类型不能修改'}
    if not all([name, network_config, payload_mode]):
        return {'code': sc.MissingRequiredParameter}
    if not RFCTaskHandler.verify_unique_name(name, exclude=uuid):
        return {'code': sc.DuplicateName}
    response, error = RFCTaskSchema(exclude=['uuid']).load(req_data, instance=task)
    if error:
        task_error.error('序列化RFC2544任务数据失败：{}'.format(error))
        error_log.error('序列化RFC2544任务数据失败：{}'.format(error))
        return {'code': sc.DataSerializationFailed, 'msg': error[list(error)[0]][0]}
    try:
        # 保存数据库
        RFCTaskHandler.save(response)
        task_info.info('更新RFC2544任务{}数据库记录成功'.format(response.uuid))
        info_log.info('更新RFC2544任务{}数据库记录成功'.format(response.uuid))
    except Exception as e:
        error_log.error('更新RFC2544任务保存入库失败：{}'.format(e))
        task_error.error('更新RFC2544任务保存入库失败：{}'.format(e))
        return {'code': sc.EditFailed}

    # 生成trex启动的配置文件
    generate_start_file(network_config, name)
    task_info.info('RFC2544任务成功重新生成trex启动的配置文件')
    info_log.info('RFC2544任务成功重新生成trex启动的配置文件')
    return {'code': sc.Success}


def rfc_task_operation(req_data):
    """
    rfc2544任务操作，包括:开始、停止、重置
    :param req_data: 请求参数，包括任务的uuid、操作的类型
    :return:
    """
    if not req_data:
        return {'code': sc.ParameterError}
    task_uuid = req_data.get('uuid')
    action = req_data.get('action')
    if not task_uuid or not action:
        return {'code': sc.MissingRequiredParameter}
    task = RFCTaskHandler.get_one_by_uuid(task_uuid)
    if not task:
        error_log.error('RFC2544任务{}不存在'.format(task_uuid))
        task_error.error('RFC2544任务{}不存在'.format(task_uuid))
        return {'code': sc.NotFound, 'msg': 'RFC2544任务不存在'}
    if not str(action).isdigit() or int(action) not in {TaskAction.start, TaskAction.stop}:
        return {'code': sc.TaskActionError}
    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        # 开始发送
        return start_testing(task)
    elif int(action) == TaskAction.stop:
        # 停止发送
        return stop_testing(task)
    elif int(action) == TaskAction.reset:
        # 重置发送
        return reset_testing(task)


def start_testing(task):
    """
    开始进行rfc2544测试
    :param task: 任务对象
    :return:
    """
    # 如果任务有不是停止的，则不能再次点击开始
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': '任务未停止，请停止后再次开始'}

    status_detail_list = []
    task_info.info('准备开始发送流量进行测试')
    info_log.info('准备开始发送流量进行测试')
    # 创建任务结果的数据库记录
    status_detail_list.append('正在启动trex服务')
    result_data = {
        'task_uuid': task.uuid,
        'status': TaskResultStatus.init,
        'status_detail': status_detail_list,
        'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    task_result_obj, errors = TaskResultSchema().load(result_data, session=db.session)
    if errors:
        error_log.error('创建任务结果记录失败: {}'.format(errors[list(errors)[0]][0]))
        task_error.error('创建任务结果记录失败: {}'.format(errors[list(errors)[0]][0]))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
    TaskResultHandler.save(task_result_obj)
    task_info.info('RFC2544任务的运行结果保存成功')
    info_log.info('RFC2544任务的运行结果保存成功')

    # 判断端口是否被占用
    network_config = task.network_config
    for client in network_config.get('client'):
        port_obj = PortHandler.get_one_by_port(client.get('port'))
        if port_obj and port_obj.status == PortStatus.acquire:
            status_detail_list.append('有端口正在被占用')
            task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped})
            return {'code': sc.PortAcquired}
    for server in network_config.get('server', []):
        port_obj = PortHandler.get_one_by_port(server.get('port'))
        if port_obj and port_obj.status == PortStatus.acquire:
            status_detail_list.append('有端口正在被占用')
            task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped})
            return {'code': sc.PortAcquired}
    trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task.name))
    # 启动一个trex的守护进程，其中的端口存到redis中, 目前默认是无状态
    daemon_server_status = TrexDaemonHandler.start_daemon_server(task.name, NetworkStructureType.stl)
    if not daemon_server_status:
        error_log.error('启动trex守护进程失败')
        task_error.error('启动trex守护进程失败')
        status_detail_list.append('启动trex守护进程失败')
        task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped})
        return {'code': sc.ExecuteCommandFail}
    task_info.info('启动RFC2544任务{}的trex守护进程成功，准备启动trex服务'.format(task.name))
    info_log.info('启动RFC2544任务{}的trex守护进程成功，准备启动trex服务'.format(task.name))
    trex_handler = TrexHandler(trex_host=TREX_HOST, trex_daemon_port=cache.get(task.name))
    try:
        trex_handler.start_stateless_server({'cfg': trex_config_path})
        status_detail_list.append('启动trex服务成功，正在检查配置文件信息及网络结构')
        task_result_obj.update(
            {'status': TaskResultStatus.running, 'status_detail': status_detail_list}
        )
        task_info.info('启动RFC2544任务{}的无状态trex服务成功，准备发送流量'.format(task.name))
        info_log.info('启动RFC2544任务{}的trex服务成功，准备发送流量'.format(task.name))

        # 根据任务表中的参数，开始发送流量
        from tasks.traffic_task import send_rfc_stateless_traffic
        th = Thread(target=send_rfc_stateless_traffic, args=(task.uuid,))
        th.start()
        # 将此线程存储到全局变量中，便于后续停止任务时，停止对应的线程
        ThreadingRecord.threads[task.uuid] = th
    except Exception as e:
        status_detail_list.append('启动trex服务失败')
        task_result_obj.update(
            {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'result_detail': '启动trex服务失败',
             'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
        )
        error_log.error('启动trex服务失败: {}'.format(e))
        task_error.error('启动无状态trex服务失败: {}'.format(e))
        # trex服务启动失败的话，将对应的守护进程也停止掉
        TrexDaemonHandler.stop_daemon_server(task.name, task.type)
        return {'code': sc.StartTrexServerFail}
    task_info.info('启动任务成功，正在异步发送测试流量')
    info_log.info('启动任务成功，正在异步发送测试流量')
    return {'code': sc.Success}


def stop_testing(task):
    """
    停止进行rfc2544测试
    :param task: 任务对象
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if not task_result_obj:
        return {'code': sc.NotFound, 'msg': '未找到任务运行结果记录'}
    status_detail_list = task_result_obj.status_detail
    status_detail_list.append('准备停止发送流量')
    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopping})
    # 将trex服务停止
    try:
        trex_handler = TrexHandler(trex_host=TREX_HOST, trex_daemon_port=cache.get(task.name))
        trex_handler.stop()
        # 将trex守护进程的服务停止
        TrexDaemonHandler.stop_daemon_server(task.name, task.type)
        th = ThreadingRecord.threads.get(task.uuid)
        if th:
            stop_thread(th)
    except (ConnectionRefusedError, Exception) as e:
        error_log.error('trex服务链接异常:{}'.format(e))
        task_error.error('trex服务链接异常:{}'.format(e))
    status_detail_list.append('trex服务已经停止')
    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped,
                            'end_time': datetime.now()})
    TrexClientRecord.clients.pop(task.uuid, None)

    # 将端口的acquire状态改为release
    network_config = task.network_config
    for client in network_config.get('client'):
        port_obj = PortHandler.get_one_by_port(client.get('port'))
        if port_obj:
            port_obj.update({'status': PortStatus.release})
    for server in network_config.get('server', []):
        port_obj = PortHandler.get_one_by_port(server.get('port'))
        if port_obj:
            port_obj.update({'status': PortStatus.release})

    # 将redis中缓存的端口信息清除
    cache.delete(task.name)
    ThreadingRecord.threads.pop(task.uuid, None)
    task_info.info('停止发送测试流量成功')
    info_log.info('停止发送测试流量成功')
    return {'code': sc.Success}


def reset_testing(task):
    """
    重置rfc2544测试
    :param task:
    :return:
    """
    # 首先判断任务状态是否为停止
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': '任务未停止，请停止任务后重试'}

    # 将任务结果中的数据全部清除
    TaskResultHandler.delete_task_results_by_task_uuid(task.uuid)
    # 将rfc_result表中的数据全部清除
    RFCTaskResultHandler.delete_results_by_task_uuid(task.uuid)
    task_info.info('任务结果中的数据已清除')
    info_log.info('任务结果中的数据已清除')
    # 调用开始发送流量的方法重新发送流量
    # return start_sending_traffic(task)
    return {'code': sc.Success}


def get_rfc_detail_result(task_uuid):
    """
    获取rfc任务的详情结果信息
    :param task_uuid: 任务的uuid
    :return:
    """
    task = RFCTaskHandler.get_one_by_uuid(task_uuid)
    if not task:
        return {'code': sc.NotFound, 'msg': '任务不存在'}
    rfc_result_objs = RFCTaskResultHandler.get_all_by_task_uuid(task_uuid)
    result_list = [obj.to_dict() for obj in rfc_result_objs]
    data = {
        'average_result': task.result,
        'result_list': result_list
    }
    return {'code': sc.Success, 'data': data}


def download_rfc_report(task_uuid):
    """
    根据任务的uuid下载任务的对应报告
    :param task_uuid: 任务的uuid
    :return:
    """
    task = RFCTaskHandler.get_one_by_uuid(task_uuid)
    if not task:
        error_log.error('下载rfc2544报告报错: 任务不存在')
        task_error.error('下载rfc2544报告报错: 任务不存在')
        raise DataException('任务不存在')
    task_results = RFCTaskResultHandler.get_all_by_task_uuid(task_uuid)
    wb = Workbook()  # 实例化操作表格的对象
    ws0 = wb.create_sheet('平均测试结果表', 0)
    ws0.merge_cells('A1:B1')
    ws0.cell(1, 1).value = 'RFC2544测试报告'
    ws0['A2'] = '帧长(字节)'
    if task.type == RFCType.throughput:
        # 吞吐量的报告
        ws1 = wb.create_sheet('RFC吞吐量结果表', 1)
        # 设置平均测试结果表的表头
        ws0['B2'] = '平均吞吐量(pps)'
        # 设置结果表的表头
        ws1['A2'] = '轮次'
        ws1['B2'] = '帧长(字节)'
        ws1['C2'] = '发送包数'
        ws1['D2'] = '接收包数'
        ws1['E2'] = '吞吐量(pps)'

    elif task.type == RFCType.frame_loss_rate:
        # 丢包率的报告
        ws1 = wb.create_sheet('RFC丢包率结果表', 1)
        # 设置平均测试结果表的表头
        ws0['B2'] = '平均丢包率(%)'
        # 设置结果表的表头
        ws1['A2'] = '轮次'
        ws1['B2'] = '帧长(字节)'
        ws1['C2'] = '发送包数'
        ws1['D2'] = '接收包数'
        ws1['E2'] = '丢包率(%)'
    elif task.type == RFCType.latecy:
        # 时延的报告
        ws1 = wb.create_sheet('RFC时延结果表', 1)
        # 设置平均测试结果表的表头
        ws0['B2'] = '平均时延(μs)'
        # 设置结果表的表头
        ws1['A2'] = '轮次'
        ws1['B2'] = '帧长(字节)'
        ws1['C2'] = '发送包数'
        ws1['D2'] = '接收包数'
        ws1['E2'] = '时延(μs)'
    else:
        # 背靠背的报告
        ws1 = wb.create_sheet('RFC背靠背帧结果表', 1)
        # 设置平均测试结果表的表头
        ws0['B2'] = '平均持续时间(s)'
        # 设置结果表的表头
        ws1['A2'] = '轮次'
        ws1['B2'] = '帧长(字节)'
        ws1['C2'] = '发送包数'
        ws1['D2'] = '接收包数'
        ws1['E2'] = '持续时间(s)'
    # 给第二个表格增加表头
    ws1.merge_cells('A1:H1')
    ws1.cell(1, 1).value = 'RFC2544测试报告'
    ws1['F2'] = '流量方向'
    ws1['G2'] = '持续时间(s)'
    ws1['H2'] = '时间'
    # 将第一个表中的数据填充上
    for index, _result in enumerate(task.result):
        ws0[f'A{index + 3}'] = list(_result.keys())[0]
        ws0[f'B{index + 3}'] = list(_result.values())[0]

    # 开始填充第二个表中的数据
    for index, task_result_obj in enumerate(task_results):
        ws1[f'A{index + 3}'] = task_result_obj.round
        ws1[f'B{index + 3}'] = task_result_obj.frame_length
        ws1[f'C{index + 3}'] = task_result_obj.transmit_packets
        ws1[f'D{index + 3}'] = task_result_obj.receive_packets
        ws1[f'E{index + 3}'] = task_result_obj.result
        ws1[f'F{index + 3}'] = '双向'
        ws1[f'G{index + 3}'] = task.duration
        ws1[f'H{index + 3}'] = task_result_obj.create_time
    report_dir_path = os.path.join(BASE_DIR, 'media/rfc_report')
    if not os.path.exists(report_dir_path):
        os.makedirs(report_dir_path, exist_ok=True)
    report_path = os.path.join(report_dir_path, '{}.xlsx'.format(task.name))
    wb.save(report_path)
    return report_path
