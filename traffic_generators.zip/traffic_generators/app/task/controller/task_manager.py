from trex_stl_lib.api import *
import json
import os
import queue
import time
from concurrent.futures.thread import ThreadPoolExecutor
from datetime import datetime
from logging import getLogger
from threading import Thread
import yaml

import config
from app.software.controller.software_manager import add_ports_for_middleground
from config import TREX_PLATFORM_NAME, TREX_DAEMON_SERVER_PORT_NAME, ATTACK_RUN_FINISHED_COUNT, BATCH_RUN_RESULT
from app.configure.ops.db_handler import CfgFlowsHandler, ProfileHandler, NetworkHandler
from app.monitor.ops.db_handler import TmpPcapHandler
from app.resources.ops.db_handler import FileDbManager, TagDbManager
from app.software.ops.db_handler import PortHandler
from app.task.ops.db_handler import CustomTaskHandler, TaskResultHandler, StandardTaskHandler, TaskFlowRecordsHandler, \
    TaskAttackFlowRecordsHandler, TaskPortManagerHandler
from app.task.schema.validate import CustomTaskSchema, TaskResultSchema, StandardTaskSchema
from common import error_log, info_log
from common.constant import TaskAction, TaskResultStatus, TaskStatus, ImageType, PortStatus, NetworkStructureType, \
    ThreadingRecord, ScriptMapping, TaskPortStatus
from common.trex_handler import TrexHandler, TrexDaemonHandler
from config import BASE_DIR, TREX_HOST, PASSWORD
from extension import db, cache
from utils import status_code as sc
from utils.exception_tools import UpdatePortException, APIException
from utils.redis_util import get_redis_client
from utils.resp_util import exec_cmd, resp_message
from utils.util import get_available_port, compress_files_to_one_file, stop_thread, get_ip, kill_processes


task_error = getLogger('task_error')
task_info = getLogger('task_info')


def create_custom_task(params):
    """
    创建自定义任务
    :param params: 创建自定义任务需要的参数
    :return:
    """
    task_info.info('开始创建自定义任务')
    info_log.info('开始创建自定义任务')
    # 校验请求参数
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    network_uuid = params.get('network_uuid')
    configuration_uuid = params.get('configuration_uuid')
    if not all([name, network_uuid, configuration_uuid]):
        return {'code': sc.MissingRequiredParameter}
    if not CustomTaskHandler.verify_unique_name(name):
        return {'code': sc.DuplicateName}
    network = NetworkHandler.get_one_by_uuid(network_uuid)
    if not network:
        return {'code': sc.NotFound, 'msg': '选择的网络结构不存在'}
    task_type = network.type
    params["type"] = task_type
    config_file = CfgFlowsHandler.get_one_by_uuid(
        configuration_uuid) if task_type == NetworkStructureType.astf else ProfileHandler.get_one_by_uuid(
        configuration_uuid)
    if not config_file:
        return {'code': sc.NotFound, 'msg': '选择的配置文件不存在'}
    response, errors = CustomTaskSchema().load(params, session=db.session)
    if errors:
        error_log.error('创建自定义任务报错：{}'.format(errors))
        task_error.error('创建自定义任务报错：{}'.format(errors))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
    try:
        # 保存数据库
        CustomTaskHandler.save(response)
        task_info.info('创建自定义任务{}数据库记录成功'.format(response.uuid))
        info_log.info('创建自定义任务{}数据库记录成功'.format(response.uuid))
    except Exception as e:
        error_log.error('创建自定义任务保存入库失败：{}'.format(e))
        task_error.error('创建自定义任务保存入库失败：{}'.format(e))
        return {'code': sc.AddFailed}
    return {'code': sc.Success, 'data': response.uuid}


def generate_start_file(network, name):
    """
    生成启动trex的配置文件,不是发送流量的配置文件
    :param network: 网络结构的对象
    :param name: 任务的名称
    :return:
    """
    # 解析网络结构中的数据
    network_data = {}
    network_data['version'] = 2
    network_data['prefix'] = name
    zmq_pub_port = get_available_port()
    zmq_rpc_port = get_available_port()
    network_data['zmq_pub_port'] = zmq_pub_port
    network_data['zmq_rpc_port'] = zmq_rpc_port

    # 将zmq_pub_port、zmq_rpc_port存储到redis中，方便后面发送流量时，连接客户端使用
    cache.set(name + '_zmq_port', json.dumps([zmq_rpc_port, zmq_pub_port]), timeout=-1)
    _network_data = analysis_network_data(network, network_data)

    # 将组合的数据序列化到yaml文件中
    new_trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs')
    if not os.path.exists(new_trex_config_file_dir):
        os.makedirs(new_trex_config_file_dir)
    new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(name))
    with open(new_trex_config_file_path, 'w+') as f:
        yaml.dump([_network_data], f, default_flow_style=False)
    return new_trex_config_file_path


def generate_stl_start_file(network, name):
    """
    生成启动无状态trex的配置文件,不是发送流量的配置文件
    :param network: 网络结构的对象
    :param name: 任务的名称
    :return:
    """
    # 解析网络结构中的数据
    network_data = {}
    network_data['version'] = 2
    network_data['prefix'] = name
    zmq_pub_port = get_available_port()
    zmq_rpc_port = get_available_port()
    network_data['zmq_pub_port'] = zmq_pub_port
    network_data['zmq_rpc_port'] = zmq_rpc_port

    # 将zmq_pub_port、zmq_rpc_port存储到redis中，方便后面发送流量时，连接客户端使用
    cache.set(name + '_zmq_port', json.dumps([zmq_rpc_port, zmq_pub_port]), timeout=-1)
    _network_data = analysis_stl_network_data(network, network_data)

    # 将组合的数据序列化到yaml文件中
    new_trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs')
    if not os.path.exists(new_trex_config_file_dir):
        os.makedirs(new_trex_config_file_dir)
    new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(name))
    with open(new_trex_config_file_path, 'w+') as f:
        yaml.dump([_network_data], f, default_flow_style=False)
    return new_trex_config_file_path


def init_trex_server(added_ports_info):
    """
    初始化trex服务
    :param added_ports_info:
    :param is_out_net:
    :return:
    """
    task_info.info("start to init trex server")
    init_stl_start_file(added_ports_info, TREX_PLATFORM_NAME)
    init_stl_server()
    task_info.info("end to init trex server")


def init_stl_start_file(added_ports_info, name):
    """
    生成启动trex的配置文件
    :param added_ports_info: 网络信息
    :param name: 任务的名称
    :return:
    """
    task_info.info("=====init_stl_start_file")
    # 解析网络结构中的数据
    network_data = {
        'version': 2,
        'prefix': name,
        'low_end': True
    }
    zmq_pub_port = get_available_port()
    zmq_rpc_port = get_available_port()
    network_data['zmq_pub_port'] = zmq_pub_port
    network_data['zmq_rpc_port'] = zmq_rpc_port

    # 将zmq_pub_port、zmq_rpc_port存储到redis中，方便后面发送流量时，连接客户端使用
    cache.set(name + '_zmq_port', json.dumps([zmq_rpc_port, zmq_pub_port]), timeout=-1)

    network_data['port_info'] = []
    network_data['interfaces'] = []
    sorted_added_ports_info = sorted(added_ports_info, key=lambda x: x['port'])
    port_num = len(sorted_added_ports_info)

    task_info.info(f"===========sorted_added_ports_info: {sorted_added_ports_info}")
    local_ip = get_ip(b'ens3')
    get_redis_client().set("LOCAL_IP", local_ip)
    str_mac = exec_cmd(f"sudo ifconfig ens3|grep ether|tr -s ' ' |cut -d' ' -f3")
    out_mac = str(str_mac, 'utf-8').strip()
    exec_cmd("sudo sysctl -w net.ipv4.ip_forward=1")
    exist_bradge = dict()
    for i, ports_info in enumerate(sorted_added_ports_info):
        br_name = "br" + str(i)
        network_id = ports_info.get('netmask')
        is_br_exist = False
        if not exist_bradge or not network_id in exist_bradge:
            exist_bradge[network_id] = br_name
        else:
            is_br_exist = True
            br_name = exist_bradge[network_id]

        veth_num = (i + 1) * 2
        str_veth1 = "veth" + str(veth_num - 1)
        str_veth2 = "veth" + str(veth_num)
        network_data['interfaces'].append(str_veth2)
        network_data['port_info'].append({'ip': ports_info.get('ip') if ports_info.get('ip') else local_ip,
                                          'default_gw': ports_info.get('target_ip')})

        if not is_br_exist:
            ens_name = ports_info.get("port_name")
            str_ip = exec_cmd(f"sudo ifconfig {ens_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
            ens_ip = str(str_ip, 'utf-8').strip()
            info_log.info(f"{ens_name}===========ens_ip：{ens_ip}")
            while not ens_ip:
                time.sleep(1)
                str_ip = exec_cmd(f"sudo ifconfig {ens_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
                ens_ip = str(str_ip, 'utf-8').strip()
                info_log.info(f"{ens_name}===========ens_ip_again：{ens_ip}")
            exec_cmd(f"sudo brctl addbr {br_name}")
            exec_cmd(f"sudo brctl setageing {br_name} 0")
            exec_cmd(f"sudo brctl addif {br_name} {ens_name}")
            exec_cmd(f"sudo ifconfig {ens_name} 0.0.0.0 up")
            exec_cmd(f"sudo ifconfig {br_name} {ens_ip}/24 up")

            if out_mac == ports_info.get("mac"):
                index = ens_ip.rfind(".")
                route_ip = ens_ip[0:index] + ".254"
                exec_cmd(f"sudo ip route add default via {route_ip} dev {br_name}")

        exec_cmd(f"sudo ip link add {str_veth1} type veth peer name {str_veth2}")
        exec_cmd(f"sudo brctl addif {br_name} {str_veth1}")
        if out_mac == ports_info.get("mac"):
            exec_cmd(f"ip link set dev {str_veth1} address {out_mac}")
        exec_cmd(f"sudo ip link set dev {str_veth1} up")
        exec_cmd(f"sudo ifconfig {str_veth2} 0.0.0.0 up ")
    exec_cmd("sudo iptables -P FORWARD ACCEPT")

    # 网口不是偶数，补充一个"dummy"网口
    if port_num % 2 != 0:
        network_data['port_limit'] = port_num + 1
        network_data['interfaces'].append('dummy')
    else:
        network_data['port_limit'] = port_num
    task_info.info(f"init stl start file result: {network_data}")

    # 将组合的数据序列化到yaml文件中
    new_trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs')
    if not os.path.exists(new_trex_config_file_dir):
        os.makedirs(new_trex_config_file_dir)
    new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(name))
    with open(new_trex_config_file_path, 'w+') as f:
        yaml.dump([network_data], f, default_flow_style=False)
    return new_trex_config_file_path


def init_stl_server():
    """
    初始化trex服务端
    :return:
    """
    try:
        # 根据任务生成的trex启动配置文件启动trex
        task_name = TREX_PLATFORM_NAME
        trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
        daemon_server_status = TrexDaemonHandler.start_daemon_server(task_name, NetworkStructureType.stl)
        daemon_port = cache.get(TREX_DAEMON_SERVER_PORT_NAME)
        task_info.info(f"init stl server trex_daemon_port：{daemon_port}")
        if not daemon_server_status or not daemon_port:
            task_info.error("init stl server trex daemon failed")
            raise APIException(sc.ExecuteCommandFail)

        trex_handler = TrexHandler(trex_host=TREX_HOST,
                                   trex_daemon_port=daemon_port,
                                   trex_args="")

        task_info.info("init stl trex server start")
        trex_handler.start_stateless_server({'cfg': trex_config_path})
        task_info.info("init stl trex server success")
    except Exception as e:
        task_info.error(f'init stl server trex service failed: {e}')
        try:
            # 关闭服务
            trex_handler.stop()
            # 关闭守护进程
            TrexDaemonHandler.stop_daemon_server(task_name, NetworkStructureType.stl)
        except Exception as e2:
            task_info.error(f'init stl server stop trex service failed: {e2}')
        # 删除缓存的守护进程port
        cache.delete(TREX_DAEMON_SERVER_PORT_NAME)
        raise APIException(sc.ExecuteCommandFail)


def delete_start_file(name):
    # 删除名称生成的配置文件
    trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs')
    trex_config_file_path = os.path.join(trex_config_file_dir, '{}.yaml'.format(name))
    if os.path.exists(trex_config_file_path):
        # 删除缓存
        cache.delete(name + '_zmq_port')
        os.remove(trex_config_file_path)


def analysis_network_data(network, network_data):
    """
    解析网络结构中的数据
    :param network: 网络结构的对象
    :param network_data: 保存解析的网络结构的字典
    :return:
    """
    network_data['port_info'] = []
    network_data['interfaces'] = []
    try:
        network_config = network.network_config
    except AttributeError:
        # 下面的是rfc2544使用的，因为没有在cfg_networkstructures表中存储数据
        network_config = network

    # 计算使用多少个端口
    server_port = network_config.get('server', [])
    client_port = network_config.get('client', [])
    server_port_num = len(server_port)
    client_port_num = len(client_port)
    task_info.info(f"server_port_num：{server_port_num}")
    if server_port_num == 0:
        # 无状态只使用client端口
        for _client in client_port:
            task_info.info(f"stateless mac：{_client.get('port')}")
            port_obj = PortHandler.get_one_by_port_mac(_client.get('port'))
            network_data['interfaces'].append(port_obj.pci)
            network_data['port_info'].append({'ip': _client.get('ip'), 'default_gw': _client.get('default_gw')})
        if client_port_num % 2 != 0:
            network_data['port_limit'] = client_port_num + 1
            network_data['interfaces'].append('dummy')
        else:
            network_data['port_limit'] = client_port_num
    else:
        # 有状态的client和server的数量必须是一致的，组合的port_info部分的顺序按照：前面是client，后面是server，一对来组合
        network_data['port_limit'] = client_port_num + server_port_num
        for i, _client in enumerate(client_port):
            _server = server_port[i]
            if _client == "dummy":  # 只有app task 使用
                network_data['interfaces'].append('dummy')
            else:
                network_data['port_info'].append({'ip': _client.get('ip'), 'default_gw': _client.get('default_gw')})
                client_port_obj = PortHandler.get_one_by_port(_client.get('port'))
                network_data['interfaces'].append(client_port_obj.pci)
            if _server == "dummy":  # 只有app task 使用
                network_data['interfaces'].append('dummy')
            else:
                network_data['port_info'].append(
                    {'ip': server_port[i].get('ip'), 'default_gw': _server.get('default_gw')})
                server_port_obj = PortHandler.get_one_by_port(_server.get('port'))
                network_data['interfaces'].append(server_port_obj.pci)

    return network_data


def analysis_stl_network_data(network, network_data):
    """
    解析网络结构中的数据
    :param network: 网络结构的对象
    :param network_data: 保存解析的网络结构的字典
    :return:
    """
    network_data['port_info'] = []
    network_data['interfaces'] = []
    network_config = network.network_config
    # 计算使用多少个端口
    client_port = network_config.get('client', [])
    client_port_num = len(client_port)

    # 无状态只使用client端口
    for _client in client_port:
        task_info.info(f"stateless mac：{_client.get('port')}")
        port_obj = PortHandler.get_one_by_port_mac(_client.get('port'))
        network_data['interfaces'].append(port_obj.pci)
        network_data['port_info'].append({'ip': _client.get('ip'), 'default_gw': _client.get('default_gw')})
    if client_port_num % 2 != 0:
        network_data['port_limit'] = client_port_num + 1
        network_data['interfaces'].append('dummy')
    else:
        network_data['port_limit'] = client_port_num
    network_data['low_end'] = True
    return network_data


def delete_custom_task(params):
    """
    删除自定义任务
    :param params: 自定义任务的uuid列表
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    task_uuids = params.get('uuids')
    # 首先应该判断要删除的自定义任务是否正在运行
    for _uuid in task_uuids:
        task = CustomTaskHandler.get_one_by_uuid(_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(_uuid)
        if task_result_obj and task_result_obj.status == TaskResultStatus.running:
            task_error.error('任务:{}正在运行中，无法删除'.format(task.name))
            error_log.error('任务:{}正在运行中，无法删除'.format(task.name))
            return {'code': sc.TaskRunning, 'msg': '任务正在运行中，无法删除'}
        else:
            # 删除生成的配置文件及缓存
            CustomTaskHandler.delete_trex_config_by_task_uuid(_uuid)
            # 删除缓存
            cache.delete(task.name + '_zmq_port')
            # 删除生成的流量包文件
            TmpPcapHandler.delete_pcap_files_by_task_uuid(_uuid)
            # 删除单个记录
            CustomTaskHandler.delete_one(task)
    task_info.info('删除自定义任务：{}成功'.format(task_uuids))
    info_log.info('删除自定义任务：{}成功'.format(task_uuids))
    return {'code': sc.Success}


def update_custom_task(uuid, params):
    """
    修改自定义任务的信息
    :param uuid: 任务的uuid
    :param params: 修改任务的信息参数
    :return:
    """
    # 校验请求参数
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    network_uuid = params.get('network_uuid')
    configuration_uuid = params.get('configuration_uuid')
    if not all([name, network_uuid, configuration_uuid]):
        return {'code': sc.MissingRequiredParameter}
    custom_task = CustomTaskHandler.get_one_by_uuid(uuid)
    if not custom_task:
        return {'code': sc.NotFound, 'msg': '未找到自定义任务记录'}

    # 判断任务是否正在运行
    task_result_obj = TaskResultHandler.get_one_task_result(uuid)
    if task_result_obj and task_result_obj.status == TaskResultStatus.running:
        return {'code': sc.TaskRunning, 'msg': '任务正在运行，无法编辑'}
    if not CustomTaskHandler.verify_unique_name(name, exclude=uuid):
        return {'code': sc.DuplicateName}
    network = NetworkHandler.get_one_by_uuid(network_uuid)
    if not network:
        return {'code': sc.NotFound, 'msg': '选择的网络结构不存在'}
    task_type = network.type
    params["type"] = task_type
    config_file = CfgFlowsHandler.get_one_by_uuid(
        configuration_uuid) if task_type == NetworkStructureType.astf else ProfileHandler.get_one_by_uuid(
        configuration_uuid)

    if not config_file:
        return {'code': sc.NotFound, 'msg': '选择的配置文件不存在'}

    task_old_name = custom_task.name
    response, errors = CustomTaskSchema(exclude=['uuid']).load(params, session=db.session, instance=custom_task)
    if errors:
        error_log.error('修改自定义任务报错：{}'.format(errors))
        task_error.error('修改自定义任务报错：{}'.format(errors))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}

    if task_old_name != name:
        delete_start_file(task_old_name)
    try:
        # 保存数据库
        CustomTaskHandler.save(response)
        task_info.info('修改自定义任务{}数据库记录成功'.format(uuid))
        info_log.info('修改自定义任务{}数据库记录成功'.format(uuid))
    except Exception as e:
        error_log.error('修改自定义任务{}保存入库失败:{}'.format(uuid, e))
        task_error.error('修改自定义任务{}保存入库失败:{}'.format(uuid, e))
        return {'code': sc.AddFailed}
    return {'code': sc.Success}


def get_custom_task_detail(uuid):
    """
    获取自定义任务的详情信息
    :param uuid: 自定义任务的uuid
    :return:
    """
    custom_task = CustomTaskHandler.get_one_by_uuid(uuid)
    if not custom_task:
        return {'code': sc.NotFound, 'msg': '未找到自定义任务记录'}
    response, _ = CustomTaskSchema().dump(custom_task)
    task_info.info('获取自定义任务{}详情成功'.format(uuid))
    info_log.info('获取自定义任务{}详情成功'.format(uuid))
    return {'code': sc.Success, 'data': response}


def get_custom_task_list(name, page, per_page, tag_id):
    """
    获取自定义任务的列表
    :param name: 任务的名称
    :param page: 页码
    :param per_page: 每页显示的数量
    :param tag_id: tag标签的id
    :return:
    """
    page = int(page) if str(page).isdigit() else 1
    per_page = int(per_page) if str(per_page).isdigit() else 10
    filters = []
    if name:
        filters.append(CustomTaskHandler.name.contains(name))
    if tag_id:
        tag_obj = TagDbManager.get_tag_by_id(int(tag_id))
        if not tag_obj:
            return {'code': sc.NotFound, 'msg': '未找到对应的tag信息'}
        filters.append(CustomTaskHandler.tag_id == int(tag_id))
    tasks, total = CustomTaskHandler.get_all_by_filter(page, per_page, filters)
    response, error = CustomTaskSchema(many=True, only=['uuid', 'name', 'tag_id', 'type', 'create_time', 'update_time',
                                                        'description']).dump(tasks)
    if error:
        error_log.error(error)
        task_error.error(error)
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    data = {
        'rows': response,
        'total': total
    }
    task_info.info('获取自定义任务的列表成功')
    info_log.info('获取自定义任务的列表成功')
    return {'code': sc.Success, 'data': data}


def task_operation(params):
    """
    任务操作
    :param params: 任务操作的一些参数，包含:任务uuid，任务的动作，1：开始， 2：停止， 3：重置
    :return:
    """
    # 校验参数
    if not params:
        return {'code': sc.ParameterError}
    task_uuid = params.get('uuid')
    action = params.get('action')
    # 传入任务调用时间，防止时区不对，时间对不上
    time = params.get('time')
    # 字符串转datetime
    task_time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
    if not task_uuid or not action:
        return {'code': sc.MissingRequiredParameter}
    task = StandardTaskHandler.get_one_by_uuid(task_uuid)
    if not task:
        task_info.error('stateless task {} not exist'.format(task_uuid))
        return {'code': sc.NotFound, 'msg': 'stateless task not exist'}
    if not str(action).isdigit() or int(action) not in {TaskAction.start, TaskAction.stop}:
        return {'code': sc.TaskActionError}

    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if action != 2 and task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        task_info.error("task is running, please try again later")
        return {'code': sc.TaskNotStopped, 'msg': 'task is running, please try again later'}
    status_detail_list = []
    status_detail_list.append('start running stateless task with global client')
    result_data = {
        'task_uuid': task.uuid,
        'status': TaskResultStatus.init,
        'status_detail': status_detail_list,
        'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

    task_result_obj, errors = TaskResultSchema().load(result_data, session=db.session)
    if errors:
        task_info.error('create task result failed: {}'.format(errors[list(errors)[0]][0]))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}

    TaskResultHandler.save(task_result_obj)

    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        # 新任务启动后，将之前流量记录状态设为失效
        TaskFlowRecordsHandler.batch_update_records_status(1, task_uuid)

        # 开始发送
        from tasks.traffic_task import send_stateless_traffic_with_global_client
        th = Thread(target=send_stateless_traffic_with_global_client, args=(task_uuid, task_time))
        th.start()

        ThreadingRecord.threads[task.uuid] = th
        return {'code': sc.Success}
    elif int(action) == TaskAction.stop:
        # 停止发送
        return stop_sending_traffic_with_global_client(task)


def task_batch_operation(params):
    """
    任务操作
    :param params: 任务操作的一些参数，包含:任务uuid，任务的动作，1：开始， 2：停止
    :return:
    """
    # 校验参数
    if not params:
        return {'code': sc.ParameterError}
    task_uuids = params.get('uuids')
    action = params.get('action')
    # 执行方式：0 串行，1 并行
    run_type = params.get('run_type')
    # 流量任务节点id
    node_id = params.get('node_id')
    time = params.get('time')

    # 字符串转datetime
    task_time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
    if not task_uuids or not action or not node_id or not time:
        return {'code': sc.MissingRequiredParameter}
    if not str(action).isdigit() or int(action) not in {TaskAction.start, TaskAction.stop}:
        return {'code': sc.TaskActionError}

    tasks = StandardTaskHandler.batch_get_by_uuids(task_uuids)
    if not tasks:
        task_info.error('batch exec tasks [{}] not exist'.format(task_uuids))
        return {'code': sc.NotFound, 'msg': 'stateless task not exist'}

    node_task_result_obj = TaskResultHandler.get_one_task_result(node_id)
    if action != 2 and node_task_result_obj and node_task_result_obj.status != TaskResultStatus.stopped:
        task_info.error("batch tasks are running, please try again later")
        return {'code': sc.TaskNotStopped, 'msg': 'batch tasks are running, please try again later'}

    node_status_detail_list = ['start running stateless task with global client']
    node_result_data = {
        'task_uuid': node_id,
        'status': TaskResultStatus.init,
        'status_detail': node_status_detail_list,
        'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    node_task_result_obj, errors = TaskResultSchema().load(node_result_data, session=db.session)
    if errors:
        task_info.error('create task result failed: {}'.format(errors[list(errors)[0]][0]))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}

    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        # 新任务启动后，将之前流量记录状态设为失效
        TaskFlowRecordsHandler.batch_update_records_status(1, node_id)
        # 新任务启动后，将之前攻击流量记录状态设为失效
        TaskAttackFlowRecordsHandler.batch_update_records_status(1, node_id)

        # 遍历创建每个任务的结果记录
        task_result_datas = [node_task_result_obj]
        # 攻击流量任务集合
        attack_task_ids = []
        # 背景流量任务集合
        background_task_ids = []
        for task in tasks:
            task_result_data = {
                'task_uuid': task.uuid,
                'status': TaskResultStatus.init,
                'status_detail': node_status_detail_list,
                'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            task_result_obj, batch_errors = TaskResultSchema().load(task_result_data, session=db.session)
            if batch_errors:
                task_info.error('batch create task result failed: {}'.format(batch_errors[list(batch_errors)[0]][0]))
                return {'code': sc.DataSerializationFailed, 'msg': batch_errors[list(batch_errors)[0]][0]}
            task_result_datas.append(task_result_obj)

            # 区分流量任务类型
            if not task.file_resource_uuid:
                background_task_ids.append(task.uuid)
            else:
                attack_task_ids.append(task.uuid)

        TaskResultHandler.save_all(task_result_datas)
        # 重置任务批量运行结果
        get_redis_client().delete(BATCH_RUN_RESULT + node_id)
        if 1 == run_type:
            # 并行运行
            if len(background_task_ids) > 0:
                # 设置背景流量运行标志
                get_redis_client().lpush(BATCH_RUN_RESULT + node_id, "BACKGROUND")
                from tasks.traffic_task import batch_send_traffic_with_global_client
                th = Thread(target=batch_send_traffic_with_global_client,
                            args=(background_task_ids, node_id, task_time))
                th.start()
                # 批量运行背景流量线程id
                ThreadingRecord.threads['background' + node_id] = th

            if len(attack_task_ids) > 0:
                # 设置攻击流量运行标志
                get_redis_client().lpush(BATCH_RUN_RESULT + node_id, "ATTACK")
                th = Thread(target=batch_running_attack_script, args=(attack_task_ids, node_id, task_time))
                th.start()
                # 批量运行攻击流量线程id
                ThreadingRecord.threads['attack' + node_id] = th
        else:
            # 串行运行
            from tasks.traffic_task import sync_batch_send_all
            th = Thread(target=sync_batch_send_all, args=(task_uuids, node_id, task_time))
            th.start()
            ThreadingRecord.threads['sync_all' + node_id] = th
        return {'code': sc.Success}
    else:
        # 停止发送
        return batch_stop_sending_traffic_with_global_client(task_uuids, node_id)


def batch_running_attack_script(task_uuids, node_id, task_time):
    """
    批量运行攻击脚本
    :param task_uuids: 任务ids
    :param node_id: 节点id
    :return:
    """
    from manage import app
    with app.app_context():
        task_info.info("batch start to run attack script")
        # 重置运行结束数量
        get_redis_client().set(ATTACK_RUN_FINISHED_COUNT + node_id, 0)
        task = StandardTaskHandler.get_one_by_uuid(task_uuids[0])
        # 查询端口的详细信息
        port_obj = PortHandler.get_one_by_port_mac(task.port)
        from tasks.traffic_task import get_port_flow_status
        # 起线程获取网口流量状态
        get_port_status_attack_th = Thread(target=get_port_flow_status, args=(port_obj.port_name, node_id, task_time))
        get_port_status_attack_th.start()
        ThreadingRecord.threads['get_port_status_attack_th' + node_id] = get_port_status_attack_th

        # 并发运行
        thread_pool = ThreadPoolExecutor(max_workers=5)
        for task_uuid in task_uuids:
            thread_pool.submit(batch_start_running_attack_script, task_uuid, node_id)
            # th = Thread(target=batch_start_running_attack_script, args=(task_uuid, node_id))
            # th.start()

        thread_pool.shutdown(wait=True)
        finished_count = get_redis_client().get(ATTACK_RUN_FINISHED_COUNT + node_id)
        task_info.info(f'attack task total count: {len(task_uuids)}, finished num count: {finished_count}')
        while int(finished_count) < len(task_uuids):
            # 所有攻击任务运行结束，才继续执行
            time.sleep(1)
            finished_count = get_redis_client().get(ATTACK_RUN_FINISHED_COUNT + node_id)
        # 攻击流量运行结束，删除运行标志，停止获取运行记录
        get_redis_client().lpop(BATCH_RUN_RESULT + node_id)
        if 0 == get_redis_client().llen(BATCH_RUN_RESULT + node_id):
            task_info.info(f'batch run attack task end')
            # 更新任务批量运行状态为结束
            node_task_result = TaskResultHandler.get_one_task_result(node_id)
            node_task_result.update({
                'result': TaskStatus.success,
                'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': TaskResultStatus.stopped
            })

            # 停止获取攻击流量记录
            stop_thread(get_port_status_attack_th)
            ThreadingRecord.threads.pop('get_port_status_attack_th' + node_id, None)

            # 停止获取背景流量记录
            get_port_status_background_th = ThreadingRecord.threads.get('get_port_status_background_th' + node_id)
            stop_thread(get_port_status_background_th)
            ThreadingRecord.threads.pop('get_port_status_background_th' + node_id, None)


def start_sending_traffic(task, task_time):
    """
    开启启动trex，并且发送流量
    :param task_time: 任务开始时间
    :param task: 任务对象
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': 'task is running, please try again later'}
    status_detail_list = []
    try:
        status_detail_list.append('start running stateless task')
        result_data = {
            'task_uuid': task.uuid,
            'status': TaskResultStatus.init,
            'status_detail': status_detail_list,
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        task_result_obj, errors = TaskResultSchema().load(result_data, session=db.session)
        if errors:
            task_error.error('create task result failed: {}'.format(errors[list(errors)[0]][0]))
            return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
        TaskResultHandler.save(task_result_obj)
        task_info.info('init stateless task result success')

        # 根据任务表中的参数，开始发送流量
        from tasks.traffic_task import send_stateless_traffic
        th = Thread(target=send_stateless_traffic, args=(task.uuid, task_time))
        th.start()
        # 将此线程存储到全局变量中，便于后续停止任务时，停止对应的线程
        ThreadingRecord.threads[task.uuid] = th
    except Exception as e:
        status_detail_list.append('call stateless trex service failed')
        task_result_obj.update(
            {'status_detail': status_detail_list, 'result': TaskStatus.fail,
             'result_detail': 'call stateless trex service failed',
             'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
        )
        task_error.error('call stateless trex service failed: {}'.format(e))
        return {'code': sc.StartTrexServerFail}
    task_info.info('call stateless trex service success，prepare to send flow')
    return {'code': sc.Success}


def stop_sending_traffic_with_global_client(task):
    """
    停止发送流量
    :param task: 任务对象
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if not task_result_obj:
        return {'code': sc.NotFound, 'msg': 'task result not found'}
    status_detail_list = task_result_obj.status_detail
    status_detail_list.append('prepare to stop sending stateless flow')
    task_result_obj.update(
        {'status_detail': status_detail_list, 'status': TaskResultStatus.stopping, 'result': TaskStatus.success})

    # 将trex任务停止
    try:
        th = ThreadingRecord.threads.get(task.uuid)
        if th:
            stop_thread(th)
            ThreadingRecord.threads.pop(task.uuid, None)
            task_info.info('stop sending stateless flow success')
            status_detail_list.append('trex task has stopped')

        th_status = ThreadingRecord.threads.get(task.uuid + "_status")
        if th_status:
            ThreadingRecord.threads.pop(task.uuid + "_status", None)
            stop_thread(th_status)
            task_info.info('stop get stateless flow status success')
    except Exception as e:
        status_detail_list.append('trex task stopped failed')
        task_error.error('stop sending stateless flow failed:{}'.format(e))

    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped,
                            'end_time': datetime.now()})
    ThreadingRecord.threads.pop(task.uuid, None)
    return {'code': sc.Success}


def batch_stop_sending_traffic_with_global_client(task_uuids, node_id):
    """
    停止批量发送流量
    :param task_uuids:
    :param node_id:
    :return:
    """
    tasks = TaskResultHandler.batch_get_by_uuids(task_uuids)
    if not tasks:
        task_info.info("batch stop tasks result is empty")

    TaskResultHandler.batch_update_result_status(TaskResultStatus.stopping, TaskStatus.fail, task_uuids)
    task_uuids.append(node_id)
    try:
        # 停止背景流量线程
        th_background = ThreadingRecord.threads.get('background' + node_id)
        if th_background:
            stop_thread(th_background)
            ThreadingRecord.threads.pop('background' + node_id, None)
            task_info.info('batch stop sending [background] flow success')

        # 停止攻击流量线程
        th_attack = ThreadingRecord.threads.get('attack' + node_id)
        if th_attack:
            stop_thread(th_attack)
            ThreadingRecord.threads.pop('attack' + node_id, None)
            task_info.info('batch stop sending [attack] flow success')

        th_sync_all = ThreadingRecord.threads.get('sync_all' + node_id)
        if th_sync_all:
            stop_thread(th_sync_all)
            ThreadingRecord.threads.pop('sync_all' + node_id, None)
            task_info.info('batch stop [sync_all] flow success')

        # 停止流量状态线程
        sync_batch_get_attack_status_th = ThreadingRecord.threads.get('sync_batch_get_attack_status' + node_id)
        if sync_batch_get_attack_status_th and sync_batch_get_attack_status_th.ident:
            stop_thread(sync_batch_get_attack_status_th)
            ThreadingRecord.threads.pop('sync_batch_get_attack_status' + node_id, None)
            task_info.info('batch stop [sync_batch_get_attack_status] flow success')

        sync_batch_get_background_status_th = ThreadingRecord.threads.get('sync_batch_get_background_status' + node_id)
        if sync_batch_get_background_status_th and sync_batch_get_background_status_th.ident:
            stop_thread(sync_batch_get_background_status_th)
            ThreadingRecord.threads.pop('sync_batch_get_background_status' + node_id, None)
            task_info.info('batch stop [sync_batch_get_background_status] flow success')

        get_port_status_attack_th = ThreadingRecord.threads.get('get_port_status_attack_th' + node_id)
        if get_port_status_attack_th and get_port_status_attack_th.ident:
            stop_thread(get_port_status_attack_th)
            ThreadingRecord.threads.pop('get_port_status_attack_th' + node_id, None)
            task_info.info('batch stop [get_port_status_attack_th] flow success')

        get_port_status_background_th = ThreadingRecord.threads.get('get_port_status_background_th' + node_id)
        if get_port_status_background_th and get_port_status_background_th.ident:
            stop_thread(get_port_status_background_th)
            ThreadingRecord.threads.pop('get_port_status_background_th' + node_id, None)
            task_info.info('batch stop [get_port_status_background_th] flow success')

    except Exception as e:
        task_error.error('batch stop sending stateless flow failed:{}'.format(e))
        return {'code': sc.SystemError}

    TaskResultHandler.batch_update_result_status(TaskResultStatus.stopped, TaskStatus.fail, task_uuids)
    ThreadingRecord.threads.pop('background' + node_id, None)
    ThreadingRecord.threads.pop('attack' + node_id, None)
    return {'code': sc.Success}


def stop_sending_traffic(task):
    """
    停止发送流量，并且停止trex服务
    :param task: 任务对象
    :return:
    """
    from trex_stl_lib.api import STLClient
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if not task_result_obj:
        return {'code': sc.NotFound, 'msg': 'task result not found'}
    status_detail_list = task_result_obj.status_detail
    status_detail_list.append('prepare to stop sending stateless flow')
    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopping})
    # 将trex服务停止
    try:
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        # 获取trex启动的时候，是以ipv4启动的，还是ipv6启动的
        trex_args = '' if network.ip_versions == 'ipv4' else 'ipv6'
        daemon_port = cache.get(TREX_DAEMON_SERVER_PORT_NAME)
        trex_handler = TrexHandler(trex_host=TREX_HOST,
                                   trex_daemon_port=daemon_port,
                                   trex_args=trex_args)

        sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
        task_info.info(f"stop stateless task client, sync_port：{sync_port}, async_port:{async_port}")
        stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)
        stl_client.connect()

        # 将端口全部重置，排除影响
        stl_client.reset()
        stl_client.acquire()
        stl_client.stop()
        stl_client.release()

        # 关闭服务
        trex_handler.stop()
        th = ThreadingRecord.threads.get(task.uuid)
        if th:
            stop_thread(th)
    except (ConnectionRefusedError, Exception) as e:
        task_error.error('connect trex service failed:{}'.format(e))
    status_detail_list.append('trex service has stopped')
    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped,
                            'end_time': datetime.now()})

    # 删除启动trex配置文件及缓存
    ThreadingRecord.threads.pop(task.uuid, None)
    task_info.info('stop sending stateless flow success')
    return {'code': sc.Success}


def reset_sending_traffic(task):
    """
    清除任务结果
    :param task: 任务对象
    :return:
    """
    # 首先判断任务状态是否为停止
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': '任务未停止，请停止任务后重试'}

    # 将任务结果中的数据全部清除
    TaskResultHandler.delete_task_results_by_task_uuid(task.uuid)
    # 将捕获的流量包清除
    TmpPcapHandler.delete_pcap_files_by_task_uuid(task.uuid)
    TmpPcapHandler.delete_by_task_uuid(task.uuid)
    task_info.info('任务结果中的数据已清除')
    info_log.info('任务结果中的数据已清除')
    return {'code': sc.Success}


def all_task_result_of_task(uuid, standard_task=False):
    """
    获取任务的所有结果
    :param uuid: 任务的uuid
    :param standard_task: 是否是标准任务，默认为False
    :return:
    """
    if standard_task:
        standard_task_obj = StandardTaskHandler.get_one_by_uuid(uuid)
        if not standard_task_obj:
            return {'code': sc.NotFound, 'msg': '未找到标准实验室任务记录'}
    else:
        custom_task = CustomTaskHandler.get_one_by_uuid(uuid)
        if not custom_task:
            return {'code': sc.NotFound, 'msg': '未找到自定义任务记录'}
    task_result_objs = TaskResultHandler.stopped_task_result_by_task_uuid(uuid)
    task_result_list = []
    for obj in task_result_objs:
        result_info = obj.to_dict()
        task_result_list.append(result_info)
    task_info.info('获取任务的所有历史结果成功')
    return {'code': sc.Success, 'data': task_result_list}


def create_standard_task(params):
    """
    根据type类型创建标准实验室任务，包括：扫描、爆破、其他
    :param params:
    :return:
    """
    info_log.info('start to create standard task')
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    _type = params.get('type')
    port = params.get('port')
    target_ip = params.get('target_ip')
    source_ip = params.get('source_ip')
    file_resource_uuid = params.get('file_resource_uuid')
    if not all([name, _type, file_resource_uuid, port, target_ip, source_ip]):
        return {'code': sc.MissingRequiredParameter}
    unique_name = StandardTaskHandler.verify_unique_name(name)
    if not unique_name:
        return {'code': sc.DuplicateName}
    # 资源从项目数据库中获取
    file_resource_obj = FileDbManager.get_one_by_uuid(file_resource_uuid)
    if not file_resource_obj:
        return {'code': sc.NotFound, 'msg': 'acctck script not exist'}
    if file_resource_obj.type != ScriptMapping.attack_scripts.value:
        return {'code': sc.FileResourceTypeError}
    # 给中台使用，port obj 以mac多地址查找
    port_obj = PortHandler.get_one_by_port_mac(port)
    if not port_obj:
        # 更新port
        try:
            add_ports_for_middleground([port])
        except UpdatePortException as e:
            return {'code': sc.ParameterError, 'msg': e}
    port_obj = PortHandler.get_one_by_port_mac(port)
    if not port_obj:
        return {'code': sc.NotFound, 'msg': 'selected port not exist'}
    response, errors = StandardTaskSchema().load(params, session=db.session)
    if errors:
        error_log.error('create standard task error：{}'.format(errors))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
    try:
        # 保存数据库
        StandardTaskHandler.save(response)
        info_log.info('save standard task {} record success'.format(response.uuid))
        return {'code': sc.Success, 'data': response.uuid}
    except Exception as e:
        error_log.error('save standard task failed：{}'.format(e))
        return {'code': sc.AddFailed}


def get_standard_task_list(params):
    """
    获取标准实验室任务的列表
    :param params: 获取标准实验室任务中的请求参数
    :return:
    """
    name = params.get('name')
    type = params.get('type')
    page = params.get('page')
    per_page = params.get('per_page')
    page = int(page) if str(page).isdigit() else 1
    per_page = int(per_page) if str(per_page).isdigit() else 10
    type = int(type) if type else None
    task_items, total = StandardTaskHandler.get_all_by_filter(name, type, page, per_page)
    response, error = StandardTaskSchema(many=True, exclude=['config']).dump(task_items)
    task_uuids = [row["uuid"] for row in response]
    result_info_of_task = TaskResultHandler.latest_result_info_of_batch_task(task_uuids)
    for row in response:
        task_uuid = row["uuid"]
        result_record_info = result_info_of_task.get(task_uuid)
        status = ""
        if result_record_info:
            status = result_record_info["status"]
        row["status"] = status
    if error:
        error_log.error('标准实验室任务反序列化失败：{}'.format(error))
        task_error.error('标准实验室任务反序列化失败：{}'.format(error))
        return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
    data = {
        'rows': response,
        'total': total
    }
    task_info.info('获取标准实验室任务的列表成功')
    info_log.info('获取标准实验室任务的列表成功')
    return {'code': sc.Success, 'data': data}


def delete_standard_task(params):
    """
    删除标准实验室任务
    :param params: 标准实验室任务的uuid的列表
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    standard_task_uuids = params.get('uuids')
    # 首先应该判断要删除的自定义任务是否正在运行
    for _uuid in standard_task_uuids:
        task = StandardTaskHandler.get_one_by_uuid(_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(_uuid)
        if task_result_obj and task_result_obj.status == TaskResultStatus.running:
            error_log.error('task: {} is running, can not delete'.format(task.name))
            return {'code': sc.TaskRunning, 'msg': 'task is running,can not delete'}
        else:
            StandardTaskHandler.delete_one(task)
    info_log.info('delete standard task: {} success'.format(standard_task_uuids))
    return {'code': sc.Success}


def get_standard_task_detail(uuid):
    """
    获取标准实验室任务的详情信息
    :param uuid: 标准任务的uuid
    :return:
    """
    standard_task = StandardTaskHandler.get_one_by_uuid(uuid)
    if not standard_task:
        return {'code': sc.NotFound, 'msg': '标准任务不存在'}
    response, _ = StandardTaskSchema(exclude=['config']).dump(standard_task)
    task_info.info('获取标准实验室任务{}详情成功'.format(uuid))
    info_log.info('获取标准实验室任务{}详情成功'.format(uuid))
    return {'code': sc.Success, 'data': response}


def update_standard_task(uuid, params):
    """
    更新标准实验室任务的信息
    :param uuid: 标准实验室任务的uuid
    :param params: 标准实验室任务的参数
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    name = params.get('name')
    _type = params.get('type')
    port = params.get('port')
    target_ip = params.get('target_ip')
    source_ip = params.get('source_ip')
    file_resource_uuid = params.get('file_resource_uuid')
    if not all([name, _type, file_resource_uuid, port, target_ip, source_ip]):
        return {'code': sc.MissingRequiredParameter}
    standard_task_obj = StandardTaskHandler.get_one_by_uuid(uuid)
    if not standard_task_obj:
        return {'code': sc.NotFound, 'msg': 'standard task not exist'}
    unique_name = StandardTaskHandler.verify_unique_name(name, exclude=uuid)
    if not unique_name:
        return {'code': sc.DuplicateName}
    task_result_obj = TaskResultHandler.get_one_task_result(uuid)
    if task_result_obj and task_result_obj.status == TaskResultStatus.running:
        return {'code': sc.TaskRunning, 'msg': 'can not edit running task'}

    file_resource_obj = FileDbManager.get_one_by_uuid(file_resource_uuid)
    if not file_resource_obj:
        return {'code': sc.NotFound, 'msg': 'attack script not exist'}
    port_obj = PortHandler.get_one_by_port_mac(port)
    if not port_obj:
        return {'code': sc.NotFound, 'msg': 'selected port not exist'}
    response, errors = StandardTaskSchema(exclude=['uuid']).load(params, session=db.session, instance=standard_task_obj)
    if errors:
        error_log.error('update standard task failed:{}'.format(errors))
        return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
    try:
        # 保存数据库
        StandardTaskHandler.save(response)
        info_log.info('update standard task {} success'.format(response.uuid))
    except Exception as e:
        error_log.error('update standard task failed:{}'.format(e))
        return {'code': sc.EditFailed}
    return {'code': sc.Success}


def custom_task_action(params):
    """
    操作自定义任务，包括：开始，停止，重置
    :param params: 操作自定义任务的请求参数
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    task_uuid = params.get('uuid')
    action = params.get('action')
    time = params.get('time')

    # 字符串转datetime
    task_time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
    if not task_uuid or not action:
        return {'code': sc.MissingRequiredParameter}
    task = StandardTaskHandler.get_one_by_uuid(task_uuid)

    if not task:
        task_error.error('custom task {} not exist'.format(task_uuid))
        return {'code': sc.NotFound, 'msg': 'custom task not exist'}
    if not str(action).isdigit() or int(action) not in {TaskAction.start, TaskAction.stop}:
        return {'code': sc.TaskActionError}

    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        # 开始发送
        return start_custom_traffic(task, task_time)


def start_custom_traffic(task, task_time):
    """
    构建自定义流量，并且发送流量
    :param task_time: 任务开始时间
    :param task: 任务对象
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': 'task is running, please try again later'}
    status_detail_list = []
    try:
        status_detail_list.append('start running custom task')
        result_data = {
            'task_uuid': task.uuid,
            'status': TaskResultStatus.init,
            'status_detail': status_detail_list,
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        task_result_obj, errors = TaskResultSchema().load(result_data, session=db.session)
        if errors:
            task_error.error('create custom task result failed: {}'.format(errors[list(errors)[0]][0]))
            return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
        TaskResultHandler.save(task_result_obj)
        task_info.info('init custom task result success')

        # 根据任务表中的参数，开始发送流量
        from tasks.traffic_task import send_custom_traffic
        th = Thread(target=send_custom_traffic, args=(task.uuid, task_time,))
        th.start()

        # 将此线程存储到全局变量中，便于后续停止任务时，停止对应的线程
        ThreadingRecord.threads[task.uuid] = th
    except Exception as e:
        status_detail_list.append('call custom trex service failed')
        task_result_obj.update(
            {'status_detail': status_detail_list, 'result': TaskStatus.fail,
             'result_detail': 'call custom trex service failed',
             'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
        )
        task_error.error('call custom trex service failed: {}'.format(e))
        return {'code': sc.StartTrexServerFail}
    task_info.info('call custom trex service success，prepare to send flow')
    return {'code': sc.Success}


def standard_task_action(params):
    """
    操作标准实验室任务，包括：开始，停止，重置
    :param params: 操作标准实验室任务的请求参数
    :return:
    """
    if not params:
        return {'code': sc.ParameterError}
    task_uuid = params.get('uuid')
    action = params.get('action')
    time = params.get('time')  # 传入任务调用时间，防止时区不对，时间对不上

    # 字符串转datetime
    task_time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
    if not task_uuid or not action or not time:
        return {'code': sc.MissingRequiredParameter}
    task = StandardTaskHandler.get_one_by_uuid(task_uuid)
    if not task:
        error_log.error('standard task {} not exist'.format(task_uuid))
        return {'code': sc.NotFound, 'msg': 'standard task not exist'}
    if not str(action).isdigit() or int(action) not in {TaskAction.start, TaskAction.stop}:
        return {'code': sc.TaskActionError}

    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        # 新任务启动后，将之前流量记录状态设为失效
        TaskAttackFlowRecordsHandler.batch_update_records_status(1, task_uuid)
        # 开始发送
        return start_running_attack_script(task, task_time)
    elif int(action) == TaskAction.stop:
        # 停止发送
        return stop_running_attack_script(task)
    elif int(action) == TaskAction.reset:
        # 重置发送
        return reset_running_attack_script(task)


def batch_start_running_attack_script(task_uuid, node_id):
    """
    批量运行攻击脚本
    :param task_uuid: 任务id
    :param node_id: 节点id
    :return:
    """
    from manage import app
    with app.app_context():
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        info_log.info('batch prepare to run attack script')
        status_detail_list = []
        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)

        # 从此项目获取资源
        file_resource_data = FileDbManager.get_one_by_uuid(task.file_resource_uuid)
        file_resource_image_type = file_resource_data.image_type
        file_resource_run_cmd = file_resource_data.run_cmd

        if file_resource_image_type == ImageType.docker:
            # 将port的状态更改为锁定,同时更新任务的uuid
            status_detail_list.append('reset port success, start to prepare network')
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list}
            )  # 调用异步任务去启动容器运行脚本
            from tasks.traffic_task import batch_running_attack_scripts_local
            info_log.info('batch start calling task to run script')
            batch_running_attack_scripts_local(task.uuid, file_resource_run_cmd)
            # 攻击任务运行完成数量+1
            get_redis_client().inc(ATTACK_RUN_FINISHED_COUNT + node_id)
            return {'code': sc.Success}
        else:
            # kvm镜像类型的暂时不开发
            pass


def start_running_attack_script(task, task_time):
    """
    开始运行攻击脚本
    :param task: 任务对象
    :param task_time: 任务执行时间
    :return:
    """
    from manage import app
    with app.app_context():
        info_log.info('prepare to run attack script')
        status_detail_list = []
        status_detail_list.append('resetting port info')

        # 创建任务结果的数据库记录
        result_data = {
            'task_uuid': task.uuid,
            'status': TaskResultStatus.init,
            'status_detail': status_detail_list,
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        task_result_obj, errors = TaskResultSchema().load(result_data, session=db.session)
        if errors:
            error_log.error('create task result failed: {}'.format(errors[list(errors)[0]][0]))
            return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
        TaskResultHandler.save(task_result_obj)

        # 首先根据任务获取到文件资源镜像相关
        # 从此项目获取资源
        file_resource_data = FileDbManager.get_one_by_uuid(task.file_resource_uuid)
        file_resource_image_type = file_resource_data.image_type
        file_resource_run_cmd = file_resource_data.run_cmd
        if file_resource_image_type == ImageType.docker:
            # 查询端口的详细信息
            port_obj = PortHandler.get_one_by_port_mac(task.port)
            status_detail_list.append('reset port success, start to prepare network')
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list}
            )

            from tasks.traffic_task import running_attack_scripts_local
            from threading import Thread
            th = Thread(target=running_attack_scripts_local, args=(task.uuid, file_resource_run_cmd,
                                                                   port_obj.port_name, task_time))
            th.start()
            info_log.info('start calling async task to run script with container')
            return {'code': sc.Success}
        else:
            # kvm镜像类型的暂时不开发
            pass


def stop_running_attack_script(task):
    """
    停止运行攻击脚本
    :param task: 任务对象
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    status_detail_list = task_result_obj.status_detail
    status_detail_list.append('prepare to stop flow task')
    task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopping})
    bridge_name = task.uuid + ':0:12'
    stop_docker_cmd = 'echo {} | sudo -S docker stop {} && docker rm {}'.format(PASSWORD, task.uuid, task.uuid)
    task_info.info('stop docker command：{}'.format(stop_docker_cmd))
    delete_bridge_cmd = 'echo {} | sudo -S ovs-vsctl del-br {}'.format(PASSWORD, bridge_name)
    task_info.info('delete bridge command：{}'.format(delete_bridge_cmd))

    try:
        for cmd in [stop_docker_cmd, delete_bridge_cmd]:
            exec_cmd(cmd)
        info_log.info('stop standard task: {} success'.format(task.uuid))
        status_detail_list.append('send flow stopped success')
        task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped})
        cache.delete(task.name + '_bridge')
        return {'code': sc.Success}
    except Exception as e:
        task_error.error('stop to run attack script failed：{}'.format(e))
        status_detail_list.append('stop failed, force to update flow status')
        task_result_obj.update({'status_detail': status_detail_list, 'status': TaskResultStatus.stopped})
        return {'code': sc.TaskStopFailed}


def reset_running_attack_script(task):
    """
    清空任务运行的结果，重新运行攻击脚本
    :param task: 任务对象
    :return:
    """
    # 首先判断任务状态是否为停止
    task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
    if task_result_obj and task_result_obj.status != TaskResultStatus.stopped:
        return {'code': sc.TaskNotStopped, 'msg': '任务未停止，请停止任务后重试'}
    # 将任务结果中的数据全部清除
    TaskResultHandler.delete_task_results_by_task_uuid(task.uuid)
    task_info.info('标准实验室任务：{}的历史结果全部清空'.format(task.name))
    info_log.info('标准实验室任务：{}的历史结果全部清空'.format(task.name))
    return {'code': sc.Success}


def get_standard_task_result(task_uuid):
    """
    获取标准实验室任务容器运行的结果
    :param task_uuid: 标准实验室任务的uuid
    :return:
    """
    standard_task = StandardTaskHandler.get_one_by_uuid(task_uuid)
    task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
    file_resource_obj = FileDbManager.get_one_by_uuid(standard_task.file_resource_uuid)
    get_result_cmd = file_resource_obj.get_result_cmd
    try:
        result = exec_cmd(get_result_cmd)
        task_result_obj.update({'result': TaskStatus.success, 'result_detail': result.decode()})
        return {'code': sc.Success, 'data': result.decode()}
    except Exception as e:
        error_log.error('获取任务：{}运行结果失败：{}'.format(task_uuid, e))
        task_error.error('获取任务：{}运行结果失败：{}'.format(task_uuid, e))
        return {'code': sc.GetStandardTaskResultFail}


def download_all_pcap(uuid):
    """
    根据任务的uuid找到所有的流量包下载
    :param uuid: 任务的uuid
    :return:
    """
    task = CustomTaskHandler.get_one_by_uuid(uuid)
    tmp_pcap_objs = TmpPcapHandler.get_pcaps_by_task_uuid(uuid)
    if not tmp_pcap_objs:
        return {'code': sc.NotFound, 'msg': '未发现流量包'}
    pcap_list = [tmp_pcap.pcap_path for tmp_pcap in tmp_pcap_objs]
    zip_file_path = os.path.join(BASE_DIR, 'media/tmp/{}.zip'.format(task.name))
    # 将所有的pcap包压缩到一个压缩包中
    compress_files_to_one_file(pcap_list, zip_file_path)
    return zip_file_path


def task_of_batch_list(task_uuids):
    batch_task_list = StandardTaskHandler.batch_task_by_uuids(task_uuids)
    result_info_of_task = TaskResultHandler.latest_result_info_of_batch_task(task_uuids)
    data = []

    if result_info_of_task and not batch_task_list:
        # 批量执行结果
        for task_uuid in task_uuids:
            info = {}
            # 封装流量运行结果
            flow_records_list = get_flow_records_list(task_uuid)

            result_record_info = result_info_of_task.get(task_uuid)
            status = TaskResultStatus.not_started  # 给中台使用 表示任务未开始
            result = TaskStatus.success
            result_detail = ""
            if result_record_info:
                status = result_record_info["status"]
                result = result_record_info["result"]
                result_detail = result_record_info["result_detail"]
            info["status"] = status
            info["result"] = result
            info["result_detail"] = result_detail
            info["flow_records"] = flow_records_list
            data.append(info)

    else:
        # 单个运行结果
        for task in batch_task_list:
            info, _ = StandardTaskSchema(exclude=['config', 'target_ip', 'source_ip']).dump(task)
            task_uuid = info["uuid"]
            # 封装流量运行结果
            flow_records_list = get_flow_records_list(task_uuid)

            result_record_info = result_info_of_task.get(task_uuid)
            status = TaskResultStatus.not_started  # 给中台使用 表示任务未开始
            result = TaskStatus.success
            result_detail = ""
            if result_record_info:
                status = result_record_info["status"]
                result = result_record_info["result"]
                result_detail = result_record_info["result_detail"]
            info["status"] = status
            info["result"] = result
            info["result_detail"] = result_detail
            info["flow_records"] = flow_records_list
            data.append(info)
    return data


def get_flow_records_list(task_uuid):
    # 根据任务id查询最新流量记录
    flow_records = TaskFlowRecordsHandler.get_last_records_by_task_uuid(task_uuid)
    attack_flow_records = TaskAttackFlowRecordsHandler.get_last_records_by_task_uuid(task_uuid)

    flow_records_list = []
    if flow_records and not attack_flow_records:
        # 只有背景流量
        for flow_record in flow_records:
            flow_records_list.append(flow_record.to_dict())
    elif not flow_records and attack_flow_records:
        # 只有攻击流量
        for attack_flow_record in attack_flow_records:
            flow_records_list.append(attack_flow_record.to_dict())
    elif flow_records and attack_flow_records:
        # 同时有攻击、背景流量
        if len(attack_flow_records) > len(flow_records):
            max_records = attack_flow_records
            less_records = flow_records
        else:
            max_records = flow_records
            less_records = attack_flow_records

        max_left_create_time = time.strptime(max_records[0].to_dict().get("create_time"), "%Y-%m-%d %H:%M:%S")
        max_left_time = time.mktime(max_left_create_time)
        max_right_create_time = time.strptime(max_records[len(max_records) - 1].to_dict().get("create_time"),
                                              "%Y-%m-%d %H:%M:%S")
        max_right_time = time.mktime(max_right_create_time)

        less_left_create_time = time.strptime(less_records[0].to_dict().get("create_time"), "%Y-%m-%d %H:%M:%S")
        less_left_time = time.mktime(less_left_create_time)
        less_right_create_time = time.strptime(less_records[len(less_records) - 1].to_dict().get("create_time"),
                                               "%Y-%m-%d %H:%M:%S")
        less_right_time = time.mktime(less_right_create_time)

        # 获取时间范围
        if max_left_time < less_left_time:
            left_time = max_left_time
        else:
            left_time = less_left_time
        if max_right_time < less_right_time:
            right_time = less_right_time
        else:
            right_time = max_right_time

        # 运行结束的流量，记录最后一条
        pre_record = None
        last_max_record = max_records[len(max_records) - 1].to_dict()
        last_max_create_time = time.mktime(time.strptime(last_max_record.get("create_time"), "%Y-%m-%d %H:%M:%S"))
        last_less_record = less_records[len(less_records) - 1].to_dict()
        last_less_create_time = time.mktime(time.strptime(last_less_record.get("create_time"), "%Y-%m-%d %H:%M:%S"))
        for time_second in range(int(left_time), int(right_time)):
            current_record = None
            second = time_second - int(left_time)
            # 是否上条记录
            is_pre_record = False

            if not pre_record and time_second > int(last_max_create_time):
                pre_record = last_max_record
            if not pre_record and time_second > int(last_less_create_time):
                pre_record = last_less_record

            for max_record in max_records:
                max_record_info = max_record.to_dict()
                max_record_create_time = time.mktime(
                    time.strptime(max_record_info.get("create_time"), "%Y-%m-%d %H:%M:%S"))
                if time_second == int(max_record_create_time):
                    current_record = max_record_info

            for less_record in less_records:
                less_record_info = less_record.to_dict()
                less_record_create_time = time.mktime(
                    time.strptime(less_record_info.get("create_time"), "%Y-%m-%d %H:%M:%S"))
                if time_second == int(less_record_create_time):
                    if not current_record:
                        current_record = less_record_info
                    else:
                        current_record["opackets"] = current_record.get("opackets") + less_record_info.get("opackets")
                        current_record["obytes"] = current_record.get("obytes") + less_record_info.get("obytes")
                        current_record["tx_bps"] = round(current_record["obytes"] / second, 2)
                        current_record["oerrors"] = current_record.get("oerrors") + less_record_info.get("oerrors")

            if not current_record:
                # 没有匹配的数据，取上一条记录
                current_record = flow_records_list[len(flow_records_list) - 1]
                is_pre_record = True
            if not is_pre_record and pre_record:
                # 上一条记录，不用再加pre_record
                current_record["opackets"] = current_record.get("opackets") + pre_record.get("opackets")
                current_record["obytes"] = current_record.get("obytes") + pre_record.get("obytes")
                current_record["tx_bps"] = round(current_record["obytes"] / second, 2)
                current_record["oerrors"] = current_record.get("oerrors") + pre_record.get("oerrors")

            # 更正秒数
            current_record["second"] = second
            flow_records_list.append(current_record)
    return flow_records_list


def v2_task_operation(params):
    """
    任务操作
    :param params: 任务操作的一些参数，包含:任务参数，任务的动作，1：开始， 2：停止， 3：暂停， 4 恢复
    :return:
    """
    # 校验参数
    if not params:
        return {'code': sc.ParameterError}
    action = params.get('action')
    task = params.get('task')
    run_type = params.get('run_type')
    # 传入任务调用时间，防止时区不对，时间对不上
    current_time = params.get('time')
    task_id = params.get('task_id')

    task_info.info(f"===========v2 task operation params: {params}")

    if not action:
        return {'code': sc.MissingRequiredParameter}
    if not str(action).isdigit() or int(action) not in TaskAction.TASK_ACTION_DICT:
        return {'code': sc.TaskActionError}
    if action == TaskAction.start:
        task_id = task.get('task_id')
        if not task or not current_time or not task_id:
            return {'code': sc.MissingRequiredParameter}
    if action == TaskAction.stop and not task_id:
        return {'code': sc.MissingRequiredParameter}

    task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
    if not task_port_obj:
        task_info.error('v2 stateless task {} not exist'.format(task_id))
        return {'code': sc.NotFound, 'msg': 'flow task not exist'}

    if (action == TaskAction.start) and (
            task_port_obj.status == TaskPortStatus.running or task_port_obj.status == TaskPortStatus.preparing):
        task_info.error("task is running, please try again later")
        return {'code': sc.TaskNotStopped, 'msg': 'task is running, please try again later'}

    if current_time:
        task_time = datetime.strptime(current_time, "%Y-%m-%d %H:%M:%S")
    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        server_time_from = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # 当前任务状态设为准备中
        TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.preparing, task_id)
        # 新任务启动后，将之前流量记录状态设为失效
        update_records_status_by_task_id(task_id)

        # 异步发送流量
        from tasks.traffic_task import v2_send_stl_flow
        send_flow_th = Thread(target=v2_send_stl_flow, args=(task, task_time, server_time_from))
        send_flow_th.start()
        ThreadingRecord.threads[config.RUNNING_FLOW_THREAD + task_id] = send_flow_th

    elif int(action) == TaskAction.stop:
        # 停止任务
        return stop_task(task_id)
    return resp_message()


def v2_task_batch_operation(params):
    """
    任务批量操作
    :param params: 任务操作的一些参数，包含:任务参数，任务的动作，1：开始， 2：停止， 3：暂停， 4 恢复
    :return:
    """
    # 校验参数
    if not params:
        return {'code': sc.ParameterError}
    action = params.get('action')
    tasks = params.get('tasks')
    task_ids = params.get('task_ids')
    # 执行方式： 0 串行，1 并行
    run_type = params.get('run_type')
    # 传入任务调用时间，防止时区不对，时间对不上
    current_time = params.get('time')

    task_info.info(f"v2 task batch operation params: {params}")

    if not action:
        return {'code': sc.MissingRequiredParameter}
    if not str(action).isdigit() or int(action) not in TaskAction.TASK_ACTION_DICT:
        return {'code': sc.TaskActionError}
    if action == TaskAction.start:
        task_ids = [task.get('task_id') for task in tasks]
        if not current_time or not tasks:
            return {'code': sc.MissingRequiredParameter}

    task_port_objs = TaskPortManagerHandler.get_by_task_ids(task_ids)
    if not task_port_objs or len(task_port_objs) == 0:
        task_info.error('v2 stateless tasks {} not exist'.format(task_ids))
        return {'code': sc.NotFound, 'msg': 'flow tasks not exist'}

    if action == TaskAction.start:
        running_tasks = [task_port_obj for task_port_obj in task_port_objs if
                         task_port_obj.status in [TaskPortStatus.running, TaskPortStatus.preparing]]
        if running_tasks and len(running_tasks) > 0:
            task_info.error("tasks is running, please try again later")
            return {'code': sc.TaskNotStopped, 'msg': 'tasks is running, please try again later'}

    max_workers = len(task_ids)
    if run_type and run_type == 0:
        max_workers = 1
    # 根据不同的action进行不同的操作
    if int(action) == TaskAction.start:
        thread_pool = ThreadPoolExecutor(max_workers=15)
        server_time_from = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        task_time = datetime.strptime(current_time, "%Y-%m-%d %H:%M:%S")

        # 当前任务状态设为准备中
        TaskPortManagerHandler.batch_update_status(TaskPortStatus.preparing, task_ids)
        from tasks.traffic_task import v2_send_stl_flow
        for task in tasks:
            task_id = task.get("task_id")
            task_info.info(f"======batch start run task: {task_id}")
            # 新任务启动后，将之前流量记录状态设为失效
            update_records_status_by_task_id(task_id)
            # 异步发送流量
            thread_pool.submit(v2_send_stl_flow, task, task_time, server_time_from)

    elif int(action) == TaskAction.stop:
        # thread_pool = ThreadPoolExecutor(max_workers=max_workers)
        get_redis_client().release_lock(config.TREX_SERVER_IS_STARTING)
        TaskPortManagerHandler.batch_update_status(TaskPortStatus.stopped, task_ids)
        # 批量停止任务
        for task_id in task_ids:
            # thread_pool.submit(stop_task, task_id)
            stop_task(task_id)
        # exec_cmd("python3 /opt/project_dirs/traffic_generators/utils/trex_reload.py")

    return resp_message()


def stop_task(task_id):
    """
    停止任务
    :param task_id:
    :return:
    """
    from manage import app
    with app.app_context():
        try:
            task_info.info(f"task stop for {task_id}")
            TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.stopped, task_id)
            th = ThreadingRecord.threads.get(config.RUNNING_STATUS_THREAD + task_id)
            stop_thread(th)
            ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)
            task_info.info(f"{task_id}: is stopped")
            stop_stl_server_v2(task_id)

            kill_processes("trex_" + task_id)
            send_flow_th = ThreadingRecord.threads.get(config.RUNNING_FLOW_THREAD + task_id)
            stop_thread(send_flow_th)
            ThreadingRecord.threads.pop(config.RUNNING_FLOW_THREAD + task_id, None)
        except Exception as e:
            task_info.error(f"{task_id}: stop error for {e}")

        return resp_message()


def stop_stl_server_v2(task_id):
    """
    停止trex服务端
    :return:
    """
    try:
        daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
        if daemon_port:
            task_info.info(f"v2 stop stl server trex_daemon_port：{daemon_port}")
            trex_handler = TrexHandler(trex_host=TREX_HOST,
                                       trex_daemon_port=daemon_port,
                                       trex_args="")
            trex_handler.stop()
            TrexDaemonHandler.stop_task_daemon_server(task_id)
        task_info.info(f"{task_id}: trex server stopped")
    except Exception as e:
        cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
        task_info.error(f"{task_id} stop trex server failed: {e}")


def update_records_status_by_task_id(task_id):
    TaskFlowRecordsHandler.batch_update_records_status(1, task_id)
    TaskAttackFlowRecordsHandler.batch_update_records_status(1, task_id)


def get_protocols_top5():
    protocols_dict = {}
    running_tasks = TaskPortManagerHandler.get_running_tasks()
    task_ids = list(set(task.task_id for task in running_tasks))
    # task_info.info(f"get protocols top5 task_ids: {task_ids}")
    total = 1
    if task_ids and len(task_ids) > 0:
        for task_id in task_ids:
            protocl_range = get_redis_client().zrevrange("PROTOCOLS::" + task_id, 0, 10)
            # task_info.info(f"{task_id}: protocl_range: {protocl_range}")
            for protocol in protocl_range:
                key = str((protocol[0]), 'utf-8')
                total = total + round(protocol[1])
                if key in protocols_dict:
                    protocols_dict[key] = protocols_dict[key] + round(protocol[1])
                else:
                    protocols_dict[key] = round(protocol[1])

    for key in protocols_dict:
        protocols_dict[key] = round(protocols_dict[key] * 100 // total)

    # 降序排列
    sorted_items = sorted(protocols_dict.items(), key=lambda x: x[1], reverse=True)
    # 取前5个值
    top5_items = [{'protocol': key, 'rate': value} for key, value in sorted_items[:5]]

    # 计算总和
    if top5_items and len(top5_items) > 0:
        total_sum = sum(item['rate'] for item in top5_items)
        if total_sum != 100:
            # 计算缺少的值
            missing_value = 100 - total_sum
            # 将缺少的值添加到第一个中
            top5_items[0]['rate'] += missing_value
        # task_info.info(f"get protocols top5 items: {top5_items}")

    return top5_items
