from logging import getLogger
from random import randint

from jsonschema import validate
from jsonschema.exceptions import ValidationError
from trex_stl_lib.api import *

from app.configure.controller.configure_manager import NetworkStructureManager
from app.configure.ops.db_handler import NetworkHandler
from app.software.controller.software_manager import get_port_info_dict
from app.software.ops.db_handler import PortHandler
from app.task.controller.task_manager import generate_start_file, delete_start_file
from app.task.ops.db_handler import StandardTaskHandler, TaskResultHandler
from app.task.schema.validate import DDosTaskSchema
from common import error_log, info_log
from common.constant import TaskResultStatus, TaskAction, NetworkStructureType, DDosType, TaskStatus, StandardTaskType, \
    PortStatus, ThreadingRecord, DutRole, ValueSolution
from common.trex_handler import TrexDaemonHandler, TrexHandler
from config import BASE_DIR, TREX_HOST, PCAP_PATH
from extension import cache
from utils import status_code as sc
from utils.exception_tools import ValidateException, APIException
from utils.util import stop_thread

task_error = getLogger('task_error')
task_info = getLogger('task_info')


class DDosStlAttackTemplate():
    TCPv4SinglePacketAttack = {
        'flags': 0,
        'action_count': 0,  # 如果有下一个stream，则在停止之前循环数。 默认值：0
        'enabled': True,  # 是否启动stream
        'self_start': True,  # 如果为false，由另一个stream激活它
        'start_paused': False,
        'isg': 0.0,  # stream间隔，stream发送第一个数据包的等待时间
        'core_id': -1,
        'mode': {  # stream mode
            'rate': {
                'type': 'pps',
                'value': 1.0
            },
            'type': 'continuous'
        },
        'packet': {  # STLPktBuilder 模块需要的内容
            'binary': None,
            'meta': ''
        },
        'vm': {
            'instructions': [{
                'type': 'flow_var',
                'name': 'ip_src',
                'size': 4,
                'op': 'random',
                'next_var': None,
                'split_to_cores': True,
                'init_value': None,
                'min_value': None,
                'max_value': None,
                'step': 1
            }, {
                'type': 'flow_var',
                'name': 'src_port',
                'size': 2,
                'op': 'random',
                'next_var': None,
                'split_to_cores': True,
                'init_value': None,
                'min_value': None,
                'max_value': None,
                'step': 1
            }, {
                'type': 'write_flow_var',
                'name': 'ip_src',
                'pkt_offset': 26,
                'add_value': 0,
                'is_big_endian': True
            }, {
                'type': 'fix_checksum_ipv4',
                'pkt_offset': 14
            }, {
                'type': 'write_flow_var',
                'name': 'src_port',
                'pkt_offset': 34,
                'add_value': 0,
                'is_big_endian': True
            }]
        },
        'flow_stats': {
            'enabled': False
        }
    }


class DDosAttackFunc():
    def __init__(self):
        self.attack_func = {
            DDosType.TCPv4SinglePacketAttack: self.tcpv4_single_packet_attack,
            DDosType.ICMPv4SinglePacketAttack: self.icmpv4_single_packet_attack,
            DDosType.ARPv4SinglePacketAttack: self.arpv4_single_packet_attack,
        }


class DDosTypeSupportMode():
    type_mode_map = {
        DDosType.TCPv4SinglePacketAttack: ["SYN_FLOOD", "ACK_FLOOD", "SYN_ACK_FLOOD", "PUSH_ACK_FLOOD", "RESET_FLOOD",
                                           "FIN_FLOOD", "TCP_NO_FLAG_FLOOD", "TCP_SYN_FIN_FLAG_FLOOD", "LAND_ATTACK",
                                           "TCP_FRAG_ACK_FLOOD"],
        DDosType.ICMPv4SinglePacketAttack: ["ICMP_FLOOD", "ICMP_REPLY_FLOOD", "ICMP_DESTI_UNREACH_FLOOD", "ICMP_REDIRECT_FLOOD",
                                            "ICMP_TTL_ZERO_FLOOD", "ICMP_TTL_ONE_FLOOD", "ICMP_TIME_STAMP_OPTION_FLOOD",
                                            "ICMP_ADDR_MASK_REQUEST_FLOOD", "ICMP_RECORD_ROUTE_OPTION_FLOOD"],
        DDosType.ARPv4SinglePacketAttack: ["ARP_REQUEST_FLOOD", "ARP_RESPONSE_FLOOD"]

    }


class DDosStlAttackDeal(DDosAttackFunc):

    def tcpv4_single_packet_attack(self, data):
        template = getattr(DDosStlAttackTemplate, DDosType.TCPv4SinglePacketAttack)
        stream_data = copy.deepcopy(template)
        instructions = stream_data["vm"]["instructions"]

        # 添加src ip 数据
        src_ip_range = data.get("src_ip_range")
        min_str_ip, max_str_ip = src_ip_range.split("-")
        min_int_ip = ip2int(min_str_ip)
        max_int_ip = ip2int(max_str_ip)
        ip_var = instructions[0]
        ip_op = data.get("ip_op")
        ip_var["op"] = ValueSolution.CHOICES_DICT.get(ip_op)
        ip_var["init_value"] = min_int_ip
        ip_var["min_value"] = min_int_ip
        ip_var["max_value"] = max_int_ip
        
        # 添加src port 数据
        src_port_range = data.get("src_port_range")
        min_port, max_port = src_port_range.split("-")
        port_var = instructions[1]
        port_op = data.get("port_op")
        port_var["op"] = ValueSolution.CHOICES_DICT.get(port_op)
        port_var["init_value"] = int(min_port)
        port_var["min_value"] = int(min_port)
        port_var["max_value"] = int(max_port)

        DDos_mode = data.get("DDos_mode")
        dst_ip = data.get("dst_ip")
        dst_port = int(data.get("dst_port"))
        stream_list = []
        for key, val in DDos_mode.items():
            item_stream_data = copy.deepcopy(stream_data)
            # 添加 packet 数据
            if key == "SYN_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="S")
            elif key == "ACK_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="A")
            elif key == "SYN_ACK_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="SA")
            elif key == "FIN_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="F")
            elif key == "PUSH_ACK_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="P")
            elif key == "RESET_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="R")
            elif key == "TCP_NO_FLAG_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="")
            elif key == "TCP_SYN_FIN_FLAG_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / TCP(dport=dst_port, flags="SF")
            elif key == "LAND_ATTACK":
                item_instructions = item_stream_data["vm"]["instructions"]
                for index, ins in enumerate(item_instructions):
                    if ins["name"] == "ip_src" and ins["type"] == "write_flow_var":
                        item_instructions.pop(index)
                base_pkt = Ether() / IP(src=dst_ip, dst=dst_ip) / TCP(dport=dst_port, flags="S")
            elif key == "TCP_FRAG_ACK_FLOOD":
                payload = "1" * 1060
                base_pkt = Ether() / IP(dst=dst_ip, flags=1) / TCP(dport=dst_port, flags="A") / Raw(load=payload)

            pkt_builder = STLPktBuilder(pkt=base_pkt)
            packet = pkt_builder.dump_pkt()
            item_stream_data["packet"] = packet
            item_stream_data["mode"]["rate"]["value"] = int(val.get("pps"))
            stream_obj = STLStream.from_json(item_stream_data)
            stream_list.append(stream_obj)
        return stream_list

    def icmpv4_single_packet_attack(self, data):
        # 添加src ip 数据
        src_ip_range = data.get("src_ip_range")
        min_str_ip, max_str_ip = src_ip_range.split("-")
        min_int_ip = ip2int(min_str_ip)
        max_int_ip = ip2int(max_str_ip)
        ip_op = data.get("ip_op")
        ip_op = ValueSolution.CHOICES_DICT.get(ip_op)
        DDos_mode = data.get("DDos_mode")
        dst_ip = data.get("dst_ip")
        dst_port = int(data.get("dst_port"))
        vm = [
            STLVmFlowVar(name="src",
                         min_value=min_int_ip,
                         max_value=max_int_ip,
                         size=4, op=ip_op),
            STLVmWrFlowVar(fv_name="src", pkt_offset="IP.src"),
            STLVmFixIpv4(offset="IP")
        ]
        stream_list = []
        for key, val in DDos_mode.items():
            # item_stream_data = copy.deepcopy(stream_data)
            # 添加 packet 数据
            if key == "ICMP_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / ICMP(type=8, code=0, id=10924, seq=1)
            elif key == "ICMP_REPLY_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / ICMP(type=0, code=0, id=10925, seq=1)
            elif key == "ICMP_DESTI_UNREACH_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / ICMP(type=3, code=3)\
                           / IP(src=dst_ip, dst="192.168.33.34") / UDP(sport=dst_port, dport=33333)
            elif key == "ICMP_REDIRECT_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip) / ICMP(type=5, code=1, gw="10.0.0.200")\
                           / IP(src=dst_ip, dst="192.168.33.34") / UDP(sport=dst_port, dport=33333)
            elif key == "ICMP_TTL_ZERO_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip, ttl=0) / ICMP(type=8, code=0, id=10924, seq=1)
            elif key == "ICMP_TTL_ONE_FLOOD":
                base_pkt = Ether() / IP(dst=dst_ip, ttl=1) / ICMP(type=8, code=0, id=10924, seq=1)
            elif key == "ICMP_TIME_STAMP_OPTION_FLOOD":
                ts_ori = int(time.time())
                base_pkt = Ether() / IP(dst=dst_ip, ttl=1) / ICMP(type=13, code=0, id=10924, seq=1, ts_ori=ts_ori)
            elif key == "ICMP_ADDR_MASK_REQUEST_FLOOD":
                # ICMP掩码请求报文攻击 有的服务不会对此做出应答
                base_pkt = Ether() / IP(dst=dst_ip) / ICMP(type=17)
            elif key == "ICMP_RECORD_ROUTE_OPTION_FLOOD":
                # 带路由记录选项的ICMP报文攻击
                options = [
                    IPOption_NOP(copy_flag=0, optclass="control", option="nop"),
                    IPOption_RR(copy_flag=0, optclass="control", option="record_route", length=39, pointer=8,
                                routers=["192.168.33.39", "0.0.0.0", "0.0.0.0", "0.0.0.0", "0.0.0.0",
                                         "0.0.0.0", "0.0.0.0", "0.0.0.0", "0.0.0.0"])
                ]
                base_pkt = Ether() / IP(dst=dst_ip, options=options) / ICMP(type=8)
            pkt_builder = STLPktBuilder(pkt=base_pkt, vm=vm)
            pps = int(val.get("pps"))
            stream_obj = STLStream(packet=pkt_builder, mode=STLTXCont(pps=pps))
            stream_list.append(stream_obj)
        return stream_list

    def arpv4_single_packet_attack(self, data):
        # 添加src ip 数据
        src_ip_range = data.get("src_ip_range")
        min_str_ip, max_str_ip = src_ip_range.split("-")
        min_int_ip = ip2int(min_str_ip)
        max_int_ip = ip2int(max_str_ip)
        ip_op = data.get("ip_op")
        ip_op = ValueSolution.CHOICES_DICT.get(ip_op)
        DDos_mode = data.get("DDos_mode")
        dst_ip = data.get("dst_ip")
        dst_port = int(data.get("dst_port"))
        vm = [
            STLVmFlowVar(name="src_ip",
                         min_value=min_int_ip,
                         max_value=max_int_ip,
                         size=4, op=ip_op),
            STLVmWrFlowVar(fv_name="src_ip", pkt_offset=28),
            STLVmFlowVar(name="src_mac",
                         min_value=1,
                         max_value=255,
                         size=2,
                         op="inc",
                         step=1),
            STLVmWrMaskFlowVar(fv_name="src_mac", pkt_offset=11, pkt_cast_size=1, mask=0xff),
            STLVmWrMaskFlowVar(fv_name="src_mac", pkt_offset=27, pkt_cast_size=1, mask=0xff)
        ]
        stream_list = []
        for key, val in DDos_mode.items():
            # 添加 packet 数据
            base_mac = ":".join(["%02x" % x for x in map(lambda x: randint(0, 255), range(5))]) + ":00"
            if key == "ARP_REQUEST_FLOOD":
                # 攻击者向目标主机发送大量的，不同的源ip，源MAC的请求报文，使网络资源被大量占用，造成网络中断，掉线等问题。
                base_pkt = Ether(src=base_mac) / ARP(hwlen=6, plen=4, op=1, pdst=dst_ip, hwsrc=base_mac)
            if key == "ARP_RESPONSE_FLOOD":
                # 攻击者向目标主机发送大量的，不同的源ip，源MAC的应答报文，不断更新本地ARP缓存，使网络资源被大量占用，造成网络中断，掉线等问题。
                # manager_port_obj = PortHandler.get_manager_port()
                # manager_port_name = manager_port_obj.port_name
                # request_dst_packet = Ether() / ARP(hwlen=6, plen=4, op=2, pdst=dst_ip)
                # print('manager_port_name', manager_port_name)
                # ans, unans = srp(request_dst_packet, timeout=5, verbose=False, iface=manager_port_name)
                # print('ans, unans', ans, unans)
                # dst_mac = ans[0][1].getlayer(ARP).fields['hwsrc']
                # base_pkt = Ether(src=base_mac, dst=dst_mac) / ARP(hwlen=6, plen=4, op=2, pdst=dst_ip, hwsrc=base_mac, hwdst=dst_mac)
                base_pkt = Ether(src=base_mac) / ARP(hwlen=6, plen=4, op=2, pdst=dst_ip, hwsrc=base_mac)


            pkt_builder = STLPktBuilder(pkt=base_pkt, vm=vm)
            pps = int(val.get("pps"))
            stream_obj = STLStream(packet=pkt_builder, mode=STLTXCont(pps=pps))
            stream_list.append(stream_obj)
        return stream_list


class DDosStfAttackDeal(DDosAttackFunc):
    def __init__(self):
        super(DDosStfAttackDeal, self).__init__()
        self.CapMapping = {
            # "SYN_FLOOD": "syn_flood",
            "ACK_FLOOD": "ack_flood",
            "SYN_FLOOD": "delay_http_browsing_0.pcap",
        }

    def tcpv4_single_packet_attack(self, task_name, data):
        # 生成yaml文件
        duration = data.get("duration")
        src_ip_range = data.get("src_ip_range")
        clients_start, clients_end = src_ip_range.split("-")
        dst_ip = data.get("dst_ip")
        DDos_mode = data.get("DDos_mode")

        traffic_data = {
            "duration": duration,
            "generator": {
                "distribution": "seq",  # stf 只支持顺序ip
                "clients_start": clients_start,
                "clients_end": clients_end
            },
            "cap_info": []
        }

        cap_info = []
        for key, val in DDos_mode.items():
            pcap_name = self.CapMapping.get(key)
            pcap_file = os.path.join(PCAP_PATH, pcap_name)
            # TODO: 更改目标端口，生成新的pcap文件
            cap_item = {
                "name": pcap_file,
                "server_addr": dst_ip,
                "one_app_server": True,
                "cps": val.get("cps"),
                "ipg": val.get("ipg"),
                "rtt": val.get("ipg"),
                "w": 1
            }
            cap_info.append(cap_item)
        traffic_data["cap_info"] = cap_info
        # 将组合的数据序列化到yaml文件中
        new_trex_config_file_dir = os.path.join(BASE_DIR, 'media/stf')
        if not os.path.exists(new_trex_config_file_dir):
            os.makedirs(new_trex_config_file_dir)
        new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(task_name))
        with open(new_trex_config_file_path, 'w+') as f:
            yaml.dump([traffic_data], f, default_flow_style=False)


class DDosTaskManager(object):

    def verify_task_name(self, name, exclude_uuid=None):
        result = StandardTaskHandler.verify_unique_name(name, exclude_uuid)
        return result

    def create_task(self, data):
        obj = StandardTaskHandler.create_obj(data, "standardTask")
        return obj

    def task_list(self, page, per_page):
        paginate_data = StandardTaskHandler.paginate(page, per_page)
        data = [i.to_dict(exclued=["profile"]) for i in paginate_data["items"]]
        total = paginate_data.get("total")
        return data, total

    def get_task(self, uuid):
        port_info_dict = get_port_info_dict()

        def replace_port_num(network_info_list):
            for net_info in network_info_list:
                port_num = str(net_info["port"])
                port_info = port_info_dict.get(port_num)
                net_info["port"] = port_info

        detail = StandardTaskHandler.get_obj_by_uuid(uuid).to_dict()
        network_structure = detail.get("config").get("network_structure")
        network_config = network_structure.get("network_config")
        client = network_config.get("client")
        server = network_config.get("server")
        if client:
            replace_port_num(client)
        if server:
            replace_port_num(server)
        return detail

    def update_task(self, uuid, data):
        obj = StandardTaskHandler.get_obj_by_uuid(uuid)
        obj.update(data)

    def batch_delete_task(self, uuids):
        StandardTaskHandler.batch_delete_by_uuids(uuids)
        TaskResultHandler.delete_task_results_by_task_uuid(uuids)

    def check_DDos_config(self, data, old_data=None):
        '''

        :param data: 要检查的数据
        :param old_data: 之前保存在数据库里的数据
        :return:
        '''
        try:
            validate(data, DDosTaskSchema)
        except ValidationError as e:
            raise ValidateException(message=e.message)
        config_info = data.get("config")
        network_structure = config_info.get("network_structure")
        # network_structure信息校验
        old_network_structure = None
        if old_data:
            old_network_structure = old_data.get("config").get("network_structure")
        if network_structure.get("dut_role") == DutRole.gateway:
            raise ValidateException(message=f"DDos攻击不支持全状态流量")
        NetworkStructureManager().check_network_structure(network_structure, old_network_structure)
        specifics = config_info.get("specifics")
        DDos_type = specifics.get("DDos_type")
        DDos_mode = specifics.get("DDos_mode")
        DDOs_type_mode_map = DDosTypeSupportMode().type_mode_map
        support_mode = DDOs_type_mode_map.get(DDos_type)
        for item in DDos_mode:
            if item not in support_mode:
                raise ValidateException(message=f"不支持{DDos_mode}攻击")
        data["type"] = StandardTaskType.ddos
        return data

    def stopped_task(self, uuid):
        is_stopped = True
        task_results = TaskResultHandler.get_task_result_by_task_uuid(uuid)
        if task_results:
            newed_result_obj = task_results[0]
            status = newed_result_obj.status
            if status != TaskResultStatus.stopped:
                is_stopped = False
        return is_stopped

    def start_task(self, uuid):
        # 根据状态判断 是否可以启动任务
        task_result_record = TaskResultHandler.get_one_task_result(uuid)
        if task_result_record and task_result_record.status != TaskResultStatus.stopped:
            raise APIException(sc.TaskNotStopped, '任务未停止，请停止任务后重试')

        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        # 判断端口是否被占用
        client = network.network_config.get('client', [])
        server = network.network_config.get('server', [])
        all_port_info = client + server
        for net_cfg in all_port_info:
            port_obj = PortHandler.get_one_by_port(net_cfg['port'])
            if port_obj.status == PortStatus.acquire:
                # task_result_obj.update({'status_detail': status_detail.append('有端口正在被占用')})
                raise APIException(sc.PortAcquired)

        # 创建任务结果的数据库记录
        task_info.info(f"启动DDos任务：{task_name}")
        info_log.info(f"启动DDos任务：{task_name}")
        status_detail = ['正在启动trex服务']
        task_result_data = {
            'task_uuid': uuid,
            'status': TaskResultStatus.init,
            'status_detail': status_detail,
            'start_time': datetime.now()
        }
        task_result_obj = TaskResultHandler.create_obj(task_result_data, "taskResult")
        task_info.info(f"启动DDos任务：{task_name}，成功创建任务记录")
        info_log.info(f"启动DDos任务：{task_name}，成功创建任务记录")

        try:
            # 生成trex启动的配置文件
            generate_start_file(network, task_name)
            task_info.info(f"启动DDos任务：{task_name}，成功生成trex配置文件")
            info_log.info(f"启动DDos任务：{task_name}，成功生成trex配置文件")
        except Exception as e:
            error_log.info(f"启动DDos任务：{task_name}，生成trex启动配置文件出错")
            task_error.info(f"启动DDos任务：{task_name}，生成trex启动配置文件出错：{e}")
            status_detail.append('生成trex启动配置文件出错')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail, 'result': TaskStatus.fail,
                 'result_detail': '生成trex启动配置文件出错',
                 'end_time': datetime.now()}
            )
            raise APIException(sc.GenerationTrexCfgFail)

        # 启动一个trex的守护进程，其中的端口存到redis中
        daemon_server_status = TrexDaemonHandler.start_daemon_server(task_name, network.type)
        if not daemon_server_status:
            status_detail.append('启动trex启守护进程出错')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail, 'result': TaskStatus.fail,
                 'result_detail': '启动trex启守护进程出错',
                 'end_time': datetime.now()}
            )
            raise APIException(sc.ExecuteCommandFail)

        # 根据任务生成的trex启动配置文件启动trex
        trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
        # 获取trex启动的时候，是以ipv4启动的，还是ipv6启动的
        trex_args = '' if network.ip_versions == 'ipv4' else 'ipv6'
        if network.type == NetworkStructureType.stl:
            trex_handler = TrexHandler(trex_host=TREX_HOST, trex_daemon_port=cache.get(task_name), trex_args=trex_args)
            try:
                task_info.info(f"启动DDos任务：{task_name}，准备启动服务")
                info_log.info(f"启动DDos任务：{task_name}，准备启动服务")
                trex_handler.start_stateless_server({'cfg': trex_config_path})
                status_detail.append('启动trex服务成功，正在检查配置文件信息及网络结构')
                task_result_obj.update(
                    {'status': TaskResultStatus.running, 'status_detail': status_detail}
                )
                task_info.info(f'启动DDos任务：{task_name},成功启动无状态trex服务成功')
                task_info.info(f'启动DDos任务：{task_name},成功启动无状态trex服务成功')

                # 根据任务表中的参数，开始发送流量
                from tasks.traffic_task import send_DDos_stateless_traffic
                th = Thread(target=send_DDos_stateless_traffic, args=(task.uuid,))
                th.start()

            except Exception as e:
                status_detail.append('启动trex服务失败')
                task_result_obj.update(
                    {'status': TaskResultStatus.stopped, 'status_detail': status_detail, 'result': TaskStatus.fail,
                     'result_detail': '启动trex服务失败',
                     'end_time': datetime.now()}
                )
                error_log.error(f'启动DDos任务：{task_name}，启动trex服务失败')
                task_error.error(f'启动DDos任务：{task_name}，启动trex服务失败:{e}')
                # trex服务启动失败的话，将对应的守护进程也停止掉
                TrexDaemonHandler.stop_daemon_server(task_name, network.type)
                raise APIException(sc.StartTrexServerFail)
        else:
            from tasks.traffic_task import send_DDos_stateful_traffic
            th = Thread(target=send_DDos_stateful_traffic, args=(task.uuid,))
            th.start()
        # 将此线程存储到全局变量中，便于后续停止任务时，停止对应的线程
        ThreadingRecord.threads[task.uuid] = th

    def stop_task(self, uuid):
        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
        if not task_result_obj:
            raise APIException(sc.NotFound, '未找到任务运行结果记录')
        if task_result_obj.status == TaskResultStatus.stopped:
            raise APIException(sc.TaskStopped)
        task_info.info(f"停止DDos任务：{task_name}")
        info_log.info(f"停止DDos任务：{task_name}")
        status_detail = task_result_obj.status_detail
        status_detail.append('准备停止发送流量')
        task_result_obj.update({'status_detail': status_detail, 'status': TaskResultStatus.stopping})
        # 将trex服务停止
        network_structure = task.config.get("network_structure")
        task_type = int(network_structure.get("type"))
        try:
            trex_handler = TrexHandler(trex_host=TREX_HOST,
                                       trex_daemon_port=cache.get(task_name)) if int(
                task_type) == NetworkStructureType.stl else TrexHandler(
                trex_host=TREX_HOST, master_daemon_port=cache.get(task_name))
            trex_handler.stop()
        except ConnectionRefusedError as e:
            pass
        # 将trex守护进程的服务停止
        TrexDaemonHandler.stop_daemon_server(task_name, task_type)
        # 停止发送流量的线程
        th = ThreadingRecord.threads.get(task.uuid)
        if th:
            stop_thread(th)
        status_detail.append('trex服务已经停止')
        task_result_obj.update({'status_detail': status_detail, 'status': TaskResultStatus.stopped})
        # 释放端口
        network_config = network_structure.get("network_config")
        all_port_info = network_config.get('client', []) + network_config.get('server', [])
        port_num_list = [info["port"] for info in all_port_info]
        for port_num in port_num_list:
            PortHandler.update_by_port(port_num, {'status': 'release', 'task_uuid': ''})
        # 将redis中缓存的端口信息清除
        cache.delete(task.name)
        # 删除启动trex配置文件及缓存
        delete_start_file(task.name)
        ThreadingRecord.threads.pop(task.uuid, None)
        task_info.info(f'停止DDos任务：{task_name}，停止发送流量成功')
        info_log.info(f'停止DDos任务：{task_name}，停止发送流量成功')

    def reset_task(self, uuid):
        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        # 根据状态判断 是否可以重置任务
        task_result_record = TaskResultHandler.get_one_task_result(uuid)
        if task_result_record and task_result_record.status != TaskResultStatus.stopped:
            raise APIException(sc.TaskNotStopped, '任务未停止，请停止任务后重试')
        # 将任务结果中的数据全部清除
        TaskResultHandler.delete_task_results_by_task_uuid(uuid)
        task_info.info(f'重置DDos任务：{task_name}，重置成功')
        info_log.info(f'重置DDos任务：{task_name}，重置成功')
        # 调用开始发送流量的方法重新发送流量
        # return self.start_task(uuid)

    def task_action(self, uuid, action):
        func_dict = {
            TaskAction.start: self.start_task,
            TaskAction.stop: self.stop_task,
            TaskAction.reset: self.reset_task,
        }
        func = func_dict[action]
        return func(uuid)

    def update_task_result_info(self, task_uuid, data):
        obj = TaskResultHandler.get_one_task_result(task_uuid)
        obj.update(data)


if __name__ == "__main__":
    pass
    # data = {
    #     "DDos_type": "TCPv4SinglePacketAttack",
    #     "duration": "100",
    #     "src_ip_range": "17.1.2.2-17.1.2.201",
    #     "dst_ip": "48.0.0.1",
    #     "ip_op": "random",
    #     "src_port_range": "1025-65000",
    #     "port_op": "random",
    #     "dst_port": "80",
    #     "DDos_mode": {
    #         "SYN_FLOOD": {
    #             "pps": "2",
    #         }
    #     }
    #
    # }
    # a = DDosStlAttackDeal()
    # b = a.tcpv4_single_packet_attack(data)
    # print(b)
    # from manage import app
    # stf
    # a = DDosTaskManager().start_task("88f70aa5cda3_standardTask")
    # print(a)

    # a = DDosTaskManager().start_task("32f9a2f46900_standardTask")
    # print(a)

    # a = DDosTaskManager().task_action("32f9a2f46900_standardTask", 1)
    # print(a)

    # a = DDosTaskManager().start_task("32f9a2f46900_standardTask")
    # print(a)
    data = {
        "ip_op": 1,
        "dst_ip": "48.0.0.1",
        "port_op": 1,
        "dst_port": 80,
        "duration": 10,
        "DDos_mode": {
            "ICMP_FLOOD": {
                "pps": 2
            }
        },
        "DDos_type": "ICMPv4SinglePacketAttack",
        "src_ip_range": "16.0.0.1-17.0.0.1",
        "src_port_range": "1000-2000"
    }
    DDosStlAttackDeal().icmpv4_single_packet_attack(data)
