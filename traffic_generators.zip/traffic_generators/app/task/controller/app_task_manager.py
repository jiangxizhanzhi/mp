from datetime import datetime
from logging import getLogger
from threading import Thread

from jsonschema import validate
from jsonschema.exceptions import ValidationError
from trex_stl_lib.api import *

from app.configure.ops.db_handler import NetworkHandler
from app.resources.controller.resource_manager import PcapManagement
from app.software.controller.software_manager import get_port_info_dict, port_info_dict_of_key_mac, \
    add_ports_for_middleground
from app.software.ops.db_handler import PortHandler
from app.task.controller.task_manager import delete_start_file
from app.task.ops.db_handler import StandardTaskHandler, TaskResultHandler
from app.task.schema.validate import AppTaskSchema
from common import error_log, info_log
from common.constant import TaskResultStatus, TaskAction, NetworkStructureType, TaskStatus, StandardTaskType, \
    ThreadingRecord, DutRole, IpVersions, DutMode
from common.trex_handler import TrexDaemonHandler, TrexHandler
from config import BASE_DIR, TREX_HOST, PCAP_PATH, STF_CFG_PATH
from extension import cache
from utils import status_code as sc
from utils.exception_tools import ValidateException, APIException, UpdatePortException
from utils.util import get_available_port, stop_thread

task_error = getLogger('task_error')
task_info = getLogger('task_info')


class AppTaskManager(object):
    def __init__(self):
        pass

    def generate_stf_yaml(self, task_uuid, data):
        # 生成yaml文件
        duration = data.get("duration")
        src_ip_range = data.get("src_ip_range")
        clients_start, clients_end = src_ip_range.split("-")
        dst_ip_range = data.get("dst_ip_range")
        servers_start, servers_end = dst_ip_range.split("-")
        traffic_data = {
            "duration": duration,
            "generator": {
                "distribution": "seq",  # stf 只支持顺序ip
                "clients_start": clients_start,
                "clients_end": clients_end,
                "servers_start": servers_start,
                "servers_end": servers_end,
            },
            "cap_ipg": True,  # 使用pcap包里的间隔时间
            "cap_info": []
        }

        cap_info = []
        cap_list = data["cap_list"]
        for item in cap_list:
            pcap_name = item.get("name")
            pcap_file = os.path.join(PCAP_PATH, pcap_name)
            cap_item = {
                "name": pcap_file,
                # "server_addr": dst_ip,
                # "one_app_server": True,
                "cps": item.get("cps"),
                "ipg": 100000,
                "rtt": 100000,
                "w": 1,
                # "multi_flow_enabled": True,
                # "flows_dirs": [0, 0]
            }
            cap_info.append(cap_item)
        traffic_data["cap_info"] = cap_info
        # 将组合的数据序列化到yaml文件中
        if not os.path.exists(STF_CFG_PATH):
            os.makedirs(STF_CFG_PATH)
        new_trex_config_file_path = os.path.join(STF_CFG_PATH, '{}.yaml'.format(task_uuid))
        with open(new_trex_config_file_path, 'w+') as f:
            yaml.dump([traffic_data], f, default_flow_style=False)

    def del_stf_yaml(self, task_uuid):
        stf_yaml_file_path = os.path.join(STF_CFG_PATH, '{}.yaml'.format(task_uuid))
        if os.path.exists(stf_yaml_file_path):
            os.remove(stf_yaml_file_path)

    # def add_port_to_nic_conf_file(self, add_ports_list):
    #     '''
    #     将网口配置写入netplan管理文件,并启动网卡
    #     :param add_ports_list:
    #     :return:
    #     '''
    #     conf_file_name = os.listdir("/etc/netplan/")[0]
    #     file_path = os.path.join("/etc/netplan/", conf_file_name)
    #     with open(file_path, 'r') as f:
    #         content = yaml.load(f.read(), Loader=yaml.FullLoader)
    #         network = content["network"]
    #         all_ethernet = network.get("ethernets", {})
    #         for item in add_ports_list:
    #             port_name = item["port_name"]
    #             all_ethernet[port_name] = {"dhcp4": True}
    #         network["ethernets"] = all_ethernet
    #     yaml_file = open(file_path, 'w')
    #     yaml.dump(content, yaml_file, default_flow_style=False)
    #     yaml_file.close()
    #     exec_cmd("sudo netplan apply")

    def check_network_structure(self, data, old_data=None):
        '''
        校验network_structure数据
        当dut_role为gateway，network_config里的client和server之间的对应关系由相同索引实现
        {
            "name": "caitt4",                 // 必填 str
            "dut_role": "gateway",            // 必填 str
            "ip_versions": "ipv4",            // 必填 str
            "dut_mode": "TP",                 // 非必填 str
            "network_config": {               // 必填 dict
                "client": [{                  // 必填 list
                    "ip": "192.168.3.3",      // 必填 str
                    "default_gw": "192.168.3.3", // 必填 str
                    "port": "fa:16:3e:a6:c1:23",  // 必填 str
                    "capture": true,          //  必填 bool
                    "capture_limit": 1000     // 非必填 int
                }],
                "server": [{                  // 非必填 list
                    "ip": "192.168.3.4",      // 必填 str
                    "default_gw": "192.168.3.3", // 必填 str
                    "port": "fa:16:3e:a6:c1:78"  // 必填 str
                }]
            }
        }
        '''
        # 校验dut_mode参数
        dut_role = data.get("dut_role")
        dut_mode = data.get("dut_mode", "")
        ip_versions = data.get("ip_versions")
        # 已经创建的网络结构不能更改dut_role
        if old_data:
            if old_data.get("dut_role") != dut_role:
                raise ValidateException("不能更改测试设备模式")
            if old_data.get("ip_versions") != ip_versions:
                raise ValidateException("不能更改ip版本")
            if old_data.get("dut_mode", "") != dut_mode:
                raise ValidateException("不能更改dut_mode")
        if dut_role == DutRole.gateway:
            if dut_mode not in DutMode.CHOICES_DICT:
                raise ValidateException("被测设备模式错误")
        else:
            if dut_mode:
                raise ValidateException("服务器设备不能选择测试模式")
        # 校验network_config参数
        network_config = data.get("network_config")
        if not network_config:
            raise ValidateException("网络结构配置不能为空")
        client = network_config.get("client", [])
        server = network_config.get("server", [])
        if dut_role == DutRole.gateway:
            if not (client and server):
                raise ValidateException("被测为网关设备需要客户端和服务端的网络信息")
            if len(client) != len(server):
                raise ValidateException("客户端和服务端的网络数量不一致")
            all_port_count = len(client) + len(server)
            if all_port_count * ["dummy"] == client + server:
                raise ValidateException("不能所有端口为dummy")
            network_structure_type = NetworkStructureType.astf
        else:
            if not client:
                raise ValidateException("被测为应用服务需要客户端网络信息")
            if server:
                raise ValidateException("被测为应用服务不需要服务端网络信息")
            network_structure_type = NetworkStructureType.stl
        all_network_list = client + server
        used_port_list = []
        for item in all_network_list:
            # 只有app task 使用
            if item == "dummy":
                continue
            capture = item.get("capture")
            if dut_role == DutRole.gateway and capture:
                raise ValidateException("网关模式不能捕获")
            capture_limit = item.get("capture_limit")
            if capture and not capture_limit:
                item["capture_limit"] = 1000
            default_gw = item.get("default_gw")
            if not default_gw:
                raise ValidateException("default_gw是必填项")
            port = item.get("port")
            if not port:
                raise ValidateException("port是必填项")
            if port in used_port_list:
                continue
                # raise ValidateException(f"port:{port}被重复选择")
            used_port_list.append(port)
        # 校验port是否在数据库里
        port_info_dict = port_info_dict_of_key_mac()
        add_port_macs = []
        for p in used_port_list:
            if str(p) not in port_info_dict:
                add_port_macs.append(p)
        if add_port_macs:
            try:
                add_ports_for_middleground(add_port_macs)
            except UpdatePortException as e:
                raise ValidateException(str(e))
            # 将网口配置写入netplan管理文件
            # self.add_port_to_nic_conf_file(add_ports_list)
        data["type"] = network_structure_type
        return data

    def check_config(self, data):
        try:
            validate(data, AppTaskSchema)
        except ValidationError as e:
            raise ValidateException(message=e.message)
        config_info = data.get("config")
        network_structure = config_info.get("network_structure")
        # app task 网络结构默认参数
        network_structure["dut_role"] = DutRole.gateway
        network_structure["ip_versions"] = IpVersions.ipv4
        network_structure["dut_mode"] = DutMode.TP
        # network_structure信息校验
        self.check_network_structure(network_structure)
        # check specifics
        specifics = config_info.get("specifics")
        flow_protocol = specifics.get("flow_protocol")
        if not flow_protocol:
            cap_list = specifics.get("cap_list")
            pcap_names = [info["name"] for info in cap_list]
            pcap_manager = PcapManagement()
            # 使用此项目数据库
            not_found_pcap_names = pcap_manager.not_found_pcap_names(pcap_names)
            # 使用资源服务器数据库
            # not_found_pcap_names = pcap_manager.not_found_pcap_names_form_flow_resource(pcap_names)
            if not_found_pcap_names:
                raise ValidateException(message=f'pcap file {not_found_pcap_names} not exist')
        data["type"] = StandardTaskType.app
        return data

    def verify_task_name(self, name, exclude_uuid=None):
        result = StandardTaskHandler.verify_unique_name(name, exclude_uuid)
        return result

    def create_task(self, data):
        obj = StandardTaskHandler.create_obj(data, "standardTask")
        return obj

    def task_list(self, page, per_page):
        paginate_data = StandardTaskHandler.paginate(page, per_page,
                                                     filters=[StandardTaskHandler.type == StandardTaskType.app])
        task_uuids = [i.uuid for i in paginate_data["items"]]
        result_info_of_task = TaskResultHandler.latest_result_info_of_batch_task(task_uuids)
        data = []
        for i in paginate_data["items"]:
            info = i.to_dict()
            task_uuid = info["uuid"]
            result_record_info = result_info_of_task.get(task_uuid)
            status = ""
            if result_record_info:
                status = result_record_info["status"]
            info["status"] = status
            data.append(info)
        total = paginate_data.get("total")
        return data, total

    def task_of_batch_list(self, task_uuids):
        batch_task_list = StandardTaskHandler.batch_task_by_uuids(task_uuids)
        result_info_of_task = TaskResultHandler.latest_result_info_of_batch_task(task_uuids)
        data = []
        for task in batch_task_list:
            info = task.to_dict()
            task_uuid = info["uuid"]
            result_record_info = result_info_of_task.get(task_uuid)
            status = ""
            if result_record_info:
                status = result_record_info["status"]
            info["status"] = status
            data.append(info)
        return data

    def get_task(self, uuid):
        port_info_dict = get_port_info_dict()

        def replace_port_num(network_info_list):
            for net_info in network_info_list:
                if net_info == "dummy":
                    continue
                port_num = str(net_info["port"])
                port_info = port_info_dict.get(port_num)
                net_info["port"] = port_info

        detail = StandardTaskHandler.get_obj_by_uuid(uuid).to_dict()
        network_structure = detail.get("config").get("network_structure")
        network_config = network_structure.get("network_config")
        client = network_config.get("client")
        server = network_config.get("server")
        if client:
            replace_port_num(client)
        if server:
            replace_port_num(server)
        return detail

    def update_task(self, uuid, data):
        obj = StandardTaskHandler.get_obj_by_uuid(uuid)
        obj.update(data)

    def batch_delete_task(self, uuids):
        StandardTaskHandler.batch_delete_by_uuids(uuids)
        TaskResultHandler.delete_task_results_by_task_uuid(uuids)

    def stopped_task(self, uuid):
        is_stopped = True
        task_results = TaskResultHandler.get_task_result_by_task_uuid(uuid)
        if task_results:
            newed_result_obj = task_results[0]
            status = newed_result_obj.status
            if status != TaskResultStatus.stopped:
                is_stopped = False
        return is_stopped

    def analysis_network_data(self, network, network_data):
        """
        解析网络结构中的数据
        :param network: 网络结构的对象
        :param network_data: 保存解析的网络结构的字典
        :return:
        """
        network_data['port_info'] = []
        network_data['interfaces'] = []
        network_data['low_end'] = True
        try:
            network_config = network.network_config
        except AttributeError:
            # 下面的是rfc2544使用的，因为没有在cfg_networkstructures表中存储数据
            network_config = network
        # 计算使用多少个端口
        server_port = network_config.get('server', [])
        client_port = network_config.get('client', [])
        server_port_num = len(server_port)
        client_port_num = len(client_port)
        if server_port_num == 0:
            # 无状态只使用client端口
            for _client in client_port:
                port_obj = PortHandler.get_one_by_port_mac(_client.get('port'))
                network_data['interfaces'].append(port_obj.pci)
                network_data['port_info'].append({'ip': _client.get('ip'), 'default_gw': _client.get('default_gw')})
            if client_port_num % 2 != 0:
                network_data['port_limit'] = client_port_num + 1
                network_data['interfaces'].append('dummy')
            else:
                network_data['port_limit'] = client_port_num
        else:
            # 有状态的client和server的数量必须是一致的，组合的port_info部分的顺序按照：前面是client，后面是server，一对来组合
            network_data['port_limit'] = client_port_num + server_port_num
            for i, _client in enumerate(client_port):
                _server = server_port[i]
                if _client == "dummy":  # 只有app task 使用
                    network_data['interfaces'].append('dummy')
                else:
                    network_data['port_info'].append({'ip': _client.get('ip'), 'default_gw': _client.get('default_gw')})
                    client_port_obj = PortHandler.get_one_by_port_mac(_client.get('port'))
                    network_data['interfaces'].append(client_port_obj.pci)
                if _server == "dummy":  # 只有app task 使用
                    network_data['interfaces'].append('dummy')
                else:
                    network_data['port_info'].append(
                        {'ip': server_port[i].get('ip'), 'default_gw': _server.get('default_gw')})
                    server_port_obj = PortHandler.get_one_by_port_mac(_server.get('port'))
                    network_data['interfaces'].append(server_port_obj.pci)

        return network_data

    def generate_start_file(self, network, name):
        # 解析网络结构中的数据
        network_data = {}
        network_data['version'] = 2
        network_data['prefix'] = name
        zmq_pub_port = get_available_port()
        zmq_rpc_port = get_available_port()
        network_data['zmq_pub_port'] = zmq_pub_port
        network_data['zmq_rpc_port'] = zmq_rpc_port

        # 将zmq_pub_port、zmq_rpc_port存储到redis中，方便后面发送流量时，连接客户端使用
        cache.set(name + '_zmq_port', json.dumps([zmq_rpc_port, zmq_pub_port]), timeout=-1)
        _network_data = self.analysis_network_data(network, network_data)

        # 将组合的数据序列化到yaml文件中
        new_trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs')
        if not os.path.exists(new_trex_config_file_dir):
            os.makedirs(new_trex_config_file_dir)
        new_trex_config_file_path = os.path.join(new_trex_config_file_dir, '{}.yaml'.format(name))
        with open(new_trex_config_file_path, 'w+') as f:
            yaml.dump([_network_data], f, default_flow_style=False)
        return new_trex_config_file_path

    def start_task(self, uuid):
        # 根据状态判断 是否可以启动任务
        task_result_record = TaskResultHandler.get_one_task_result(uuid)
        if task_result_record and task_result_record.status != TaskResultStatus.stopped:
            raise APIException(sc.TaskNotStopped, '任务未停止，请停止任务后重试')

        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        # 创建任务结果的数据库记录
        task_info.info(f"启动app任务：{task_name}")
        info_log.info(f"启动app任务：{task_name}")
        status_detail = ['正在启动trex服务']
        task_result_data = {
            'task_uuid': uuid,
            'status': TaskResultStatus.init,
            'status_detail': status_detail,
            'start_time': datetime.now()
        }
        task_result_obj = TaskResultHandler.create_obj(task_result_data, "taskResult")
        task_info.info(f"启动app任务：{task_name}，成功创建任务记录")
        info_log.info(f"启动app任务：{task_name}，成功创建任务记录")

        try:
            # 生成trex启动的配置文件
            self.generate_start_file(network, task_name)
            task_info.info(f"启动app任务：{task_name}，成功生成trex配置文件")
            info_log.info(f"启动app任务：{task_name}，成功生成trex配置文件")
        except Exception as e:
            error_log.info(f"启动app任务：{task_name}，生成trex启动配置文件出错")
            task_error.info(f"启动app任务：{task_name}，生成trex启动配置文件出错：{e}")
            status_detail.append('生成trex启动配置文件出错')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail, 'result': TaskStatus.fail,
                 'result_detail': '生成trex启动配置文件出错',
                 'end_time': datetime.now()}
            )
            raise APIException(sc.GenerationTrexCfgFail)

        # 启动一个trex的守护进程，其中的端口存到redis中
        daemon_server_status = TrexDaemonHandler.start_daemon_server(task_name, network.type)
        if not daemon_server_status:
            status_detail.append('启动trex启守护进程出错')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail, 'result': TaskStatus.fail,
                 'result_detail': '启动trex启守护进程出错',
                 'end_time': datetime.now()}
            )
            raise APIException(sc.ExecuteCommandFail)
        th = Thread(target=self.send_low_stateful_traffic, args=(task.uuid,))
        th.start()
        # 将此线程存储到全局变量中，便于后续停止任务时，停止对应的线程
        ThreadingRecord.threads[task.uuid] = th

    def stop_task(self, uuid):
        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        task_result_obj = TaskResultHandler.get_one_task_result(task.uuid)
        if not task_result_obj:
            raise APIException(sc.NotFound, '未找到任务运行结果记录')
        if task_result_obj.status == TaskResultStatus.stopped:
            raise APIException(sc.TaskStopped)
        task_info.info(f"停止app任务：{task_name}")
        info_log.info(f"停止app任务：{task_name}")
        status_detail = task_result_obj.status_detail
        status_detail.append('准备停止发送流量')
        task_result_obj.update({'status_detail': status_detail, 'status': TaskResultStatus.stopping})
        # 将trex服务停止
        network_structure = task.config.get("network_structure")
        task_type = int(network_structure.get("type"))
        try:
            trex_handler = TrexHandler(trex_host=TREX_HOST,
                                       trex_daemon_port=cache.get(task_name)) if int(
                task_type) == NetworkStructureType.stl else TrexHandler(
                trex_host=TREX_HOST, master_daemon_port=cache.get(task_name))
            trex_handler.stop()
        except ConnectionRefusedError as e:
            pass
        # 将trex守护进程的服务停止
        TrexDaemonHandler.stop_daemon_server(task_name, task_type)
        # 停止发送流量的线程
        th = ThreadingRecord.threads.get(task.uuid)
        if th:
            try:
                stop_thread(th)
            except Exception as e:
                task_info.error(f"停止app任务：{task_name}异常:{e}")
                info_log.error(f"停止app任务：{task_name}异常:{e}")
        status_detail.append('trex服务已经停止')
        task_result_obj.update({'status_detail': status_detail, 'status': TaskResultStatus.stopped})

        # 将redis中缓存的端口信息清除
        cache.delete(task.name)
        # 删除启动trex配置文件及缓存
        delete_start_file(task.name)
        # delete stf yaml config
        self.del_stf_yaml(uuid)
        ThreadingRecord.threads.pop(uuid, None)
        task_info.info(f'停止app任务：{task_name}，停止发送流量成功')
        info_log.info(f'停止app任务：{task_name}，停止发送流量成功')

    def reset_task(self, uuid):
        task = StandardTaskHandler.get_one_by_uuid(uuid)
        task_name = task.name
        # 根据状态判断 是否可以重置任务
        task_result_record = TaskResultHandler.get_one_task_result(uuid)
        if task_result_record and task_result_record.status != TaskResultStatus.stopped:
            raise APIException(sc.TaskNotStopped, '任务未停止，请停止任务后重试')
        # 将任务结果中的数据全部清除
        TaskResultHandler.delete_task_results_by_task_uuid(uuid)
        task_info.info(f'重置app任务：{task_name}，重置成功')
        info_log.info(f'重置app任务：{task_name}，重置成功')
        # 调用开始发送流量的方法重新发送流量
        # return self.start_task(uuid)

    def task_action(self, uuid, action):
        func_dict = {
            TaskAction.start: self.start_task,
            TaskAction.stop: self.stop_task,
            TaskAction.reset: self.reset_task,
        }
        func = func_dict[action]
        return func(uuid)

    def update_task_result_info(self, task_uuid, data):
        obj = TaskResultHandler.get_one_task_result(task_uuid)
        obj.update(data)

    def send_low_stateful_traffic(self, task_uuid):
        """
           stl流量发生
           :param task_uuid: 任务的uuid
           :return:
        """
        from manage import app
        with app.app_context():
            task = StandardTaskHandler.get_one_by_uuid(task_uuid)
            task_result = TaskResultHandler.get_one_task_result(task_uuid)
            status_detail_list = task_result.status_detail
            # 从缓存中去取zmq_port的值
            network_structure = task.config.get("network_structure")
            network_config = network_structure.get("network_config")

            all_port_info = network_config.get('client', []) + network_config.get('server', [])
            port_num_list = [info["port"] for info in all_port_info if info != "dummy"]
            sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
            trex_args = '' if network_structure.get("ip_versions") == 'ipv4' else 'ipv6'
            trex_handler = TrexHandler(trex_host=TREX_HOST, master_daemon_port=cache.get(task.name),
                                       trex_zmq_port=async_port, trex_args=trex_args)
            if not trex_handler.is_running():
                try:
                    trex_handler.start_trex_daemon()
                except Exception as e:
                    task_info.error(f'重启trex_daemon异常:{e}')
                    error_log.error(f'重启trex_daemon异常:{e}')
            task_name = task.name

            trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
            if network_structure.get("dut_mode") == 'NAT':
                # 此处的learn_mode，目前默认为第一种模式，后期可以添加2 3模式
                start_args = {'cfg': trex_config_path, 'learn_mode': 1}
            else:
                start_args = {'cfg': trex_config_path}

            # 生成yaml文件
            task_config = task.config
            specifics = task_config.get("specifics")
            self.generate_stf_yaml(task_uuid, specifics)
            task_info.info(f"启动app任务：{task_name}，成功生成stf配置文件")
            info_log.info(f"启动app任务：{task_name}，成功生成stf配置文件")
            duration = specifics.get("duration")
            traffic_yaml_path = os.path.join(STF_CFG_PATH, '{}.yaml'.format(task_uuid))
            try:
                trex_handler.start_trex(f=traffic_yaml_path, d=duration, **start_args)
                info_log.info(f'启动app任务：{task_name}，成功启动stl状态trex服务，并开始发送流量')
                task_info.info(f'启动app任务：{task_name}，成功启动stl状态trex服务，并开始发送流量')
                status_detail_list.append('trex服务器已启动，并发送流量')
                task_result.update({'status': TaskResultStatus.running, 'status_detail': status_detail_list})
                i = 3600
                while i > 0:
                    if trex_handler.is_idle():
                        break
                    i -= 1
                status_detail_list.append('流量发送成功')
                task_result.update({'status_detail': status_detail_list, 'result': TaskStatus.success,
                                    'end_time': datetime.now()})
            except Exception as e:
                task_info.error(f'启动app任务：{task_name}, 执行stl状态trex服务出错:{e}')
                error_log.error(f'启动app任务：{task_name}, 执行stl状态trex服务出错')
                status_detail_list.append('trex服务出错')
                task_result.update(
                    {'status_detail': status_detail_list, 'result': TaskStatus.fail,
                     'end_time': datetime.now()})
            task_result.update({'status': TaskResultStatus.stopping})
            trex_handler.stop()
            task_info.info(f'启动app任务：{task_name}，停止trex服务')
            info_log.info(f'启动app任务：{task_name}，停止trex服务')
            trex_handler.stop_trex_daemon()
            task_info.info(f'启动app任务：{task_name}，停止trex守护进程服务')
            info_log.info(f'启动app任务：{task_name}，停止trex守护进程服务')
            TrexDaemonHandler.stop_daemon_server(task.name, task.type)
            task_info.info(f'启动app任务：{task_name}，杀掉trex守护进程服务')
            info_log.info(f'启动app任务：{task_name}，杀掉trex守护进程服务')
            status_detail_list.append('trex服务器已停止')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list})
            # 将redis中缓存的端口信息清除
            cache.delete(task.name)
            # 删除启动trex配置文件及缓存
            delete_start_file(task.name)
            # delete stf yaml config
            self.del_stf_yaml(task_uuid)
            task_info.info(f'启动app任务：{task_name}，任务结束')
            info_log.info(f'启动app任务：{task_name}，任务结束')
            ThreadingRecord.threads.pop(task.uuid, None)
