from datetime import datetime

from common.db_manage import DbManager
from extension import db


class CustomTask(db.Model, DbManager):
    """自定义任务表    表名custom_task"""

    __tablename__ = "custom_task"
    uuid = db.Column(db.String(64), primary_key=True)  # 任务uuid
    name = db.Column(db.String(100))  # 任务名称
    description = db.Column(db.String(1024))  # 任务描述
    duration = db.Column(db.Integer, default=-1)  # 持续时间，默认一直发  单位seconds
    network_uuid = db.Column(db.String(64))  # 网络结构中的uuid
    configuration_uuid = db.Column(db.String(64))  # 选择的配置文件的uuid
    type = db.Column(db.Integer)  # 任务类型  1：无状态  2：有状态
    latency_pps = db.Column(db.Integer, default=0)  # 延迟数据包的速率，0表示禁用
    multiplier = db.Column(db.Integer, default=1)  # 比率乘数，将每个模板的cps速率乘以num
    ipv6 = db.Column(db.Boolean, default=False)  # 将模板换成ipv6的模式
    nc = db.Column(db.Boolean, default=False)  # 不要等待流在持续时间结束时关闭
    block = db.Column(db.Boolean, default=True)  # 等待流量启动
    pid_input = db.Column(db.String(64), default='-')  # 输入配置文件uuid
    force = db.Column(db.Boolean, default=False)  # 是否强制启动
    tag_id = db.Column(db.Integer)  # 标签id
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class StandardTask(db.Model, DbManager):
    """标准任务表    表名standard_task"""

    __tablename__ = "standard_task"
    uuid = db.Column(db.String(64), primary_key=True)  # 任务uuid
    name = db.Column(db.String(100))  # 任务名称
    description = db.Column(db.String(1024))  # 任务的描述信息
    config = db.Column(db.JSON)  # 任务执行所需要的数据
    port = db.Column(db.String(64))  # 使用的端口pci号
    target_ip = db.Column(db.String(64))  # 目标ip
    source_ip = db.Column(db.String(64))  # 源ip
    type = db.Column(db.Integer)  # 任务类型  值为：1: DDOS 2:扫描 3:爆破 4:其他
    file_resource_uuid = db.Column(db.String(64))  # 攻击脚本类型的资源文件的uuid
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class TaskSet(db.Model):
    """任务集表    表名task_set      暂时不用"""

    __tablename__ = "task_set"
    uuid = db.Column(db.String(64), primary_key=True)  # 任务集uuid
    name = db.Column(db.String(100))  # 任务集名称
    tasks = db.Column(db.Text)  # 任务uuid列表


class TaskResult(db.Model, DbManager):
    """任务结果表    表名task_result"""

    __tablename__ = "task_result"
    uuid = db.Column(db.String(64), primary_key=True)  # 记录的uuid
    task_uuid = db.Column(db.String(64))  # 任务的uuid
    status = db.Column(db.Integer, default=0)  # 任务状态  0：初始化  1：正在运行  2：正在停止  3：已停止
    status_detail = db.Column(db.JSON)  # 任务状态详细信息
    result = db.Column(db.Integer)  # 任务结果    1：成功  2：失败
    result_detail = db.Column(db.String(1024))  # 任务结果详情
    start_time = db.Column(db.DateTime)  # 开始时间
    end_time = db.Column(db.DateTime)  # 结束时间
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class RFCTask(db.Model, DbManager):
    """
    rfc2544任务表  表名rfc_task
    """
    __tablename__ = "rfc_task"
    uuid = db.Column(db.String(64), primary_key=True)  # 记录的uuid
    name = db.Column(db.String(100), nullable=False)  # 任务的名称
    description = db.Column(db.String(1024))  # 任务的描述信息
    duration = db.Column(db.Integer, nullable=False)  # 测试时间
    rounds = db.Column(db.Integer, nullable=False)  # 测试轮数
    type = db.Column(db.Integer, nullable=False)  # 测试类型，包括： 1:吞吐量 2:丢包率 3:时延 4:背靠背
    payload_mode = db.Column(db.JSON, nullable=False)  # 负载的迭代方式，目前默认为二分法
    network_config = db.Column(db.JSON, nullable=False)  # 网络结构数据
    frame_length = db.Column(db.JSON, nullable=False)  # 帧长度的大小选择方式，目前只是rfc2544规范的列表
    source_port = db.Column(db.Integer, nullable=False)  # 源端口
    dst_port = db.Column(db.Integer, nullable=False)  # 目标端口
    source_ip = db.Column(db.String(20), nullable=False)  # 源IP
    dst_ip = db.Column(db.String(20), nullable=False)  # 目标IP
    source_mac = db.Column(db.String(64), nullable=False)  # 源mac
    dst_mac = db.Column(db.String(64), nullable=False)  # 目标mac
    result = db.Column(db.JSON)  # 测试多次之后的平均结果,格式为：[{64: 199.3}, {128: 199.3}],其中key是帧长，value是速度
    create_time = db.Column(db.DateTime, default=datetime.now)
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)


class RFCTaskResult(db.Model, DbManager):
    """
    rfc2544测试结果分析数据表  表名rfc_result
    """
    __tablename__ = 'rfc_result'
    uuid = db.Column(db.String(64), primary_key=True)  # 记录的uuid
    rfc_task_uuid = db.Column(db.String(64), nullable=False)  # 测试任务的uuid
    round = db.Column(db.Integer, nullable=False)  # 测试轮数，第几轮
    frame_length = db.Column(db.Integer, nullable=False)  # 测试帧长
    max_rate = db.Column(db.Float)  # 最大测试速度，单位pps
    min_rate = db.Column(db.Float)  # 最小测试速度， 单位pps
    transmit_packets = db.Column(db.Integer)  # 发送包的数量
    receive_packets = db.Column(db.Integer)  # 接收包的数量
    result = db.Column(db.Float)  # 测试结果
    create_time = db.Column(db.DateTime, default=datetime.now)


class TaskFlowRecords(db.Model, DbManager):
    """
    流量运行结果记录表  表名flow_records
    """
    __tablename__ = 'flow_records'
    id = db.Column(db.Integer, primary_key=True)  # 记录的uuid
    task_uuid = db.Column(db.String(64), nullable=False)  # 任务的uuid
    group_count = db.Column(db.Integer, nullable=False)  # 执行次数分组，相同表示同一次流量发生产生的数据
    second = db.Column(db.Integer, nullable=False)  # 秒数
    opackets = db.Column(db.Integer)  # 发包数量
    obytes = db.Column(db.Integer)  # 发包大小 单位byte
    tx_bps = db.Column(db.Float)  # 发包速率 单位byte/s
    oerrors = db.Column(db.Integer)  # 发包异常数量
    tx_pps = db.Column(db.Float)
    latency = db.Column(db.Integer)
    jitter = db.Column(db.Integer)
    total_tx_L2 = db.Column(db.Float)
    total_tx_L1 = db.Column(db.Float)
    total_rx = db.Column(db.Float)
    queue_full = db.Column(db.Integer)
    drop_rate = db.Column(db.Float)
    status = db.Column(db.Integer)  # 状态：0有效， 1失效
    record_time = db.Column(db.DateTime, nullable=False)  # 发包时间
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间


class TaskAttackFlowRecords(db.Model, DbManager):
    """
    攻击流量运行结果记录表  表名attack_flow_records
    """
    __tablename__ = 'attack_flow_records'
    id = db.Column(db.Integer, primary_key=True)  # 记录的uuid
    task_uuid = db.Column(db.String(64), nullable=False)  # 任务的uuid
    group_count = db.Column(db.Integer, nullable=False)  # 执行次数分组，相同表示同一次流量发生产生的数据
    second = db.Column(db.Integer, nullable=False)  # 秒数
    opackets = db.Column(db.Integer)  # 发包数量
    obytes = db.Column(db.Integer)  # 发包大小 单位byte
    tx_bps = db.Column(db.Float)  # 发包速率 单位byte/s
    oerrors = db.Column(db.Integer)  # 发包异常数量
    tx_pps = db.Column(db.Float)
    latency = db.Column(db.Integer)
    jitter = db.Column(db.Integer)
    total_tx_L2 = db.Column(db.Float)
    total_tx_L1 = db.Column(db.Float)
    total_rx = db.Column(db.Float)
    queue_full = db.Column(db.Integer)
    drop_rate = db.Column(db.Float)
    packets_sent = db.Column(db.Integer)  # 总发包数量
    bytes_sent = db.Column(db.Integer)  # 总发包大小 单位byte
    errout = db.Column(db.Integer)  # 总发包异常数量
    status = db.Column(db.Integer)  # 状态：0有效， 1失效
    record_time = db.Column(db.DateTime, nullable=False)  # 发包时间
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间


class TaskPortManager(db.Model, DbManager):
    """
    流量任务网口关联表  表名task_port_manager
    """
    __tablename__ = 'task_port_manager'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.String(64), nullable=False)
    status = db.Column(db.Integer, default=0)
    port_name = db.Column(db.String(12))
    port_num = db.Column(db.Integer)
    mac = db.Column(db.String(64))
    msg = db.Column(db.String(1024), default="")
    target_ip = db.Column(db.String(64))
    create_time = db.Column(db.DateTime, default=datetime.now)
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
