import json
import time
from threading import Thread
from geventwebsocket import WebSocketApplication

from app.task.controller.task_manager import get_flow_records_list
from app.task.ops.db_handler import TaskPortManagerHandler
from common import info_log
from common.constant import TaskPortStatus
from utils.redis_util import get_redis_client


class TaskRunningApplication(WebSocketApplication):
    # def __init__(self):
    #     super().__init__()
    #     self.task_id = None

    def on_open(self):
        info_log.info("Task Running Status Connection opened")

    def on_message(self, str_ids):
        from manage import app
        with app.app_context():
            info_log.info(f"TaskRunningApplication str_ids: {str_ids}")
            if not str_ids:
                return
            task_ids = str_ids.split(",")
            if task_ids and len(task_ids) > 0:
                for task_id in task_ids:
                    task_cache = get_redis_client().get("TASK_RUNNING_STATUS_" + task_id)
                    if not task_cache:
                        get_redis_client().set_with_expire("TASK_RUNNING_STATUS_" + task_id, task_id, 5)
                        info_log.info(f"receive client uuid: {task_id}")
                        th = Thread(target=self.refresh_task, args=(task_id,))
                        th.start()
                        time.sleep(1)
                    else:
                        info_log.info(f"{task_id} refresh task thread is already on")

    def refresh_task(self, task_id):
        from manage import app
        with app.app_context():
            running = True
            count = 0
            while not self.ws.closed and running:
                try:
                    task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
                    # info_log.info(f"======task_port_obj: {task_port_obj.to_dict()}")

                    if not task_port_obj:
                        info_log.error(f"task is not exist for [{task_id}]")
                        break

                    info = {}

                    # 1分钟，任务状态还不是准备中，停止线程
                    if count > 60 and task_port_obj.status != TaskPortStatus.preparing and task_port_obj.status != TaskPortStatus.running:
                        info_log.error(f"[{task_id}] is not started")
                        get_redis_client().delete("TASK_RUNNING_STATUS_" + task_id)
                        running = False

                    # 刷新缓存时间
                    get_redis_client().set_with_expire("TASK_RUNNING_STATUS_" + task_id, task_id, 5)

                    status = task_port_obj.status
                    # 封装流量运行结果
                    flow_records_list = get_flow_records_list(task_id)
                    if not flow_records_list or len(flow_records_list) == 0:
                        if count > 2 and status == TaskPortStatus.error:
                            # 流量执行失败
                            info["flow_record"] = {}
                        elif count > 2 and status == TaskPortStatus.stopped:
                            # 流量执行完成
                            info["flow_record"] = {}
                        else:
                            count = count + 2
                            info_log.info(f"{task_id} task is starting...")
                            time.sleep(1)
                            continue
                    else:
                        flow_records_list = flow_records_list[len(flow_records_list) - 1]
                        info["flow_record"] = flow_records_list

                    info["task_id"] = task_id
                    info["status"] = status
                    info["msg"] = task_port_obj.msg if status == TaskPortStatus.error else "success"
                    info_log.info(f"refresh task info: {json.dumps(info)}")

                    self.ws.send(json.dumps(info))
                    if status == TaskPortStatus.error or status == TaskPortStatus.stopped:
                        get_redis_client().delete("TASK_RUNNING_STATUS_" + task_id)
                        running = False
                    time.sleep(1)
                except Exception as e:
                    get_redis_client().delete("TASK_RUNNING_STATUS_" + task_id)
                    info_log.error(f"refresh task error for task:{task_id}, {e}")
                    running = False

    def on_close(self, *args, **kwargs):
        info_log.info(f"Task Running Status Connection closed")
