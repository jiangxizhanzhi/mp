from logging import getLogger

from flask import request
from flask_restplus import Namespace, Resource

from app.task.controller.ddos_task_manager import DDosTaskManager
from common import info_log
from common.constant import TaskAction
from utils import status_code as sc
from utils.exception_tools import ValidateException, StandardTaskNotFound, APIException
from utils.resp_util import resp_message

ddos_namespace = Namespace('', description='Endpoint to manage DDos task')
ddos_task_manager = DDosTaskManager()

task_error = getLogger('task_error')
task_info = getLogger('task_info')


@ddos_namespace.route('/tasks/ddos')
class TasksApi(Resource):
    """
    DDOS任务管理的api类
    """

    def post(self):
        req_data = request.get_json()
        try:
            ddos_task_manager.check_DDos_config(req_data)
        except ValidateException as e:
            return resp_message(code=sc.ParameterError, msg=str(e))
        name = req_data["name"]
        only_name = ddos_task_manager.verify_task_name(name)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        obj = ddos_task_manager.create_task(req_data)
        data = {
            "uuid": obj.uuid
        }
        info_log.info(f"成功新增DDos任务：{name}")
        return resp_message(data=data)

    def delete(self):
        """
        删除
        :return:
        """
        req_data = request.get_json()
        uuids = req_data.get("uuids", [])
        for uuid in uuids:
            can_del = ddos_task_manager.stopped_task(uuid)
            if not can_del:
                return resp_message(code=sc.FailDelete, msg=f'请停止任务{uuid}后在进行删除')
        ddos_task_manager.batch_delete_task(uuids)
        info_log.info(f"成功删除DDos任务")
        return resp_message()


@ddos_namespace.route('/tasks/ddos/<string:uuid>')
class TaskDetailApi(Resource):
    """
    任务详情的api类
    """

    def get(self, uuid):
        """
        获取指定任务的详情
        :param uuid: 任务的uuid
        :return:
        """
        try:
            detail = ddos_task_manager.get_task(uuid)
        except StandardTaskNotFound as e:
            return resp_message(code=sc.NotFound)
        info_log.info(f"成功获取DDos任务信息")
        return resp_message(data=detail)

    def patch(self, uuid):
        """
        编辑指定任务的详情
        :return:
        """
        req_data = request.get_json()
        try:
            task = ddos_task_manager.get_task(uuid)
        except StandardTaskNotFound as e:
            return resp_message(code=sc.NotFound)
        task_is_stoped = ddos_task_manager.stopped_task(uuid)
        if not task_is_stoped:
            return resp_message(code=sc.TaskNotStopped, msg=f'请停止任务{uuid}后在进行编辑')
        try:
            ddos_task_manager.check_DDos_config(req_data, task)
        except ValidateException as e:
            return resp_message(code=sc.ParameterError, msg=str(e))

        name = req_data["name"]
        only_name = ddos_task_manager.verify_task_name(name, uuid)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        ddos_task_manager.update_task(uuid, req_data)
        info_log.info(f"成功编辑DDos任务：{name}")
        return resp_message()


@ddos_namespace.route('/tasks/ddos/list')
class TaskListApi(Resource):

    def get(self):
        per_page = int(request.args.get('per_page')) if request.args.get('per_page') and str(
            request.args.get('per_page')).isdigit() else 10
        page = int(request.args.get('page')) if request.args.get('page') and str(
            request.args.get('page')).isdigit() else 1
        rows, total = ddos_task_manager.task_list(page, per_page, )
        data = {
            "rows": rows,
            "total": total
        }
        info_log.info(f"成功获取DDos任务列表")
        return resp_message(data=data)


@ddos_namespace.route('/tasks/ddos/action')
class TaskActionApi(Resource):

    def post(self):
        """
        任务操作
        :return:
        """
        req_data = request.get_json()
        uuid = req_data.get("uuid")
        action = req_data.get("action")
        if not uuid or action not in TaskAction.TASK_ACTION_DICT:
            return resp_message(code=sc.ParameterError)
        try:
            task = ddos_task_manager.get_task(uuid)
        except StandardTaskNotFound as e:
            return resp_message(code=sc.NotFound)
        task_name = task.get("name")
        # 开始 停止 重置
        try:
            ddos_task_manager.task_action(uuid, action)
        except APIException as e:
            resp = resp_message(code=e.code, msg=e.message)
            # error_msg = resp.get("msg")
            return resp
        return resp_message()
