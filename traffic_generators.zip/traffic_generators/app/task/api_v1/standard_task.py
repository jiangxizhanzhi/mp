from flask import request
from flask_restplus import Namespace, Resource

from app.task.controller.task_manager import create_standard_task, get_standard_task_list, delete_standard_task, \
    get_standard_task_detail, update_standard_task, standard_task_action, get_standard_task_result, \
    all_task_result_of_task, task_of_batch_list, custom_task_action, get_protocols_top5
from utils.resp_util import resp_message

standard_namespace = Namespace('', description='Endpoint to manage custom task')


@standard_namespace.route('/tasks/standards')
class StandardTaskApi(Resource):
    """
    标准实验室任务的操作api
    """

    def get(self):
        """
        获取标准实验室任务的列表
        :return:
        """
        params = request.args.to_dict()
        response = get_standard_task_list(params)
        return resp_message(**response)

    def post(self):
        """
        创建标准实验室任务
        :return:
        """
        params = request.get_json()
        response = create_standard_task(params)
        return resp_message(**response)

    def delete(self):
        """
        删除标准实验室任务
        :return:
        """
        params = request.get_json()
        response = delete_standard_task(params)
        return resp_message(**response)


@standard_namespace.route('/tasks/standards/<string:uuid>')
class StandardTaskDetailApi(Resource):
    """
    标准实验室任务详情的API操作
    """

    def get(self, uuid):
        """
        标准实验室任务详情展示
        :param uuid: 任务的uuid
        :return:
        """
        response = get_standard_task_detail(uuid)
        return resp_message(**response)

    def patch(self, uuid):
        """
        标准实验室任务的修改
        :param uuid: 任务的uuid
        :return:
        """
        params = request.get_json()
        response = update_standard_task(uuid, params)
        return resp_message(**response)


@standard_namespace.route('/tasks/standards/action')
class StandardTaskActionApi(Resource):
    """
    标准实验室任务操作的api
    """

    def post(self):
        """
        操作标准实验室任务，包括：开始，停止，重置
        :return:
        """
        params = request.get_json()
        response = standard_task_action(params)
        return resp_message(**response)


@standard_namespace.route('/tasks/custom/action')
class StandardTaskActionApi(Resource):
    """
    自定义任务操作的api
    """

    def post(self):
        """
        操作自定义任务，包括：开始，停止，重置
        :return:
        """
        params = request.get_json()
        response = custom_task_action(params)
        return resp_message(**response)


@standard_namespace.route('/tasks/standards/<string:uuid>/result')
class StandardTaskRunResultApi(Resource):
    """
    获取指定标准实验室任务运行容器之后的结果
    """

    def get(self, uuid):
        """
        获取标准实验室任务运行容器之后的结果
        :return:
        """
        response = get_standard_task_result(uuid)
        return resp_message(**response)


@standard_namespace.route('/standard/result/<string:uuid>/list')
class TaskResultListInfo(Resource):

    def get(self, uuid):
        """
        获取指定任务的所有执行结果
        :param uuid: 任务的uuid
        :return:
        """
        response = all_task_result_of_task(uuid, standard_task=True)
        return resp_message(**response)


@standard_namespace.route('/tasks/standards/many')
class TaskInfoOfBatch(Resource):

    def post(self):
        req_data = request.get_json()
        uuids = req_data.get("uuids")
        data = task_of_batch_list(uuids)
        data = {
            "rows": data,
        }
        return resp_message(data=data)


@standard_namespace.route('/tasks/protocols/top5')
class TaskInfoOfBatch(Resource):

    def post(self):
        result = get_protocols_top5()
        data = {
            "protocols": result,
        }
        return resp_message(data=data)
