from flask import request
from flask_restplus import Namespace, Resource
from logging import getLogger

from common.constant import TaskAction
from common import info_log
from utils.resp_util import resp_message
from utils import status_code as sc
from utils.exception_tools import StandardTaskNotFound, APIException
from app.task.controller.app_task_manager import AppTaskManager

app_namespace = Namespace('', description='Endpoint to manage APP task')
app_task_manager = AppTaskManager()

task_error = getLogger('task_error')
task_info = getLogger('task_info')


@app_namespace.route('/tasks/app')
class TasksApi(Resource):
    """
    中台任务管理的api类
    """

    def post(self):
        req_data = request.get_json()
        name = req_data["name"]
        only_name = app_task_manager.verify_task_name(name)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        obj = app_task_manager.create_task(req_data)
        data = {
            "uuid": obj.uuid
        }
        info_log.info(f"add app task success：{name}")
        return resp_message(data=data)

    def delete(self):
        """
        删除
        :return:
        """
        req_data = request.get_json()
        uuids = req_data.get("uuids", [])
        for uuid in uuids:
            can_del = app_task_manager.stopped_task(uuid)
            if not can_del:
                return resp_message(code=sc.FailDelete, msg=f'Please stop task {uuid} before deleting')
        app_task_manager.batch_delete_task(uuids)
        info_log.info(f"delete app task success")
        return resp_message()


@app_namespace.route('/tasks/app/<string:uuid>')
class TaskDetailApi(Resource):
    """
    任务详情的api类
    """

    def get(self, uuid):
        """
        获取指定任务的详情
        :param uuid: 任务的uuid
        :return:
        """
        try:
            detail = app_task_manager.get_task(uuid)
        except StandardTaskNotFound as e:
            return resp_message(code=sc.NotFound)
        info_log.info(f"get app task info success")
        return resp_message(data=detail)

    def patch(self, uuid):
        """
        编辑指定任务的详情
        :return:
        """
        req_data = request.get_json()

        task_is_stoped = app_task_manager.stopped_task(uuid)
        if not task_is_stoped:
            return resp_message(code=sc.TaskNotStopped, msg=f'Please stop task {uuid} before editing')

        name = req_data["name"]
        only_name = app_task_manager.verify_task_name(name, uuid)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        app_task_manager.update_task(uuid, req_data)
        info_log.info(f"edit app task success：{name}")
        data = {
            "uuid": uuid
        }
        return resp_message(data=data)


@app_namespace.route('/tasks/app/list')
class TaskListApi(Resource):

    def get(self):
        per_page = int(request.args.get('per_page')) if request.args.get('per_page') and str(
            request.args.get('per_page')).isdigit() else 10
        page = int(request.args.get('page')) if request.args.get('page') and str(
            request.args.get('page')).isdigit() else 1
        rows, total = app_task_manager.task_list(page, per_page, )
        data = {
            "rows": rows,
            "total": total
        }
        info_log.info(f"get app task list success")
        return resp_message(data=data)


@app_namespace.route('/tasks/app/action')
class TaskActionApi(Resource):

    def post(self):
        """
        任务操作
        :return:
        """
        req_data = request.get_json()
        uuid = req_data.get("uuid")
        action = req_data.get("action")
        if not uuid or action not in TaskAction.TASK_ACTION_DICT:
            return resp_message(code=sc.ParameterError)
        try:
            app_task_manager.task_action(uuid, action)
        except APIException as e:
            resp = resp_message(code=e.code, msg=e.message)
            return resp
        return resp_message()