from flask import request, send_file
from flask_restplus import Namespace, Resource

from app.task.controller.rfc_task_manager import create_rfc_task, get_rfc_task_list, delete_rfc_task, \
    get_rfc_task_detail, update_rfc_task, rfc_task_operation, get_rfc_detail_result, download_rfc_report
from utils.exception_tools import DataException
from utils.resp_util import resp_message

rfc_namespace = Namespace('', description='Endpoint to manage rfc task')


@rfc_namespace.route('/tasks/rfc')
class RFCManagerApi(Resource):
    """
    rfc2544任务管理api
    """

    def get(self):
        """
        获取rfc2544任务的列表
        :return:
        """
        name = request.args.get('name')
        page = request.args.get('page')
        per_page = request.args.get('per_page')
        type = request.args.get('type')
        response = get_rfc_task_list(name, page, per_page, type)
        return resp_message(**response)

    def post(self):
        """
        创建rfc2544任务
        :return:
        """
        req_data = request.get_json()
        response = create_rfc_task(req_data)
        return resp_message(**response)

    def delete(self):
        """
        删除rfc2544任务
        :return:
        """
        req_date = request.get_json()
        response = delete_rfc_task(req_date)
        return resp_message(**response)


@rfc_namespace.route('/tasks/rfc/<string:uuid>')
class RFCTaskDetailApi(Resource):
    """
    rfc2544任务详情的api
    """

    def get(self, uuid):
        """
        获取rfc2544任务的详细信息
        :param uuid: 任务的uuid
        :return:
        """
        response = get_rfc_task_detail(uuid)
        return resp_message(**response)

    def patch(self, uuid):
        """
        编辑rfc2544任务的详细信息
        :param uuid: 任务的uuid
        :return:
        """
        req_data = request.get_json()
        response = update_rfc_task(uuid, req_data)
        return resp_message(**response)


@rfc_namespace.route('/tasks/rfc/action')
class RFCTaskActionApi(Resource):
    """
    任务操作的api，包括： 开始、停止、重置
    """

    def post(self):
        """
        rfc2544任务的操作，包括：开始、停止、重置
        :return:
        """
        req_data = request.get_json()
        response = rfc_task_operation(req_data)
        return resp_message(**response)


@rfc_namespace.route('/tasks/rfc/result')
class RFCTaskResultApi(Resource):
    """
    rfc2544任务的分析结果的信息api
    """

    def get(self):
        """
        获取rfc2544测试任务的分析结果信息
        :return:
        """
        task_uuid = request.args.get('uuid')
        response = get_rfc_detail_result(task_uuid)
        return resp_message(**response)


@rfc_namespace.route('/tasks/rfc/report')
class RFCReportDownloadAPi(Resource):
    """
    rfc2544任务的报告下载
    """
    def get(self):
        """
        根据任务uuid下载rfc2544任务的报告
        :return:
        """
        task_uuid = request.args.get('task_uuid')
        try:
            file_path = download_rfc_report(task_uuid)
        except DataException:
            return None
        return send_file(file_path, as_attachment=True)