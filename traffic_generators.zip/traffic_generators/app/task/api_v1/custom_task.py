import json
import os
from logging import getLogger
from threading import Thread

from flask import request, send_file
from flask_restplus import Namespace, Resource

from app.software.controller.software_manager import init_ports, init_networks
from app.task.controller.task_manager import create_custom_task, delete_custom_task, update_custom_task, \
    get_custom_task_detail, get_custom_task_list, task_operation, all_task_result_of_task, download_all_pcap, \
    init_trex_server, task_batch_operation, v2_task_operation, v2_task_batch_operation
from utils import status_code as sc
from utils.redis_util import RedisUtil, get_redis_client
from utils.resp_util import resp_message, exec_cmd

custom_namespace = Namespace('', description='Endpoint to manage custom task')
task_info = getLogger('task_info')


@custom_namespace.route('/tasks')
class CustomTasksApi(Resource):
    """
    自定义任务管理的api类
    """

    def post(self):
        """
        创建自定义任务
        :return:
        """
        params = request.get_json()
        response = create_custom_task(params)
        return resp_message(**response)

    def delete(self):
        """
        删除自定义任务
        :return:
        """
        params = request.get_json()
        response = delete_custom_task(params)
        return resp_message(**response)


@custom_namespace.route('/tasks/<string:uuid>')
class CustomTaskDetailApi(Resource):
    """
    自定义任务详情的api类
    """

    def get(self, uuid):
        """
        获取指定自定义任务的详情
        :param uuid: 任务的uuid
        :return:
        """
        response = get_custom_task_detail(uuid)
        return resp_message(**response)

    def patch(self, uuid):
        """
        编辑指定自定义任务的详情
        :return:
        """
        params = request.get_json()
        response = update_custom_task(uuid, params)
        return resp_message(**response)


@custom_namespace.route('/tasks/list')
class TaskListApi(Resource):
    """
    自定义任务列表的api
    """

    def get(self):
        """
        获取自定义任务的列表
        :return:
        """
        name = request.args.get('name')
        page = request.args.get('page')
        per_page = request.args.get('per_page')
        tag_id = request.args.get('tag_id')
        response = get_custom_task_list(name, page, per_page, tag_id)
        return resp_message(**response)


@custom_namespace.route('/tasks/action')
class TaskActionApi(Resource):
    """
    任务操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = task_operation(params)
        return resp_message(**response)


@custom_namespace.route('/tasks/batch/action')
class TaskActionApi(Resource):
    """
    任务批量操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = task_batch_operation(params)
        return resp_message(**response)


@custom_namespace.route('/result/<string:uuid>/list')
class TaskResultListInfo(Resource):

    def get(self, uuid):
        """
        获取指定任务的所有执行结果
        :param uuid: 任务的uuid
        :return:
        """
        response = all_task_result_of_task(uuid)
        return resp_message(**response)


@custom_namespace.route('/download_pcap/<string:uuid>')
class DownloadPcapApi(Resource):
    """
    下载流量包的api
    """

    def get(self, uuid):
        """
        下载任务运行时捕获到的流量包
        :param uuid: 任务的uuid
        :return:
        """
        file_path = download_all_pcap(uuid)
        return send_file(file_path, as_attachment=True)


@custom_namespace.route('/tasks/init')
class TaskActionApi(Resource):
    """
    任务初始化api
    """

    def post(self):
        """
        任务初始化
        :return:
        """
        params = request.get_json()
        network_infos = params.get('network_infos')
        task_info.info(f"skip task init networkInfos:{network_infos}")
        # if not network_infos:
        #     res = exec_cmd("sudo ip a | grep veth1@veth2 |grep -v grep | awk '{print $2}'")
        #     str_res = str(res, 'utf-8')
        #     init_result = get_redis_client().get("TASKS_INIT_RESULT")
        #     task_info.info(f"redis init result: {init_result}")
        #     if not init_result:
        #         get_redis_client().set("TASKS_INIT_RESULT", "TASKS_INIT_RESULT")
        #     if os.path.exists('/root/init.txt') and not str_res and not init_result:
        #         with open("/root/init.txt", "r") as f:
        #             lines = f.readlines()
        #             task_info.info(f"network_infos line:{lines[0]}")
        #             network_infos = json.loads(lines[0])
        #     else:
        #         task_info.error("networkInfos can not be empty")
        #         return resp_message(code=sc.ParameterError)
        # else:
        #     # 保存网口初始化数据
        #     with open("/root/init.txt", "w") as f:
        #         f.write(json.dumps(network_infos))
        #
        # added_ports_info, is_out_net = init_ports(network_infos)
        # # 初始化trex服务
        # init_trex_server(added_ports_info)

        return resp_message()


@custom_namespace.route('/network/init')
class NetworkApi(Resource):
    """
    网口初始化api
    """

    def post(self):
        """
        网口初始化
        :return:
        """
        params = request.get_json()
        network_infos = params.get('network_infos')
        task_info.info(f"network init networkInfos:{network_infos}")
        if not network_infos:
            task_info.error("networkInfos can not be empty")
            return resp_message(code=sc.ParameterError)

        return init_networks(network_infos)


@custom_namespace.route('/v2/tasks/action')
class TaskActionApi(Resource):
    """
    任务操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = v2_task_operation(params)
        return resp_message(**response)


@custom_namespace.route('/v2/tasks/batch/action')
class TaskActionApi(Resource):
    """
    任务批量操作管理的api
    """

    def post(self):
        """
        任务操作
        :return:
        """
        params = request.get_json()
        response = v2_task_batch_operation(params)
        return resp_message(**response)
