from flask import Blueprint
from flask_restplus import Api

from app.task.api_v1.custom_task import custom_namespace
from app.task.api_v1.rfc_task import rfc_namespace
from app.task.api_v1.standard_task import standard_namespace
from app.task.api_v1.ddos_task import ddos_namespace
from app.task.api_v1.app_task import app_namespace

task_blueprint = Blueprint('task_blueprint', __name__)
task_api = Api(task_blueprint, version='v1')

# 添加任务管理中的每个命名空间url, 也就是每个大模块下面的每个小模块分成不同的url
task_api.add_namespace(custom_namespace)
task_api.add_namespace(standard_namespace)
task_api.add_namespace(ddos_namespace)
task_api.add_namespace(app_namespace)
task_api.add_namespace(rfc_namespace)


