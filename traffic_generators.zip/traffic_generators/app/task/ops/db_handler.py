import os
from logging import getLogger

from sqlalchemy import desc, func
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from app import CustomTask, TaskResult, StandardTask, RFCTask, RFCTaskResult, TaskFlowRecords, TaskAttackFlowRecords, \
    TaskPortManager
from common.constant import TaskResultStatus
from config import BASE_DIR
from extension import db
from utils.exception_tools import StandardTaskNotFound

task_info = getLogger('task_info')


class CustomTaskHandler(CustomTask):
    """
    自定义任务操作数据库类
    """

    @classmethod
    def delete_trex_config_by_task_uuid(cls, task_uuid):
        """
        根据uuid列表删除自定义任务的记录，同时删除对应的配置文件
        :param task_uuid: 自定义任务的uuid
        :return:
        """
        obj = cls.query.filter(cls.uuid == task_uuid).first()
        # 删除生成的配置文件
        path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(obj.name))
        if os.path.exists(path):
            os.remove(path)

    @classmethod
    def get_tasks_by_configure_uuid(cls, configure_uuid):
        """
        根据配置配置文件的uuid
        :param configure_uuid: 配置文件的uuid
        :return:
        """
        tasks = cls.query.filter(cls.configuration_uuid == configure_uuid).all()
        return [task.uuid for task in tasks]

    @classmethod
    def get_all_by_filter(cls, page, per_page, filters):
        """
        获取自定义任务的列表
        :param page: 页码
        :param per_page: 每页显示的数量
        :param filters: 过滤条件
        :return:
        """

        profile_pagination = cls.query.filter(*filters).paginate(page, per_page, False)

        return profile_pagination.items, profile_pagination.total

    @classmethod
    def get_task_by_uuid(cls, uuid):
        return cls.query.filter(cls.uuid == uuid).first()


class TaskResultHandler(TaskResult):
    """
    自定义任务结果的操作类
    """

    @classmethod
    def get_task_status_by_task_uuids(cls, task_uuids):
        """
        根据任务的uuid，获取任务结果的对象
        :param task_uuids: 任务的uuid列表
        :return:
        """
        task_results = cls.query.filter(cls.task_uuid.in_(task_uuids)).all()
        return [task_result.status for task_result in task_results]

    @classmethod
    def get_task_result_by_task_uuid(cls, task_uuid):
        task_results = cls.query.filter(cls.task_uuid == task_uuid).order_by(desc('create_time')).all()
        return task_results

    @classmethod
    def stopped_task_result_by_task_uuid(cls, task_uuid):
        task_results = cls.query.filter(cls.task_uuid == task_uuid, cls.status == TaskResultStatus.stopped).order_by(
            desc('create_time')).all()
        return task_results

    @classmethod
    def delete_task_results_by_task_uuid(cls, task_uuid):
        cls.query.filter(cls.task_uuid == task_uuid).delete(synchronize_session=False)
        cls.commit()

    @classmethod
    def get_one_task_result(cls, task_uuid):
        task_result = cls.query.filter(cls.task_uuid == task_uuid).order_by(-cls.create_time).first()
        return task_result

    @classmethod
    def latest_result_info_of_batch_task(cls, task_uuids):
        if len(task_uuids) == 0:
            task_uuids.append('')

        sql_str = '''
                                    SELECT
                                        A.task_uuid,
                                        A.`status`,
                                        A.`result`,
                                        A.`result_detail`,
                                        A.create_time
                                    FROM
                                        task_result AS A,
                                        ( SELECT task_uuid, MAX( create_time ) AS btime FROM task_result WHERE task_uuid in :task_uuids GROUP BY task_uuid ) AS B
                                    WHERE
                                        A.task_uuid = B.task_uuid
                                        AND A.create_time = B.btime
                                    '''
        cursor = db.session.execute(sql_str, params={"task_uuids": task_uuids})
        result_list = [dict(row) for row in cursor]
        result_dict = {item["task_uuid"]: item for item in result_list}
        return result_dict

    @classmethod
    def batch_update_result_status(cls, task_status, task_result, task_uuids):
        if len(task_uuids) == 0:
            task_uuids.append('')

        sql_str = '''
                    update 
                        task_result AS A
                        set A.`status` = :task_status,
                            A.`result` = :task_result
                    where A.`task_uuid` in :task_uuids
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_result": task_result,
                                                     "task_uuids": task_uuids})
        cls.commit()
        return cursor

    @classmethod
    def update_status_by_task_id(cls, task_status, task_uuid, task_result):
        """
        根据任务id更新状态
        :param task_status:
        :param task_uuid:
        :param task_result:
        :return:
        """
        sql_str = '''
                    update 
                        task_result AS A
                        set A.`status` = :task_status,
                        A.`result` = :task_result
                    where A.`task_uuid` = :task_uuid
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_uuid": task_uuid,
                                                     "task_result": task_result})
        cls.commit()
        return cursor

    @classmethod
    def update_status_by_task_id_with_msg(cls, task_status, task_uuid, task_result, result_detail):
        """
        根据任务id更新状态
        :param task_status:
        :param task_uuid:
        :param task_result:
        :param result_detail:
        :return:
        """
        sql_str = '''
                        update 
                            task_result AS A
                            set A.`status` = :task_status,
                            A.`result` = :task_result,
                            A.`result_detail` = :result_detail
                        where A.`task_uuid` = :task_uuid
                        '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_uuid": task_uuid,
                                                     "task_result": task_result, "result_detail": result_detail})
        cls.commit()
        return cursor


class StandardTaskHandler(StandardTask):
    """
    标准任务的操作类
    """

    @classmethod
    def get_all_by_filter(cls, name, type, page, per_page):
        """
        获取标准任务的列表
        :param name: 标准任务的名称，如果存在，则会筛选出包含该名字的标准任务记录
        :param type: 标准任务的类型，1：ddos, 2:扫描， 3：爆破
        :param page: 页码
        :param per_page: 每页显示的数量
        :return:
        """
        filters_list = []
        if name:
            filters_list.append(cls.name.contains(name))
        if type:
            filters_list.append(cls.type == type)

        profile_pagination = cls.query.filter(*filters_list).paginate(page, per_page, False)

        return profile_pagination.items, profile_pagination.total

    @classmethod
    def get_task_by_uuid(cls, uuid):
        return cls.query.filter(cls.uuid == uuid).first()

    @classmethod
    def get_obj_by_uuid(cls, uuid):
        try:
            obj = cls.query.filter(cls.uuid == uuid).one()
        except (NoResultFound, MultipleResultsFound) as e:
            raise StandardTaskNotFound(uuid, str(e))
        return obj

    @classmethod
    def get_task_status_by_task_uuids(cls, task_uuids):
        """
        根据任务的uuid，获取任务结果的对象
        :param task_uuids: 任务的uuid列表
        :return:
        """
        task_results = cls.query.filter(cls.task_uuid.in_(task_uuids)).all()
        return [task_result.status for task_result in task_results]

    @classmethod
    def batch_task_by_uuids(cls, uuids):
        qs = cls.query.filter(cls.uuid.in_(uuids)).all()
        return qs

    @classmethod
    def get_in_use_attack_scripts_uuids(cls):
        """
        获取正在使用中的攻击脚本uuids
        """
        uuids = db.session.query(cls.file_resource_uuid).all()
        return uuids


class RFCTaskHandler(RFCTask):
    """
    rfc2544任务的操作类
    """

    @classmethod
    def get_all_by_filter(cls, name, type, page, per_page):
        """
        获取rfc2544任务的列表
        :param name: 任务的名称，如果存在，则会筛选出包含该名字的任务记录
        :param type: 任务的测试类型，1:吞吐量 2:丢包率 3:时延 4:背靠背
        :param page: 页码
        :param per_page: 每页显示的数量
        :return:
        """
        filters_list = []
        if name:
            filters_list.append(cls.name.contains(name))
        if type:
            filters_list.append(cls.type == type)

        rfc_task_pagination = cls.query.filter(*filters_list).paginate(page, per_page, False)

        return rfc_task_pagination.items, rfc_task_pagination.total

    @classmethod
    def delete_trex_config_by_task_uuid(cls, task_uuid):
        """
        根据uuid列表删除rfc2544任务的记录，同时删除对应的配置文件
        :param task_uuid: rfc2544任务的uuid
        :return:
        """
        obj = cls.query.filter(cls.uuid == task_uuid).first()
        # 删除生成的配置文件
        path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(obj.name))
        if os.path.exists(path):
            os.remove(path)


class RFCTaskResultHandler(RFCTaskResult):
    """
    rfc2544任务的分析结果的操作类
    """

    @classmethod
    def get_latest_by_task_uuid(cls, uuid, round, size):
        """
        通过任务的uuid获取到最后一次的分析结果
        :param uuid: 任务的uuid
        :param round: 轮次
        :return:
        """
        return cls.query.filter(cls.rfc_task_uuid == uuid, cls.round == round, cls.frame_length == size).order_by(
            -cls.create_time).first()

    @classmethod
    def delete_results_by_task_uuid(cls, task_uuid):
        """
        根据rfc任务的uuid删除所有的结果
        :param task_uuid: 任务的uuid
        :return:
        """
        cls.query.filter(cls.rfc_task_uuid == task_uuid).delete(synchronize_session=False)
        cls.commit()

    @classmethod
    def get_all_by_task_uuid(cls, task_uuid):
        """
        根据任务的uuid，获取所有的结果
        :param task_uuid: 任务的uuid
        :return:
        """
        return cls.query.filter(cls.rfc_task_uuid == task_uuid).order_by(cls.create_time).all()


class TaskFlowRecordsHandler(TaskFlowRecords):
    """
    任务流量记录结果的操作类
    """

    @classmethod
    def get_all_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取所有流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        return cls.query.filter(cls.task_uuid == task_uuid).order_by(cls.create_time).all()

    @classmethod
    def get_max_group_count_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最大执行次数
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        return 0 if not max_group_count else max_group_count

    @classmethod
    def get_last_records_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最新的流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        max_group_count = 1 if not max_group_count else max_group_count
        return cls.query.filter(cls.task_uuid == task_uuid, cls.group_count == max_group_count,
                                cls.status == 0).order_by(cls.create_time).all()

    @classmethod
    def batch_update_records_status(cls, task_status, task_uuid):
        """
        根据任务id批量更新记录状态
        :param task_status:
        :param task_uuid:
        :return:
        """
        if not task_uuid:
            task_uuid = ''

        sql_str = '''
                    update 
                        flow_records AS A
                        set A.`status` = :task_status
                    where A.`task_uuid` = :task_uuid
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_uuid": task_uuid})
        cls.commit()
        return cursor


class TaskAttackFlowRecordsHandler(TaskAttackFlowRecords):
    """
    攻击任务流量记录结果的操作类
    """

    @classmethod
    def get_all_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取所有流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        return cls.query.filter(cls.task_uuid == task_uuid).order_by(cls.create_time).all()

    @classmethod
    def get_max_group_count_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最大执行次数
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        return 0 if not max_group_count else max_group_count

    @classmethod
    def get_last_records_by_task_uuid(cls, task_uuid):
        """
        通过任务的uuid获取最新的流量记录
        :param task_uuid: 任务的uuid
        :return:
        """
        # 查询最大执行次数分组
        max_group_count = db.session.query(func.max(cls.group_count)).filter(cls.task_uuid == task_uuid).first()[0]
        max_group_count = 1 if not max_group_count else max_group_count
        return cls.query.filter(cls.task_uuid == task_uuid, cls.group_count == max_group_count,
                                cls.status == 0).order_by(cls.create_time).all()

    @classmethod
    def batch_update_records_status(cls, task_status, task_uuid):
        """
        根据任务id批量更新记录状态
        :param task_status:
        :param task_uuid:
        :return:
        """
        if not task_uuid:
            task_uuid = ''

        sql_str = '''
                    update 
                        attack_flow_records AS A
                        set A.`status` = :task_status
                    where A.`task_uuid` = :task_uuid
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_uuid": task_uuid})
        cls.commit()
        return cursor


class TaskPortManagerHandler(TaskPortManager):
    """
    流量任务网口管理类
    """

    @classmethod
    def get_all_by_mac(cls, mac):
        """
        通过mac获取网口管理数据
        :param mac: mac
        :return:
        """
        return cls.query.filter(cls.mac == mac).order_by(-cls.create_time).all()

    @classmethod
    def get_max_port_num(cls):
        """
        查询最大端口号
        :return:
        """
        max_port_num = db.session.query(func.max(cls.port_num)).first()[0]
        return 0 if not max_port_num else max_port_num

    @classmethod
    def get_by_task_id(cls, task_id):
        """
        通过task_id获取网口管理数据
        :param task_id: task_id
        :return:
        """
        task_port = cls.query.filter(cls.task_id == task_id).order_by(-cls.create_time).first()
        cls.commit()
        return task_port


    @classmethod
    def get_by_task_ids(cls, task_ids):
        """
        通过task_ids获取网口管理数据
        :param task_ids: 任务id集合
        :return:
        """
        return cls.query.filter(cls.task_id.in_(task_ids)).order_by(-cls.create_time).all()


    @classmethod
    def get_running_tasks(cls):
        """
        获取运行中的任务
        :return:
        """
        return cls.query.filter(cls.status.in_([0, 1, 4, 5])).order_by(-cls.create_time).all()


    @classmethod
    def get_push_tasks(cls):
        """
        获取待推送任务
        :return:
        """
        return cls.query.filter(cls.status.in_([1, 4])).order_by(-cls.create_time).all()

    @classmethod
    def batch_update_status(cls, task_status, task_ids):
        """
        根据任务id更新状态
        :param task_status:
        :param task_ids:
        :return:
        """
        sql_str = '''
                        update 
                            task_port_manager AS A
                            set A.`status` = :task_status
                        where A.`task_id` in :task_ids
                        '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_ids": task_ids})
        cls.commit()
        return cursor

    @classmethod
    def update_status_by_task_id(cls, task_status, task_id):
        """
        根据任务id更新状态
        :param task_status:
        :param task_id:
        :return:
        """
        if not task_id:
            task_id = ''

        sql_str = '''
                    update 
                        task_port_manager AS A
                        set A.`status` = :task_status
                    where A.`task_id` = :task_id
                    '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_id": task_id})
        cls.commit()
        return cursor

    @classmethod
    def update_status_msg_by_task_id(cls, task_status, task_id, msg):
        """
        根据任务id更新状态
        :param task_status:
        :param task_id:
        :param msg:
        :return:
        """
        if not task_id:
            task_id = ''

        sql_str = '''
                        update 
                            task_port_manager AS A
                            set A.`status` = :task_status,
                            A.`msg` = :msg
                        where A.`task_id` = :task_id
                        '''
        cursor = db.session.execute(sql_str, params={"task_status": task_status, "task_id": task_id, "msg": msg})
        cls.commit()
        return cursor
