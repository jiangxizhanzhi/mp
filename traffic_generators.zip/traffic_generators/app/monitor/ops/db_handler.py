import os

from app import TmpPcap


class TmpPcapHandler(TmpPcap):

    @classmethod
    def get_pcap_by_uuid(cls, uuid):
        return cls.query.filter(cls.uuid == uuid).first()

    @classmethod
    def get_all_tmppcap(cls, page, per_page):
        if page and per_page:
            pcaps = cls.query.filter().paginate(page, per_page, False)
        else:
            pcaps = cls.query.all()
        return pcaps

    @classmethod
    def get_pcaps_by_task_uuid(cls, task_uuid):
        """
        根据任务的uuid获取所有的pcap包记录
        :param task_uuid:  任务的uuid
        :return:
        """
        return cls.query.filter(cls.task_uuid == task_uuid, cls.status == 1).all()

    @classmethod
    def delete_by_task_uuid(cls, task_uuid):
        """
        根据任务的uuid删除对应的pcap包记录
        :param task_uuid:  任务的uuid
        :return:
        """
        cls.query.filter(cls.task_uuid == task_uuid).delete(synchronize_session=False)
        cls.commit()

    @classmethod
    def delete_pcap_files_by_task_uuid(cls, task_uuid):
        """
        删除任务的捕获到的流量包文件
        :param task_uuid:  任务的uuid
        :return:
        """
        objs = cls.query.filter(cls.task_uuid == task_uuid).all()
        for pcap_obj in objs:
            if os.path.exists(pcap_obj.pcap_path):
                os.remove(pcap_obj.pcap_path)
