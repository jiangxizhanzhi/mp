import json
import os
import time
from logging import getLogger

from trex.astf.trex_astf_client import ASTFClient
from trex.stl.trex_stl_client import STLClient

from app.software.ops.db_handler import PortHandler
from app.task.ops.db_handler import StandardTaskHandler, CustomTaskHandler
from common import error_log
from config import BASE_DIR, TREX_HOST

monitor_error = getLogger('monitor_error')
monitor_info = getLogger('monitor_info')


def get_port(message_dict):
    """
    根据trex名称和interface获取网口
    """
    from manage import app
    app_context = app.app_context()
    app_context.push()
    ports = []
    task_uuid = message_dict.get('trex_name')
    interface = message_dict.get('interface')
    for pci in interface:
        port_obj = PortHandler.get_port_by_taskuuid_pci(task_uuid, pci)
        ports.append(port_obj.port)
    app_context.pop()
    return ports


def get_trex_by_port(ports):
    """
    根据网口获取trex对象和port对象
    :param ports 网口
    :return:
    """
    # 根据网口获取port对象
    from manage import app
    app_context = app.app_context()
    app_context.push()
    trex_ports, port_objs = [], []
    for port in ports:
        port_obj = PortHandler.get_obj_by_port(port)
        port_objs.append(port_obj)

        # 根据任务uuid获取任务名称 _task结尾为自定义任务  _standardTask结尾为标准任务
        if 'standard' in port_obj.task_uuid.split('_'):
            standard_task = StandardTaskHandler.get_task_by_uuid(port_obj.task_uuid)
            task_name = standard_task.name
            type = standard_task.config.get('network_structure').get('type')
        else:
            custom_task = CustomTaskHandler.get_task_by_uuid(port_obj.task_uuid)
            task_name = custom_task.name
            type = custom_task.type

        # 根据任务名称获取任务配置文件 解析配置文件，根据interfaces和pci，确定传参给trex是0还是1
        profile = os.path.join(BASE_DIR, 'media/trex_configs', f'{task_name}.yaml')
        with open(profile, 'r') as f:
            file = f.read()
        import yaml
        yaml_config = yaml.load(file)[0]

        interfaces = yaml_config.get('interfaces')
        trex_port = interfaces.index(port_obj.pci)
        trex_ports.append(trex_port)
        zmq_pub_port = yaml_config.get('zmq_pub_port')
        zmq_rpc_port = yaml_config.get('zmq_rpc_port')
        # type    1 无状态   2 有状态
        if type == 1:
            trex_client = STLClient(server=TREX_HOST, sync_port=zmq_rpc_port, async_port=zmq_pub_port)
        else:
            trex_client = ASTFClient(server=TREX_HOST, sync_port=zmq_rpc_port, async_port=zmq_pub_port)
    app_context.pop()
    return trex_client, port_objs, trex_ports, type


class TrafficManager():

    @staticmethod
    def monitor_ports_traffic(websocket_obj, message):
        """
        获取网口流量实时数据
        :return:
        """
        data = {}
        message_dict = json.loads(message)
        ports = get_port(message_dict)
        trex_client, port_objs, trex_ports, _ = get_trex_by_port(ports)
        monitor_info.info(f'正在监控网卡:{ports}，'
                          f'ip:{[port_obj.ip for port_obj in port_objs]}, '
                          f'pci:{[port_obj.pci for port_obj in port_objs]}, '
                          f'mac:{[port_obj.mac for port_obj in port_objs]}的流量')

        try:
            trex_client.connect()
        except Exception as e:
            monitor_error.error(e)
            error_log.error(e)
        while not websocket_obj.closed:
            time.sleep(1)
            try:
                stats = trex_client.get_stats(ports=trex_ports)
                data['total'] = stats['total']
                for trex_port in trex_ports:
                    data[trex_port] = stats[trex_port]
                websocket_obj.send(json.dumps(data))
            except Exception as e:
                monitor_error.error(e)
                error_log.error(e)
                break
