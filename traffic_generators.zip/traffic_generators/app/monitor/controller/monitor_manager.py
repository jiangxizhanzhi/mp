import json
import time
from logging import getLogger

import psutil
import yaml
from geventwebsocket import WebSocketError

import config
from common import error_log, info_log
from utils.resp_util import unit_change, exec_cmd_on_path

monitor_error = getLogger('monitor_error')
monitor_info = getLogger('monitor_info')


class SystemResourceManager():

    @staticmethod
    def monitor_system_resource(websocket_obj):
        """
        获取系统cpu,ram,disk占用情况
        :return:
        """
        info_log.info('正在监控系统资源')
        monitor_info.info('正在监控系统资源')
        while not websocket_obj.closed:
            time.sleep(2)
            cpuused = psutil.cpu_percent()
            cpucount = psutil.cpu_count(logical=False)
            mem = psutil.virtual_memory()
            memtotal = unit_change(mem.total)
            memused = mem.percent
            disk = psutil.disk_usage('/')
            disktotal = unit_change(disk.total)
            diskused = disk.percent
            t = time.strftime('%Y-%m-%d %M:%S', time.localtime())
            try:
                websocket_obj.send(json.dumps({'cpu_used': cpuused,
                                               'cpu_count': cpucount,
                                               'memtotal': memtotal,
                                               'memused': memused,
                                               'disktotal': disktotal,
                                               'diskused': diskused,
                                               'time': t}))
            except WebSocketError as e:
                monitor_error.error(f'监控系统资源失败，msg：{e}')
                error_log.error(f'监控系统资源失败，msg：{e}')
                break

    @staticmethod
    def monitor_service_status(websocket_obj):
        """
        获取服务资源
        :return:
        """
        info_log.info('正在监控服务资源')
        monitor_info.info('正在监控服务资源')
        data = {}
        data['mysql'] = {}
        data['redis'] = {}
        data['nginx'] = {}
        data['trex'] = {}
        data['supervisor'] = {}
        data['mongo'] = {}
        try:
            res = exec_cmd_on_path('echo %s | sudo -S netstat -tunpl | grep mysql' % config.PASSWORD)
            port = res.split('\n')[0].split(':')[1].split('0.0.0.0')[0].strip(' ')
            data['mysql']['status'] = 'running'
            data['mysql']['port'] = port
        except Exception as e:
            monitor_error.error(f'mysql服务down，msg：{e}')
            error_log.error(f'mysql服务down，msg：{e}')
            data['mysql']['status'] = 'down'
        try:
            res = exec_cmd_on_path('echo %s | sudo -S netstat -tunpl | grep redis' % config.PASSWORD)
            port = res.split('\n')[0].split(':')[1].split('0.0.0.0')[0].strip(' ')
            data['redis']['status'] = 'running'
            data['redis']['port'] = port
        except Exception as e:
            monitor_error.error(f'redis服务down，msg：{e}')
            error_log.error(f'redis服务down，msg：{e}')
            data['redis']['status'] = 'down'
        try:
            res = exec_cmd_on_path('echo %s | sudo -S supervisorctl status' % config.PASSWORD)
            if 'RUNNING' or 'STOPPED' in res.split('\n')[0]:
                data['supervisor']['status'] = 'running'
            else:
                data['supervisor']['status'] = 'down'
        except Exception as e:
            monitor_error.error(f'supervisor服务down，msg：{e}')
            error_log.error(f'supervisor服务down，msg：{e}')
            data['supervisor']['status'] = 'down'
        try:
            res = exec_cmd_on_path('echo %s | sudo -S netstat -tunpl | grep nginx' % config.PASSWORD)
            port = res.split('\n')[0].split(':')[1].split('0.0.0.0')[0].strip(' ')
            data['nginx']['status'] = 'running'
            data['nginx']['port'] = port
        except Exception as e:
            monitor_error.error(f'nginx服务down，msg：{e}')
            error_log.error(f'nginx服务down，msg：{e}')
            data['nginx']['status'] = 'down'
        try:
            res = exec_cmd_on_path('echo %s | sudo -S netstat -tunpl | grep mongod' % config.PASSWORD)
            port = res.split('\n')[0].split(':')[1].split('0.0.0.0')[0].strip(' ')
            data['mongo']['status'] = 'running'
            data['mongo']['port'] = port
        except Exception as e:
            monitor_error.error(f'mongo服务down，msg：{e}')
            error_log.error(f'mongo服务down，msg：{e}')
            data['mongo']['status'] = 'down'
        try:
            """
            这里用exec_cmd方法，会报错 cmd stdout:b'', cmd stderr:b''
            这里必须用ax 用aux或ef 显示不全 会报错
            """
            res = exec_cmd_on_path('ps -ax | grep ./t-rex-64')
            for i in res.split('\n'):
                if '/bin/bash' in i:
                    # 按.yaml切割是因为可能后面还有其他参数
                    cfg_file = i.split('--cfg')[1].split('.yaml')[0] + '.yaml'
                    file = open(cfg_file.strip(), 'r')
                    content = yaml.load(file)[0]
                    trex_prefix = content.get('prefix')
                    data['trex'][trex_prefix] = {}
                    data['trex'][trex_prefix]['interfaces'] = content.get('interfaces')
                    data['trex'][trex_prefix]['zmq_pub_port'] = content.get('zmq_pub_port')
                    data['trex'][trex_prefix]['zmq_rpc_port'] = content.get('zmq_rpc_port')
        except Exception as e:
            monitor_error.error(f'获取trex服务状态失败，msg：{e}')
            error_log.error(f'获取trex服务状态失败，msg：{e}')
        # data = {'data': data}  # websocket不需要返回和http请求一样的返回格式
        while not websocket_obj.closed:
            try:
                time.sleep(2)
                websocket_obj.send(json.dumps(data))
            except WebSocketError as e:
                monitor_error.error(f'监控服务资源失败，msg：{e}')
                error_log.error(f'监控服务资源失败，msg：{e}')
                break
