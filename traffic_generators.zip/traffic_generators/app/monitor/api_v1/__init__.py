from flask import Blueprint
from flask_restplus import Api
from app.monitor.api_v1.system_monitor import system_monitor
from app.monitor.api_v1.traffic_monitor import traffic_monitor

monitor_blueprint = Blueprint('monitor_blueprint', __name__)
monitor_api = Api(monitor_blueprint, version='v1')

# 添加监控管理中的每个命名空间url, 也就是每个大模块下面的每个小模块分成不同的url
monitor_api.add_namespace(system_monitor)
monitor_api.add_namespace(traffic_monitor)
