from flask import request, send_file
from flask_restplus import Namespace, Resource
from geventwebsocket import WebSocketApplication

from app.monitor.controller.traffic_manager import TrafficManager
from common import info_log
from utils.resp_util import resp_message

traffic_monitor = Namespace('', description='Endpoint to manage port traffic monitor')


class TrafficMonitorApplication(WebSocketApplication):
    """
    网口流量监控
    """

    def on_open(self, *args, **kwargs):
        info_log.info("Traffic Monitor Connection opened")

    def on_message(self, message, *args, **kwargs):
        TrafficManager.monitor_ports_traffic(self.ws, message)


@traffic_monitor.route('/start_capture')
class StartCaptureApi(Resource):

    def post(self):
        """
        开始抓取流量
        :return:
        """
        params = request.get_json()
        response = TrafficManager.start_capture_traffic(params)
        return resp_message(**response)


@traffic_monitor.route('/stop_capture')
class StopCaptureApi(Resource):

    def post(self):
        """
        停止抓取流量
        :return:
        """
        params = request.get_json()
        response = TrafficManager.stop_capture_traffic(params)
        return resp_message(**response)


@traffic_monitor.route('/tmp_pcap')
class TmpPcapApi(Resource):

    def get(self):
        """
        获取已抓取pcap包列表
        :return:
        """
        params = request.args.to_dict()
        response = TrafficManager.get_all_tmppcap(params)
        return resp_message(**response)

    def delete(self):
        """
        删除已经抓取的pcap包
        :return:
        """
        params = request.get_json()
        response = TrafficManager.delete_tmppcap(params)
        return resp_message(**response)


@traffic_monitor.route('/tmppcap/download/<string:uuid>')
class DownloadTmpPcapApi(Resource):

    def get(self, uuid):
        """
        下载抓取的流量包
        :return:
        """
        file_path = TrafficManager.download_tmppcap(uuid)
        return send_file(file_path, as_attachment=True)

