from flask_restplus import Namespace
from geventwebsocket import WebSocketApplication

from app.monitor.controller.monitor_manager import SystemResourceManager
from common import info_log

system_monitor = Namespace('', description='Endpoint to manage system monitor')


class SystemMonitorApplication(WebSocketApplication):
	"""
	系统资源监控
	"""

	def on_open(self, *args, **kwargs):
		info_log.info("System Monitor Connection opened")

	def on_message(self, message, *args, **kwargs):
		SystemResourceManager.monitor_system_resource(self.ws)


class ServiceMonitorApplication(WebSocketApplication):
	"""
	服务资源监控
	"""

	def on_open(self, *args, **kwargs):
		info_log.info("Service Monitor Connection opened")

	def on_message(self, message, *args, **kwargs):
		SystemResourceManager.monitor_service_status(self.ws)
