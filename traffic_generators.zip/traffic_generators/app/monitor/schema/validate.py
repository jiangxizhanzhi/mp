import os

from marshmallow import fields, pre_load, validate

from app import TmpPcap
from config import TMP_PATH
from extension import ma
from utils.util import generate_uuid


class TmpPcapSchema(ma.ModelSchema):
    capture_id = fields.Int(required=True)
    filter = fields.Str(validate=validate.Length(0, 100, error='过滤条件在0-100个字符之间'))
    start_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    end_time = fields.Function(lambda obj: obj.end_time.strftime('%Y-%m-%d %H:%M:%S'))

    @pre_load
    def load_port(self, params):
        if not params.get('rx_port'):
            params.pop('rx_port', None)
        if not params.get('tx_port'):
            params.pop('tx_port', None)
        return params

    @pre_load
    def load_pcap_path(self, params):
        if not os.path.exists(TMP_PATH):
            os.makedirs(TMP_PATH, exist_ok=True)
        params['pcap_path'] = os.path.join(TMP_PATH, params.get('name'))
        return params

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_tmp'
        return params

    class Meta:
        model = TmpPcap