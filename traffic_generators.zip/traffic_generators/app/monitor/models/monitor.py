from datetime import datetime

from common import DbManager
from extension import db


class SystemResources(db.Model, DbManager):
    """系统资源表    表名system_resources"""

    __tablename__ = "system_resources"
    uuid = db.Column(db.String(64), primary_key=True)  # 系统资源uuid
    cpus = db.Column(db.Integer)  # cpu个数
    cpus_used_percent = db.Column(db.Float)  # cpu利用率
    memory = db.Column(db.Integer)  # 内存大小  单位为G
    memory_used_percent = db.Column(db.Float)  # 内存占用率
    disk = db.Column(db.Integer)  # 磁盘大小  单位为G
    disk_used = db.Column(db.Integer)  # 磁盘已用空间  单位为G
    disk_free = db.Column(db.Integer)  # 磁盘空闲空间  单位为G
    disk_used_percent = db.Column(db.Float)  # 磁盘占用率
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间


class TmpPcap(db.Model, DbManager):
    """抓取流量包表    表名tmp_pcap"""

    __tablename__ = "tmp_pcap"
    uuid = db.Column(db.String(64), primary_key=True)  # pcap包uuid
    capture_id = db.Column(db.Integer)  # capture流的id
    name = db.Column(db.String(100))  # pcap包名
    rx_port = db.Column(db.Integer)  # 接收端口
    tx_port = db.Column(db.Integer)  # 发送端口
    filter = db.Column(db.String(100), default='')  # BFP过滤条件
    limit = db.Column(db.Integer, default=1000)  # 抓取的pcap包的行数
    status = db.Column(db.Integer)  # 抓取状态   1：正在抓取  2：抓取结束
    start_time = db.Column(db.DateTime, default=datetime.now)  # 开始时间
    end_time = db.Column(db.DateTime)  # 结束时间
    pcap_path = db.Column(db.String(100))  # 抓取的pcap包保存的路径
    task_uuid = db.Column(db.String(64))  # 对应任务的uuid
