from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from common import Tag
from utils.exception_tools import PcapNotFound
from ..models.resources import PcapManager, FileResources


class PcapHandler(PcapManager):

    @classmethod
    def get_obj_by_uuid(cls, uuid):
        try:
            obj = cls.query.filter(cls.uuid == uuid).one()
        except (NoResultFound, MultipleResultsFound) as e:
            raise PcapNotFound(uuid, str(e))
        return obj

    @classmethod
    def batch_pcap_by_names(cls, names):
        qs = cls.query.filter(cls.name.in_(names)).all()
        return qs


class TagDbManager(Tag):

    @classmethod
    def get_all_tags(cls, tag_name, page=None, per_page=None):
        filters = []
        if tag_name:
            filters.append(cls.name.contains(tag_name))
        if page and per_page:
            tags = Tag.query.filter(*filters).paginate(page, per_page, False)
        else:
            tags = Tag.query.filter(*filters).all()
        return tags

    @classmethod
    def get_same_name_tag(cls, name):
        tag = Tag.query.filter(Tag.name == name).first()
        return tag

    @classmethod
    def get_tag_by_id(cls, id):
        tag = Tag.query.filter(Tag.id == id).first()
        return tag

    @classmethod
    def get_tags_by_ids(cls, ids):
        tags = Tag.query.filter(Tag.id.in_(ids)).all()
        return tags


class FileDbManager(FileResources):

    @classmethod
    def get_all_scripts(cls):
        scripts = cls.query.all()
        return scripts

    @classmethod
    def get_many_by_uuids(cls, uuids):
        scripts = cls.query.filter(cls.uuid.in_(uuids)).all()
        return scripts

    @classmethod
    def get_script_by_uuid(cls, uuid):
        script = cls.query.filter(cls.uuid == uuid).first()
        return script

    @classmethod
    def get_same_name_script(cls, name):
        script = cls.query.filter(cls.name == name).all()
        return script

    @classmethod
    def filter_scripts(cls, name, category_id, type, tag_id, page, per_page):
        filters = []
        if name:
            filters.append(cls.name.contains(name))
        if category_id:
            filters.append(cls.category_id == category_id)
        if tag_id:
            filters.append(cls.tag_id == tag_id)
        if type:
            filters.append(cls.type == type)
        scripts = cls.query.filter(*filters).paginate(page, per_page, False)
        return scripts
