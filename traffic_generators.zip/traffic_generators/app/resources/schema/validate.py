import os

from marshmallow import ValidationError, fields, validate, pre_load

from app import FileResources
from common import Tag
from common.constant import ScriptMapping
from config import PCAP_PATH
from extension import ma
from utils.util import generate_uuid


class ImportPcapSchema(ma.ModelSchema):
    file = fields.Method(required=True, deserialize='load_file', error_messages={"required": "请上传pcap文件"})

    @staticmethod
    def load_file(data):
        filename = data.filename
        suffix = filename.split('.')[-1]
        if suffix != "pcap":
            raise ValidationError("文件必须为pcap格式")
        # file_path = os.path.join(PCAP_PATH, filename)
        # if not os.path.exists(PCAP_PATH):
        #     os.makedirs(PCAP_PATH)
        # if os.path.exists(file_path):
        #     raise ValidationError("pcap文件已存在")
        return data


class EditPcapSchema(ma.ModelSchema):
    description = fields.Str(required=False, validate=validate.Length(min=0, max=256, error='pcap文件的描述信息在0-256个字符之间'))
    tag_id = fields.Int(required=False)
    file_name = fields.Method(required=True, deserialize='load_file_name', error_messages={"required": "缺少file_name字段"})
    category_id = fields.Int()
    type = fields.Method(required=True, deserialize='load_type', error_messages={"required": "缺少type字段"})

    @staticmethod
    def load_file_name(data):
        if not data:
            raise ValidationError("file_name不能为空")
        file_path = os.path.join(PCAP_PATH, data)
        if not os.path.exists(file_path):
            raise ValidationError("pcap文件在服务器上不存在")
        return data

    @staticmethod
    def load_type(data):
        if not data:
            raise ValidationError("必须选择type")
        if data not in ["strike", "normal"]:
            raise ValidationError("type错误")
        return data


class TagSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(1, 50, error="Tag的名称在1-50个字符之间")])
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = Tag
        fields = ('id', 'name', 'create_time', 'update_time')


class ResourceFileSchema(ma.ModelSchema):
    name = fields.Str(required=True, validate=[validate.Length(1, 50, error='资源文件名称在1-50个字符之间')])
    description = fields.Str(validate=validate.Length(0, 256, error='资源文件描述在0-256个字符之间'))
    type = fields.Int(required=True, validate=validate.OneOf([1, 2], error='资源文件类型错误'))
    run_cmd = fields.Str(validate=validate.Length(0, 1024, error='攻击脚本运行命令在0-1024个字符之间'))
    get_result_cmd = fields.Str(validate=validate.Length(0, 1024, error='获取运行攻击脚本返回结果命令在0-1024个字符之间'))
    create_time = fields.Function(lambda obj: obj.create_time.strftime('%Y-%m-%d %H:%M:%S'))
    update_time = fields.Function(lambda obj: obj.update_time.strftime('%Y-%m-%d %H:%M:%S'))

    class Meta:
        model = FileResources

    @pre_load
    def create_uuid(self, params):
        _uuid = generate_uuid()
        params['uuid'] = _uuid + '_scripts'
        return params

    @pre_load
    def load_image_type(self, params):
        if params.get('type') == ScriptMapping.attack_scripts.value:
            if int(params.get('image_type')) not in [1, 2]:
                raise ValidationError("镜像类型错误")
        return params


class EditPcapDataSchema(ma.ModelSchema):
    uuid = fields.Str(required=True)
    data = fields.Method(required=True, error_messages={"required": "缺少编辑数据信息"})

    @pre_load
    def check(self, req_data):
        from app.resources.controller.resource_manager import PcapManagement

        data = req_data.get("data")
        if not data:
            raise ValidationError("编辑数据不能为空")
        if not isinstance(data, dict):
            raise ValidationError("编辑数格式为字典")
        payload_file_list = []
        for item in data.values():
            file_resource_uuid = item.get("payload_file")
            if file_resource_uuid not in payload_file_list:
                payload_file_list.append(file_resource_uuid)
        pcap_management = PcapManagement()
        has_file = pcap_management.has_payload_file(payload_file_list)
        if not has_file:
            raise ValidationError("恶意文件不存在")
        check_edit_info_result, check_edit_info_msg = pcap_management.check_edit_info(req_data)
        if not check_edit_info_result:
            raise ValidationError(check_edit_info_msg)
        return req_data
