from datetime import datetime

from common.db_manage import DbManager
from extension import db


class FileResources(db.Model, DbManager):
    """文件资源表    表名file_resources"""

    __tablename__ = "file_resources"
    uuid = db.Column(db.String(64), primary_key=True)  # 文件uuid
    name = db.Column(db.String(100))  # 名称
    description = db.Column(db.String(1024), default='')  # 文件描述信息
    is_default = db.Column(db.Integer, default=0)  # 是否是默认镜像
    file_path = db.Column(db.String(256))  # 文件路径
    type = db.Column(db.Integer)  # 文件类型    1：攻击脚本，2：恶意文件
    image_type = db.Column(db.Integer, default=1)  # 镜像类型    1：docker，2：kvm
    run_image_script_path = db.Column(db.String(256))  # 运行攻击脚本的脚本保存路径
    run_cmd = db.Column(db.String(1024), default='')  # 攻击脚本运行命令
    get_result_cmd = db.Column(db.String(1024), default='')  # 获取运行攻击脚本返回结果命令
    tag_id = db.Column(db.Integer)  # 标签id
    category_id = db.Column(db.Integer)  # 文件类别id
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class PcapManager(db.Model, DbManager):
    """流量包管理表    表名pcap_manager"""

    __tablename__ = "pcap_manager"
    uuid = db.Column(db.String(64), primary_key=True)  # 流量包uuid
    name = db.Column(db.String(256))  # 流量包名称
    file_path = db.Column(db.String(256))  # 流量包保存路径
    tag_id = db.Column(db.Integer)  # tag的id
    description = db.Column(db.String(1024), default='')  # 描述信息
    type = db.Column(db.String(10))  # 流量包类型 值为： strike(武器库)或normal(普通流量)
    category_id = db.Column(db.Integer)  # category的id
    built_in = db.Column(db.Boolean, default=False)  # 是否为内置资源
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


