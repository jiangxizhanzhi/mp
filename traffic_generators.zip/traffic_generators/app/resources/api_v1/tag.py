from flask import request
from flask_restplus import Namespace, Resource

from app.resources.controller.resource_manager import TagManager
from utils.resp_util import resp_message

ns_tag = Namespace('', description="Endpoint to manage tag")


@ns_tag.route('/tasks/tags')
class TagApi(Resource):

	def get(self):
		"""
		获取tag信息的列表
		:return:
		"""
		params = request.args.to_dict()
		response = TagManager.get_tags(params)
		return resp_message(**response)

	def post(self):
		"""
		新增tag信息
		:return:
		"""
		params = request.get_json()
		response = TagManager.add_tag(params)
		return resp_message(**response)

	def patch(self):
		"""
		修改tag信息
		:return:
		"""
		params = request.get_json()
		response = TagManager.update_tag(params)
		return resp_message(**response)

	def delete(self):
		"""
		删除tag信息
		:return:
		"""
		params = request.get_json()
		response = TagManager.delete_tags(params)
		return resp_message(**response)

@ns_tag.route('/tasks/tags/<int:id>')
class SingleTagApi(Resource):

	def get(self, id):
		"""
		获取单个tag信息
		:return:
		"""
		response = TagManager.get_tag(id)
		return resp_message(**response)