from flask import request, send_file
from flask_restplus import Namespace, Resource

from app.resources.controller.resource_manager import FileManager
from utils.resp_util import resp_message

ns_file = Namespace('', description='Endpoint to manage malicious files and attack scripts')


@ns_file.route('/scripts')
class ResourceFileApi(Resource):

	def get(self):
		"""
		查询资源文件列表
		:return:
		"""
		params = request.form.to_dict()
		response = FileManager.get_resource_files(params)
		return resp_message(**response)

	def post(self):
		"""
		新增资源文件
		:return:
		"""
		params = request.form.to_dict()
		file = request.files.to_dict()
		response = FileManager.add_resource_file(params, file)
		return resp_message(**response)

	def delete(self):
		"""
		删除资源文件
		:return:
		"""
		params = request.get_json()
		response = FileManager.delete_resource_file(params)
		return resp_message(**response)


@ns_file.route('/scripts/<string:uuid>')
class SingleFileApi(Resource):

	def get(self, uuid):
		"""
		获取单个资源文件信息
		:return:
		"""
		response = FileManager.get_resource_file(uuid)
		return resp_message(**response)

	def patch(self, uuid):
		"""
		修改资源文件
		:return:
		"""
		params = request.form.to_dict()
		file = request.files.to_dict()
		response = FileManager.update_resource_file(uuid, params, file)
		return resp_message(**response)


@ns_file.route('/scripts/upload')
class UploadFileApi(Resource):

	def post(self):
		"""
		nginx文件上传
		:return:
		"""
		params = request.form.to_dict()
		response = FileManager.upload_file(params)
		return resp_message(**response)


@ns_file.route('/scripts/download/<string:uuid>')
class DownloadFileApi(Resource):

	def get(self, uuid):
		"""
		下载文件资源
		:return:
		"""
		run_image_script = request.args.get('is_run_image_script')
		file_path = FileManager.download_file(uuid, run_image_script)
		if isinstance(file_path, str):
			return send_file(file_path, as_attachment=True)
		else:
			return file_path
