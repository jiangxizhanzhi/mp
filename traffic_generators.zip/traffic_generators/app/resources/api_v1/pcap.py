import json
import os
from flask_restplus import Namespace, Resource
from flask import request, send_file

from common import error_log, info_log
from common.constant import PcapType
from config import PCAP_PATH, RUN_IMAGE_SCRIPTS_PATH
from utils.resp_util import resp_message
from utils.exception_tools import PcapNotFound
from utils import status_code as sc
from ..controller.resource_manager import PcapManagement
from ..schema.validate import ImportPcapSchema, EditPcapSchema, EditPcapDataSchema

ns_pcap = Namespace('pcap', description="Endpoint to manage pcap file")
pcap_management = PcapManagement()


@ns_pcap.route("/list")
class PcapList(Resource):

    def get(self):
        # flow配置文件列表
        per_page = int(request.args.get('per_page')) if request.args.get('per_page') and str(
            request.args.get('per_page')).isdigit() else 10
        page = int(request.args.get('page')) if request.args.get('page') and str(
            request.args.get('page')).isdigit() else 1
        req_args = request.args
        rows, total = pcap_management.pcap_list(page, per_page, req_args)
        data = {
            "rows": rows,
            "total": total
        }
        info_log.info("成功获取pcap管理列表")
        return resp_message(data=data)


@ns_pcap.route("")
class PcapOperation(Resource):

    def post(self):
        req_data = request.get_json()
        errors = EditPcapSchema().validate(req_data)
        if errors:
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        name = req_data.pop("file_name")
        only_name = pcap_management.verify_pcap_name(name)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        req_data["name"] = name
        req_data["file_path"] = name
        obj = pcap_management.create_pcap_info(req_data)
        data = {
            "uuid": obj.uuid
        }
        info_log.info(f"create pcap manage success：{name}")
        return resp_message(data=data)

    def delete(self):
        req_data = request.get_json()
        uuids = req_data.get("uuids", [])
        error_uuid, deleted_uuid = pcap_management.batch_delete(uuids)
        status_code = sc.Success
        if error_uuid:
            status_code = sc.FailDelete
        data = {
            "error_uuid": error_uuid,
            "deleted_uuid": deleted_uuid
        }
        info_log.info(f"delete pcap manage success")
        return resp_message(data, status_code)


@ns_pcap.route("/<string:uuid>")
class PcapDetail(Resource):

    def get(self, uuid):
        try:
            detail = pcap_management.get_pcap(uuid)
        except PcapNotFound as e:
            return resp_message(code=sc.NotFound)
        name = detail.get("name")
        info_log.info(f"成功获取pcap管理信息：{name}")
        return resp_message(data=detail)

    def patch(self, uuid):
        req_data = request.get_json()
        errors = EditPcapSchema().validate(req_data)
        if errors:
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        try:
            pcap_info = pcap_management.get_pcap(uuid)
        except PcapNotFound as e:
            return resp_message(code=sc.NotFound)
        filename = pcap_info["name"]
        name = req_data.pop("file_name")
        only_name = pcap_management.verify_pcap_name(name, uuid)
        if only_name is False:
            return resp_message(code=sc.DuplicateName)
        if filename != name:
            file_path = pcap_management.pcap_path(filename)
            pcap_management.del_pcap_from_server(file_path)
            req_data["name"] = name
            req_data["file_path"] = name
        pcap_management.update_pcap_info(uuid, req_data)
        info_log.info(f"成功修改pcap管理信息：{name}")
        return resp_message()


@ns_pcap.route("/download/<string:uuid>")
class PcapDownload(Resource):

    def get(self, uuid):
        try:
            pcap_info = pcap_management.get_pcap(uuid)
        except PcapNotFound as e:
            return resp_message(code=sc.NotFound)
        filename = pcap_info["name"]
        file_path = pcap_management.pcap_path(filename)
        info_log.info(f"成功下载pcap文件：{filename}")
        return send_file(file_path, as_attachment=True)


@ns_pcap.route("/import")
class PcapImport(Resource):

    def post(self):
        req_data = request.files.to_dict()
        errors = ImportPcapSchema().validate(req_data)
        if errors:
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        pcap_file = req_data.get("file")
        file_name = pcap_management.save_file(pcap_file)
        info_log.info(f"upload pcap success：{file_name}")
        return resp_message({"file_name": file_name})


@ns_pcap.route("/database")
class PcapBase(Resource):

    def get(self):
        uuid = request.args.get("uuid")
        if not uuid:
            return resp_message(code=sc.ParameterError)
        try:
            pcap_info = pcap_management.get_pcap(uuid)
        except PcapNotFound as e:
            return resp_message(code=sc.NotFound)
        name = pcap_info["name"]
        file_path = pcap_management.pcap_path(name)
        data = pcap_management.parse_pcap(file_path)
        info_log.info(f"成功解析cap文件：{name}")
        return resp_message(data)


# @ns_pcap.route("/data_show")
# class PcapShow(Resource):
#
#     def get(self):
#         uuid = request.args.get("uuid")
#         num = request.args.get("num")
#         if not uuid or not num:
#             return resp_message(code=sc.ParameterError)
#         try:
#             pcap_info = pcap_management.get_pcap(uuid)
#         except PcapNotFound as e:
#             return resp_message(code=sc.NotFound)
#         name = pcap_info["name"]
#         file_path = pcap_management.pcap_path(name)
#         data = pcap_management.pcap_data_show(file_path, int(num))
#         return resp_message(data)


@ns_pcap.route("/data_edit")
class PcapEdit(Resource):

    def post(self):
        req_data = request.get_json()
        errors = EditPcapDataSchema().validate(req_data)
        if errors:
            return resp_message(code=sc.ParameterError, msg=errors[list(errors)[0]][0])
        uuid = req_data.get("uuid")
        try:
            pcap_info = pcap_management.get_pcap(uuid)
        except PcapNotFound as e:
            return resp_message(code=sc.NotFound)
        pcap_management.edit_pcap_data(req_data)
        name = pcap_info.get("name")
        info_log.info(f"成功编辑pcap文件载荷：{name}")
        return resp_message()


@ns_pcap.route("/import/built_in_pcap")
class ImportBuiltInPcap(Resource):
    '''
    导入平台内置pcap资源
    '''
    def post(self):
        req_data = request.get_json()
        file_dir = req_data.get("file_dir")
        import_count = 0
        for root, dirs, files in os.walk(file_dir):
            for f in files:
                pcap_path = os.path.join(root, f)
                pcap_name = pcap_path.split("/")[-1]
                only_name = pcap_management.verify_pcap_name(pcap_name)
                if only_name is False:
                    continue
                    # return resp_message(code=sc.DuplicateName, msg=f"pcap:{pcap_name}名称重复")
                create_data = {
                    "name": pcap_name,
                    "file_path": pcap_name,
                    "type": PcapType.normal,
                    "built_in": True,
                }
                pcap_management.create_pcap_info(create_data)
                import_count += 1
        data = {
            "import_count": import_count
        }
        return resp_message(data)


@ns_pcap.route("/create")
class CreatePacketApi(Resource):
    """
    在线生成packet流量包
    """
    def post(self):
        """
        在线生成packet流量包
        :return:
        """
        req_data = request.get_json()
        response = pcap_management.create_packet(req_data)
        return resp_message(**response)


@ns_pcap.route("/upload")
class PcapImport(Resource):

    def post(self):
        req_data = request.files.to_dict()
        info_log.info(f"v2 upload req_data：{req_data}")
        req_param = request.form.to_dict()
        info_log.info(f"v2 upload req_param：{req_param}")
        flow_file = req_data.get("file")

        if not flow_file:
            return resp_message(code=sc.SystemError, msg="please upload flow file")
        file_name = req_param.get("fileName")
        if not file_name:
            return resp_message(code=sc.SystemError, msg="file_name can not be empty")

        is_attack_flow = True
        flow_path = PCAP_PATH
        suffix = file_name.split('.')[-1]
        if suffix == "pcap":
            is_attack_flow = False
        elif suffix == "sh" or suffix == "py":
            flow_path = RUN_IMAGE_SCRIPTS_PATH
        else:
            return resp_message(code=sc.SystemError, msg="not flow file")

        flow_id = req_param.get("flowId")
        if not flow_id:
            return resp_message(code=sc.SystemError, msg="flow_id can not be empty")
        path_name = flow_id + "." + suffix

        protocol_rate = req_param.get("protocolRate")
        if not is_attack_flow and not protocol_rate:
            return resp_message(code=sc.SystemError, msg="protocol_rate can not be empty")

        pcap_info = {
            "uuid": flow_id,
            "name": file_name,
            "file_path": path_name,
            "description": protocol_rate
        }

        only_name = pcap_management.verify_file_path(path_name)
        if only_name is False:
            # 流量已存在，覆盖更新
            info_log.info(f"flow file {flow_id} will be overwrite")
            pcap_management.upload_flow_file(path_name, flow_file, flow_path)
            pcap_management.update_pcap_info(flow_id, pcap_info)
            return resp_message(code=sc.Success)

        pcap_management.upload_flow_file(path_name, flow_file, flow_path)
        info_log.info(f"v2 upload flow success：{file_name}")

        obj = pcap_management.create_pcap_info(pcap_info)
        data = {
            "uuid": obj.uuid,
            "file_name": file_name
        }
        info_log.info(f"v2 upload flow manage success：{file_name}")
        return resp_message(data=data)