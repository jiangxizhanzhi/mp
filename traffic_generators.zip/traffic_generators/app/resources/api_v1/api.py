from flask_restplus import Namespace, Resource
from flask import request
from utils import status_code as sc
from utils.resp_util import resp_message

from ..controller.resource_manager import ApiManager

ns_api = Namespace('', description="Endpoint to manage resources")
api_manager = ApiManager()


@ns_api.route('/batch_resource_info')
class ResourcePath(Resource):

    def post(self):
        req_data = request.get_json()
        search = req_data.get('search')
        resource_type = req_data.get('resource_type')
        if not search or not resource_type:
            return resp_message(code=sc.ParameterError)
        resource_dict = api_manager.batch_resource_info(search, resource_type)
        return resp_message(resource_dict)