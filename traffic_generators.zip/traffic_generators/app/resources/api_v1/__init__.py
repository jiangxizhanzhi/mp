from flask import Blueprint
from flask_restplus import Api

from app.resources.api_v1.resource_file import ns_file
from app.resources.api_v1.pcap import ns_pcap
from app.resources.api_v1.api import ns_api
from app.resources.api_v1.tag import ns_tag

resource_blueprint = Blueprint('resource_blueprint', __name__)
resource_api = Api(resource_blueprint, version='v1')

# 添加资源管理中的每个命名空间url, 也就是每个大模块下面的每个小模块分成不同的url
resource_api.add_namespace(ns_pcap)
resource_api.add_namespace(ns_tag)
resource_api.add_namespace(ns_file)
resource_api.add_namespace(ns_api)

