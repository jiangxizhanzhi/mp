import shutil
from logging import getLogger

from scapy.all import *

import config
from app.resources.models.resources import PcapManager
from app.resources.ops.db_handler import TagDbManager, FileDbManager
from app.resources.schema.validate import TagSchema, ResourceFileSchema
from app.task.ops.db_handler import CustomTaskHandler
from common import error_log, info_log
from common.constant import ScriptMapping, ResourceType
from common.flow_resource import FlowResourceClient
from config import PCAP_PATH, BASE_DIR, RUN_IMAGE_SCRIPTS_PATH
from extension import db
from utils import status_code as sc
from utils.exception_tools import DataException
from utils.pcap_decode import PcapDecode
from utils.resp_util import exec_cmd_on_path, hash_file, get_Random_String
from ..ops.db_handler import PcapHandler

resource_error = getLogger('resource_error')
resource_info = getLogger('resource_info')


class PcapManagement(object):
    def __init__(self):
        self.flow_resource_client = FlowResourceClient()

    def pcap_path(self, filename):
        file_path = os.path.join(PCAP_PATH, filename)
        return file_path

    def flow_path(self, filename, flow_path):
        file_path = os.path.join(flow_path, filename)
        return file_path

    def save_file(self, file_obj):
        filename = file_obj.filename
        suffix = filename.split('.')[-1]
        name_element = filename.split('.')[:-1]
        name_element.append(str(int(time.time())))
        name_element.append(f".{suffix}")
        new_filename = "".join(name_element)
        file_path = self.pcap_path(new_filename)
        file_obj.save(file_path)
        return new_filename

    def get_pcap(self, uuid):
        detail = PcapHandler.get_obj_by_uuid(uuid).to_dict()
        filename = detail["name"]
        detail["file_path"] = self.pcap_path(filename)
        return detail

    def create_pcap_info(self, data):
        obj = PcapHandler.create_obj(data, "pcap")
        return obj

    def verify_pcap_name(self, name, exclude_uuid=None):
        result = PcapHandler.verify_unique_name(name, exclude_uuid)
        return result

    def verify_file_path(self, path_name, exclude_uuid=None):
        result = PcapHandler.verify_unique_file_path(path_name, exclude_uuid)
        return result

    def del_pcap_from_server(self, file_path):
        if os.path.exists(file_path):
            os.remove(file_path)

    def batch_delete(self, uuids):
        error_uuid, deleted_uuid = [], []
        for uuid in uuids:
            obj = PcapHandler.get_one_by_uuid(uuid)
            if not obj:
                error_uuid.append(uuid)
                continue
            if obj.built_in:
                error_uuid.append(uuid)
                continue
            filename = obj.name
            file_path = self.pcap_path(filename)
            # 删除数据库
            PcapHandler.delete_one(obj)
            # 删除服务器上pcap文件
            self.del_pcap_from_server(file_path)
            deleted_uuid.append(uuid)
        return error_uuid, deleted_uuid

    def pcap_list(self, page, per_page, req_args):
        name = req_args.get("name")
        type = req_args.get("type")
        tag_id = req_args.get("tag_id")
        category_id = req_args.get("category_id")
        filters = []
        if name:
            filters.append(PcapManager.name.contains(name))
        if type:
            filters.append(PcapManager.type == type)
        if tag_id:
            filters.append(PcapManager.tag_id == tag_id)
        if category_id:
            filters.append(PcapManager.category_id == category_id)
        paginate_data = PcapHandler.paginate(page, per_page, filters)
        data = [i.to_dict() for i in paginate_data["items"]]
        total = paginate_data.get("total")
        return data, total

    def upload_file(self, path_name, file_obj):
        file_path = self.pcap_path(path_name)
        file_obj.save(file_path)
        return path_name

    def upload_flow_file(self, path_name, file_obj, flow_path):
        file_path = self.flow_path(path_name, flow_path)
        file_obj.save(file_path)
        return path_name

    def update_pcap_info(self, uuid, data):
        obj = PcapHandler.get_obj_by_uuid(uuid)
        obj.update(data)

    def parse_pcap(self, file_path):
        PD = PcapDecode()
        pcap_data = rdpcap(file_path)
        data_result_list = []
        num = 1
        for p in pcap_data:
            data_result = PcapDecode.ether_decode(PD, p)
            data_result["num"] = num
            data_result_list.append(data_result)
            num += 1
        return data_result_list

    # def pcap_data_show(self, file_path, num):
    #     # TODO： 错的
    #     data = rdpcap(file_path)[num - 1]
    #     stdout = data.show()
    #     return stdout

    def has_payload_file(self, payload_file_list):
        result = True
        file_obj_list = FileDbManager.get_many_by_uuids(payload_file_list)
        if len(payload_file_list) != len(file_obj_list):
            result = False
        return result

    def check_edit_info(self, edit_info):
        result, msg = True, ""
        pcap_uuid = edit_info.get("uuid")
        pcap_obj = PcapHandler.get_one_by_uuid(pcap_uuid)
        filename = pcap_obj.name
        pcap_obj_path = self.pcap_path(filename)
        pcap_test = rdpcap(pcap_obj_path)
        data = edit_info.get("data")
        i = 1
        for p in pcap_test:
            str_i = str(i)
            if str_i in data:
                if not p.haslayer(Raw):
                    result, msg = False, f"序号为{i}的数据没有可更改的载荷"
                    break
            i += 1
        return result, msg

    def edit_pcap_data(self, edit_info):
        pcap_uuid = edit_info.get("uuid")
        pcap_obj = PcapHandler.get_one_by_uuid(pcap_uuid)
        filename = pcap_obj.name
        timestamp = int(time.time())
        new_pcap_name = f"{timestamp}_{filename}"
        new_pcap_path = self.pcap_path(new_pcap_name)
        pcap_obj_path = self.pcap_path(filename)
        data = edit_info.get("data")
        with PcapWriter(new_pcap_path) as Writer:
            pcap_test = rdpcap(pcap_obj_path)
            i = 1
            for p in pcap_test:
                str_i = str(i)
                if str_i in data:
                    update_info = data.get(str_i)
                    file_uuid = update_info.get("payload_file")
                    file_obj = FileDbManager.get_one_by_uuid(file_uuid)
                    file_path = file_obj.file_path
                    f = open(file_path, mode="r")
                    content = f.read()
                    if p.haslayer(Raw):
                        p[Raw].load = content
                    f.close()
                Writer.write(pkt=p)
                i += 1
        # 创建新的pcap对象
        create_info = {
            "name": new_pcap_name,
            "file_path": new_pcap_name,
            "type": pcap_obj.type,
            "category_id": pcap_obj.category_id
        }
        self.create_pcap_info(create_info)
        return new_pcap_name

    def create_packet(self, req_data):
        """
        在线创建packet包，只支持部分协议(其中每个协议里面的属性，目前处于开放式填写，只要添加上支持的就能够识别)
        req_data示例：
        {"packet": [
            {
              "Ethernet": {
                "dst": "00:00:00:01:00:00",
                "src": "00:00:00:02:00:00"
              }
            },
            {
              "IP": {
                "src": "16.0.0.1",
                "dst": "48.0.0.1"
              }
            },
            {
              "TCP": {
                "sport": "1025",
                "dport": "1025"
              }
            }
          ]
        }
        :param req_data: 创建packet包的请求参数
        :return:
        """
        # 首先在数据库中生成记录，拿到记录的uuid来作为生成的pcap包的名
        name = req_data.get('name')
        description = req_data.get('description')
        protocol_list = req_data.get('packet')
        pcap_params = {
            'name': name,
            'description': description,
            'type': 'normal'
        }
        obj = self.create_pcap_info(pcap_params)
        pkt = self._make_packet(protocol_list)
        # 构建的packet包存储到文件中
        path = os.path.join(BASE_DIR, 'media/pcap/{}.pcap'.format(name))
        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))
        obj.update({'file_path': path})
        wrpcap(path, eval(pkt))
        return {'code': sc.Success}

    def _make_packet(self, packet):
        """
        根据传递的参数构建packet包
        :param packet:
        :return: base_pkt
        """
        layers_list = []
        for layer in packet:
            d = ''
            for key1, value1 in layer.items():
                if key1 == 'Ethernet' and not value1:
                    a = 'Ether()'
                    # a = Ether()
                else:
                    # 拿到每层协议名称a
                    a = f'{key1}('
                    # 第一层协议名称Ethernet换成Ether，要不然找不到包执行报错
                    if 'Ethernet' in a:
                        a = f'Ether('
                    num, b, c = 0, '', ''
                    for key2, value2 in value1.items():
                        # 拿到每层第二个参数及值
                        if num == 0:
                            if 'Text' in key2 and not value2:
                                if len(value2.encode(encoding='utf8')) < 0 or len(
                                        value2.encode(encoding='utf8')) > 65535:
                                    return {'code': sc.AddPayLoadFailed, 'msg': '载荷字节长度在0-65535'}
                                b = f'load={value2})'
                            elif 'File' in key2 and not value2:
                                from manage import app
                                with app.app_context():
                                    file_uuid = value2
                                    file = FileDbManager.get_script_by_uuid(file_uuid)
                                    with open(file.file_path, 'rb') as f:
                                        content = f.read()
                                        if len(content) < 0 or len(content) > 65536:
                                            return {'code': sc.AddPayLoadFailed, 'msg': '载荷字节长度在0-65535'}
                                b = f'load={content})'
                            elif 'Random ascii' in key2 and not value2:
                                length = int(value2)
                                salt = get_Random_String(length)
                                b = f'load="{salt}")'
                            elif 'sport' in key2 or 'dport' in key2:
                                b = f'{key2}={int(value2)}, '
                            else:
                                b = f'{key2}="{value2}", '
                        # 拿到每层第一个参数及值
                        else:
                            if 'sport' in key2 or 'dport' in key2:
                                c = f'{key2}={int(value2)})'
                            else:
                                c = f'{key2}="{value2}")'
                        # 拼接组包公式每层括号内参数及值
                        d = b + c
                        num += 1
                # 拼接组包公式
                a = a + d
                layers_list.append(a)
            a = a + ' / ' + a
        base_pkt = ' / '.join(layers_list)
        return base_pkt

    def not_found_pcap_names(self, names):
        objs_name = PcapHandler.batch_obj_name_by_name(names)
        name_list = [item[0] for item in objs_name]
        not_found_name = set(names) - set(name_list)
        return not_found_name

    def not_found_pcap_names_form_flow_resource(self, names):
        '''
        校验pcap包是否在资源服务器里
        :param names:
        :return:
        '''
        resource_type = ResourceType.pcap
        search = names
        batch_resource_info = self.flow_resource_client.batch_resource_info(search, resource_type)
        name_list = list(batch_resource_info)
        not_found_name = set(names) - set(name_list)
        return not_found_name


class TagManager:

    @staticmethod
    def add_tag(params):
        """
        新增tag信息
        :param params:
        :return:
        """
        data = {}
        name = params.get('name')
        if not name:
            return {'code': sc.ParameterError}
        tags = TagDbManager.get_all_tags()
        if name in [tag.name for tag in tags]:
            return {'code': sc.DuplicateName}
        response, error = TagSchema().load(params, session=db.session)
        if error:
            error_log.error(error)
            resource_error.error(error)
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        try:
            TagDbManager.save(response)
        except DataException as e:
            TagDbManager.rollback()
            error_log.error(f'新增tag失败，msg：{e}')
            resource_error.error(f'新增tag失败，msg：{e}')
            return {'code': sc.AddFailed, 'msg': e}
        info_log.info(f'新增tag：{name}成功')
        resource_info.info(f'新增tag：{name}成功')
        data['tag_id'] = response.id
        return {'code': sc.Success, 'data': data}

    @staticmethod
    def get_tags(params):
        """
        获取tag列表
        :param params:
        :return:
        """
        data = {}
        page = int(params.get('page')) if str(params.get('page')).isdigit() else 1
        per_page = int(params.get('per_page')) if str(params.get('per_page')).isdigit() else 10
        tag_name = params.get('name')
        tags = TagDbManager.get_all_tags(tag_name, page=page, per_page=per_page)
        response, error = TagSchema(only=('id', 'name')).dump(tags.items, many=True)
        data['total'] = len(response)
        data['rows'] = response
        if error:
            error_log.error(f'获取tag列表失败，msg：{error}')
            resource_error.error(f'获取tag列表失败，msg：{error}')
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        return {'code': sc.Success, 'data': data}

    @staticmethod
    def update_tag(params):
        """
        修改tag信息
        :param params:
        :return:
        """
        id = params.get('id')
        name = params.get('name')
        if not id or not name:
            return {'code': sc.ParameterError}
        tag = TagDbManager.get_tag_by_id(id)
        if not tag:
            return {'code': sc.NotFound}
        data = TagDbManager.get_same_name_tag(name)
        if data:
            return {'code': sc.DuplicateName}
        response, error = TagSchema().load(params, instance=tag)
        if error:
            error_log.error(error)
            resource_error.error(error)
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        try:
            TagDbManager.save(response)
        except DataException as e:
            TagDbManager.rollback()
            error_log.error(f'修改tag：{name}失败，msg：{e}')
            resource_error.error(f'修改tag：{name}失败，msg：{e}')
            return {'code': sc.AddFailed, 'msg': e}
        info_log.info(f'修改tag：{name}成功')
        resource_info.info(f'修改tag：{name}成功')
        return {'code': sc.Success}

    @staticmethod
    def delete_tags(params):
        """
        删除tag信息
        :param params:
        :return:
        """
        ids = params.get('ids')
        if not ids:
            return {'code': sc.ParameterError}
        custom_tasks = CustomTaskHandler.get_all()
        pcaps = PcapHandler.get_all()
        for id in ids:
            if id in [task.tag_id for task in custom_tasks]:
                return {'code': sc.TagIsBeUsed}
            if id in [pcap.tag_id for pcap in pcaps]:
                return {'code': sc.TagIsBeUsed}
        tags = TagDbManager.get_tags_by_ids(ids)
        for tag in tags:
            TagDbManager.delete_one(tag)
            info_log.info(f'删除tag：{tag.name}成功')
            resource_info.info(f'删除tag：{tag.name}成功')
        return {'code': sc.Success}

    @staticmethod
    def get_tag(id):
        """
        获取单个tag信息
        :param id: tag的id
        :return:
        """
        tag = TagDbManager.get_tag_by_id(id)
        if not tag:
            return {'code': sc.NotFound}
        response, error = TagSchema(only=('id', 'name')).dump(tag)
        if error:
            error_log.error(f'获取单个tag信息失败，msg：{error}')
            resource_error.error(f'获取单个tag信息失败，msg：{error}')
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        return {'code': sc.Success, 'data': response}


class FileManager:
    def __init__(self):
        self.flow_resource_client = FlowResourceClient()

    @staticmethod
    def get_resource_files(params):
        """
        查询资源文件列表
        :param params:
        :return:
        """
        data = {}
        name = params.get('name') if params.get('name') else ''
        category_id = int(params.get('category_id')) if params.get('category_id') else None
        type = int(params.get('type')) if params.get('type') else None
        tag_id = int(params.get('tag_id')) if params.get('tag_id') else None
        page = int(params.get('page')) if str(params.get('page')).isdigit() else 1
        per_page = int(params.get('per_page')) if str(params.get('per_page')).isdigit() else 10
        scripts = FileDbManager.filter_scripts(name, category_id, type, tag_id, page, per_page)
        response, error = ResourceFileSchema().dump(scripts.items, many=True)
        data['total'] = len(response)
        data['rows'] = response
        if error:
            error_log.error(f'获取文件资源列表失败，msg：{error}')
            resource_error.error(f'获取文件资源列表失败，msg：{error}')
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        return {'code': sc.Success, 'data': data}

    @staticmethod
    def add_resource_file(params, file):
        """
        新增资源文件
        :param params:
        :return:
        """
        data = {}
        scripts = FileDbManager.get_all_scripts()
        run_image_script_path = ''
        if params.get('name') in [script.name for script in scripts]:
            return {'code': sc.DuplicateName}
        if int(params.get('type')) not in [1, 2]:
            return {'code': sc.ParameterError}
        if int(params.get('type')) == ScriptMapping.attack_scripts.value:
            if not params.get('run_cmd') or not params.get('is_default'):
                return {'code': sc.MissingRequiredParameter}
            if not file:
                return {'code': sc.MissingRequiredParameter}
            # 上传运行镜像的脚本
            run_image_script = file.get('run_image_script')
            run_image_script_path = os.path.join(RUN_IMAGE_SCRIPTS_PATH, run_image_script.filename)
            if not os.path.exists(RUN_IMAGE_SCRIPTS_PATH):
                os.makedirs(RUN_IMAGE_SCRIPTS_PATH)
            run_image_script.save(run_image_script_path)
        if int(params.get('type')) == ScriptMapping.malicious_files.value:
            if params.get('run_cmd') or params.get('is_default') or file.get('run_image_script'):
                return {'code': sc.ParameterError}
        response, error = ResourceFileSchema().load(params, session=db.session)
        data['can_upload'] = False
        data['uuid'] = response.uuid
        if error:
            error_log.error(f'add script failed, msg：{error}')
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        try:
            response.run_image_script_path = run_image_script_path
            FileDbManager.save(response)
        except DataException as e:
            FileDbManager.rollback()
            error_log.error(f'add script failed,msg：{e}')
            return {'code': sc.AddFailed, 'msg': e}
        info_log.info(f"add script record {params.get('name')} success")
        return {'code': sc.Success, 'data': data}

    @staticmethod
    def delete_resource_file(params):
        """
        删除资源文件
        :param params:
        :return:
        """
        uuids = params.get('uuids')
        if len(uuids) < 1:
            return {'code': sc.ParameterError}
        scripts = FileDbManager.get_many_by_uuids(params.get('uuids'))
        for script in scripts:
            if script.type == ScriptMapping.malicious_files.value:
                try:
                    run_image_script_path = os.path.join(RUN_IMAGE_SCRIPTS_PATH, script.name)
                    FileManager.del_script_from_server(run_image_script_path)
                    FileDbManager.delete_one(script)
                    info_log.info(f'delete script {script.name} success')
                except Exception as e:
                    FileDbManager.rollback()
                    error_log.error(f'delete script {script.name} failed, msg：{e}')
                    return {'code': sc.FailDelete, 'msg': e}
            else:
                # # 判断镜像文件有没有被使用
                # tasks = StandardTaskHandler.get_all()
                # for task in tasks:
                #     if script.uuid == task.file_resource_uuid:
                #         return {'code': sc.ImageInUse, 'msg': f'攻击脚本正被任务{task.name}使用'}
                try:
                    info_log.info(f'delete script path: {script.file_path}')
                    image_name = script.file_path.split('/')[-1].split('.tar')[0]
                    # 获取镜像id
                    image_id = exec_cmd_on_path(
                        "echo %s | sudo -S docker images | grep %s | awk '{print $3}'" % (config.PASSWORD,
                                                                                          image_name))

                    exec_cmd_on_path("echo %s | sudo -S docker rmi -f %s" % (config.PASSWORD, image_id))
                    info_log.info(f'delete image {image_name} success')
                except Exception as e:
                    error_log.error(f'image {image_name} delete failed, msg：{e}')
                    return {'code': sc.DeleteImageFailed}
                try:
                    run_image_script_path = os.path.join(RUN_IMAGE_SCRIPTS_PATH, script.name)
                    FileManager.del_script_from_server(run_image_script_path)
                    FileDbManager.delete_one(script)
                    info_log.info(f'delete script record {script.name} success')
                except Exception as e:
                    FileDbManager.rollback()
                    error_log.error(f'delete script record {script.name} failed, msg：{e}')
                    return {'code': sc.FailDelete, 'msg': e}
        return {'code': sc.Success}

    @staticmethod
    def update_resource_file(uuid, params, file):
        """
        修改资源文件
        :return:
        :param params:
        """

        """
        镜像文件只在标准任务中使用，攻击脚本的uuid如果在标准任务表中，则镜像正在使用中
        如果是修改恶意文件：
            如果更换了文件，删除原文件，修改记录，返回can_upload=True，上传新的文件
            如果没有修改文件，只修改记录
        如果是修改攻击脚本：
            如果镜像正在使用中，不能修改
            不管是否更换运行镜像的脚本文件，都重新上传新的
            如果更换了镜像文件：
                如果原镜像是默认镜像，现在不是，则修改表中file_path，返回can_upload=True，上传新的镜像
                如果原镜像不是默认镜像，现在是，则修改表中file_path为默认镜像路径，返回can_upload=False，删除原来的镜像，将默认镜像load成镜像
                如果原镜像不是默认镜像，现在也不是，则删除原来的镜像，返回can_upload=True，调用nginx上传新的镜像
        """
        data = {}
        # 镜像文件只在标准任务中使用
        script = FileDbManager.get_script_by_uuid(uuid)
        if not script:
            return {'code': sc.NotFound}
        same_name_script = FileDbManager.get_same_name_script(params.get('name'))
        if len(same_name_script) > 2:
            return {'code': sc.DuplicateName}
        data['uuid'] = uuid
        data['can_upload'] = False
        # 如果是镜像文件
        if int(params.get('type')) == ScriptMapping.attack_scripts.value:
            if not params.get('run_cmd') or not params.get('is_default'):
                return {'code': sc.ParameterError}
            if not file:
                return {'code': sc.ParameterError}
            # in_use_attack_scripts_uuids = StandardTaskHandler.get_in_use_attack_scripts_uuids()
            # if script.uuid in in_use_attack_scripts_uuids:
            #     return {'code': sc.ImageRunning}
            # 删除原来旧的run_image_script，上传新的
            os.remove(script.run_image_script_path)
            run_image_script = file.get('run_image_script')
            run_image_script_path = os.path.join(RUN_IMAGE_SCRIPTS_PATH, run_image_script.filename)
            if not os.path.exists(RUN_IMAGE_SCRIPTS_PATH):
                os.makedirs(RUN_IMAGE_SCRIPTS_PATH)
            run_image_script.save(run_image_script_path)
            # 如果原镜像是默认镜像，现在不是
            if script.is_default and not int(params.get('is_default')):
                data['can_upload'] = True
            # 如果原镜像不是默认镜像，现在也不是
            if not script.is_default and not int(params.get('is_default')):
                try:
                    image_name = script.file_path.split('/')[-1].split('.tar')[0]
                    # 获取镜像id
                    image_id = exec_cmd_on_path(
                        "echo %s | sudo -S docker images | grep %s | awk '{print $3}'" % (config.PASSWORD,
                                                                                          image_name))

                    exec_cmd_on_path("echo %s | sudo -S docker rmi -f %s" % (config.PASSWORD, image_id))
                    info_log.info(f'删除镜像{image_name}成功')
                    resource_info.info(f'删除镜像{image_name}成功')
                except Exception as e:
                    error_log.error(f'镜像{image_name}删除失败，msg：{e}')
                    resource_info.error(f'镜像{image_name}删除失败，msg：{e}')
                    return {'code': sc.DeleteImageFailed}
                try:
                    info_log.info(f'删除文件表中记录{script.name}成功')
                    resource_info.info(f'删除文件表中记录{script.name}成功')
                except Exception as e:
                    FileDbManager.rollback()
                    error_log.error(f'删除文件表中记录{script.name}失败，msg：{e}')
                    resource_error.error(f'删除文件表中记录{script.name}失败，msg：{e}')
                    return {'code': sc.FailDelete, 'msg': e}
                data['can_upload'] = True
            # 如果原镜像不是默认镜像，现在是
            if not script.is_default and int(params.get('is_default')):
                try:
                    image_name = script.file_path.split('/')[-1].split('.tar')[0]
                    # 获取镜像id
                    image_id = exec_cmd_on_path(
                        "echo %s | sudo -S docker images | grep %s | awk '{print $3}'" % (config.PASSWORD,
                                                                                          image_name))

                    exec_cmd_on_path("echo %s | sudo -S docker rmi -f %s" % (config.PASSWORD, image_id))
                    info_log.info(f'删除镜像{image_name}成功')
                    resource_info.info(f'删除镜像{image_name}成功')
                except Exception as e:
                    error_log.error(f'镜像{image_name}删除失败，msg：{e}')
                    resource_info.error(f'镜像{image_name}删除失败，msg：{e}')
                    return {'code': sc.DeleteImageFailed}
                try:
                    run_image_script_path = os.path.join(RUN_IMAGE_SCRIPTS_PATH, script.name)
                    FileManager.del_script_from_server(run_image_script_path)
                    info_log.info(f'删除文件表中记录{script.name}成功')
                    resource_info.info(f'删除文件表中记录{script.name}成功')
                except Exception as e:
                    FileDbManager.rollback()
                    error_log.error(f'删除文件表中记录{script.name}失败，msg：{e}')
                    resource_error.error(f'删除文件表中记录{script.name}失败，msg：{e}')
                    return {'code': sc.FailDelete, 'msg': e}
                response, error = ResourceFileSchema(exclude=['uuid']).load(params, instance=script)
                if error:
                    error_log.error(f'修改资源文件失败，msg：{error}')
                    resource_error.error(f'修改资源文件失败，msg：{error}')
                    return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
                try:
                    response.file_path = config.DEFAULT_PATH
                    FileDbManager.save(response)
                except DataException as e:
                    FileDbManager.rollback()
                    error_log.error(f'使用默认镜像失败，msg：{e}')
                    resource_error.error(f'使用默认镜像失败，msg：{e}')
                    return {'code': sc.UseDefaultImagesFailed, 'msg': e}
                data['can_upload'] = False
                # 将默认镜像文件load成镜像
                exec_cmd_on_path('echo %s | sudo -S chmod -R 777 ./images' % config.PASSWORD,
                                 config.Config.UPLOADS_DEFAULT_DEST)
                image_name = config.DEFAULT_PATH.split('/')[-1].split('.tar')[0]
                try:
                    res = exec_cmd_on_path(
                        f'echo %s | sudo -S docker load -i {config.DEFAULT_PATH}' % config.PASSWORD)
                    if 'Loaded image' in res and image_name in res:
                        info_log.info(f'镜像{image_name}导入成功')
                        resource_info.info(f'镜像{image_name}导入成功')
                    else:
                        error_log.error(f'镜像{image_name}导入失败')
                        resource_error.error(f'镜像{image_name}导入失败')
                        return {'code': sc.ImportImageFailed}
                except Exception as e:
                    error_log.error(f'镜像{image_name}导入失败，msg：{e}')
                    resource_error.error(f'镜像{image_name}导入失败，msg：{e}')
                    return {'code': sc.ImportImageFailed}
            response, error = ResourceFileSchema(exclude=['uuid']).load(params, instance=script)
            if error:
                error_log.error(f'修改资源文件失败，msg：{error}')
                resource_error.error(f'修改资源文件失败，msg：{error}')
                return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
            try:
                FileDbManager.save(response)
            except Exception as e:
                FileDbManager.rollback()
                error_log.error(f'修改资源文件失败，msg：{e}')
                resource_error.error(f'修改资源文件失败，msg：{e}')
                return {'code': sc.VerificationError, 'msg': e}
            resource_info.info(f'修改文件{script.name}成功')
            return {'code': sc.Success, 'data': data}
        else:
            # 如果没有更换恶意文件，则只修改记录
            response, error = ResourceFileSchema(exclude=['uuid']).load(params, instance=script)
            if error:
                error_log.error(f'修改资源文件失败，msg：{error}')
                resource_error.error(f'修改资源文件失败，msg：{error}')
                return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
            # 如果更换了恶意文件，删除原来的文件，修改记录，返回can_upload=True，上传新的文件
            if file.get('malicious_files') and not isinstance(file.get('malicious_files'), str):
                data['can_upload'] = True
            try:
                FileDbManager.save(response)
            except Exception as e:
                FileDbManager.rollback()
                error_log.error(f'修改资源文件失败，msg：{e}')
                resource_error.error(f'修改资源文件失败，msg：{e}')
                return {'code': sc.AddFailed, 'msg': e}
            info_log.info(f'修改文件{script.name}成功')
            resource_info.info(f'修改文件{script.name}成功')
            return {'code': sc.Success, 'data': data}

    @staticmethod
    def get_resource_file(uuid):
        """
        根据uuid获取单个资源文件信息
        :param uuid:
        :return:
        """
        if not uuid:
            return {'code': sc.ParameterError}
        script = FileDbManager.get_script_by_uuid(uuid)
        response, error = ResourceFileSchema().dump(script)
        if error:
            error_log.error(f'获取单个资源文件信息失败，msg：{error}')
            resource_error.error(f'获取单个资源文件信息失败，msg：{error}')
            return {'code': sc.VerificationError, 'msg': error[list(error)[0]][0]}
        return {'code': sc.Success, 'data': response}

    @staticmethod
    def del_script_from_server(file_path):
        """
        删除服务器上资源文件
        :param file_path:
        :return:
        """
        if os.path.exists(file_path):
            os.remove(file_path)

    @staticmethod
    def upload_file(params):
        """
        nginx文件上传
        :param params:
        :return:
        """
        # 根据uuid获取文件记录，判断是恶意文件还是攻击脚本
        uuid = params.get('file_uuid')
        script = FileDbManager.get_script_by_uuid(uuid)
        file_name = params.get('file.name') if params.get('file.name') else params.get('.name')
        file_path = params.get('file.path') if params.get('file.path') else params.get('.path')
        md5value = params.get('file.md5') if params.get('file.md5') else params.get('.md5')
        # 这里频繁请求nginx有时会拿不到参数返回503，所以try,nginx配置已修改这个问题，防止万一，这里try不取消
        try:
            if script.type == ScriptMapping.attack_scripts.value and file_name.split('.')[-1] not in ['tar']:
                return {'code': sc.FileTypeError}
        except:
            script = FileDbManager.get_script_by_uuid(uuid)
            FileDbManager.delete_one(script)
            return {'code': sc.FileUploadFailed}
        # 改变文件权限，执行命令获取文件的md5值和nginx传递过来的md5值对比，是否是同一个文件
        if not os.path.exists(config.Config.UPLOADS_DEFAULT_DEST + '/images'):
            os.makedirs(config.Config.UPLOADS_DEFAULT_DEST + '/images')
        exec_cmd_on_path('echo %s | sudo -S chmod -R 777 ./images' % config.PASSWORD,
                         config.Config.UPLOADS_DEFAULT_DEST)
        exec_cmd_on_path('echo %s | sudo -S chmod -R u+x ./images' % config.PASSWORD,
                         config.Config.UPLOADS_DEFAULT_DEST)
        if md5value != hash_file(file_path):
            os.remove(file_path)
            return {'code': sc.FileMD5VerificationFailed}
        # 如果上传新的文件，删除原来的旧文件
        if script.file_path and md5value != hash_file(script.file_path):
            if script.file_path != config.DEFAULT_PATH:
                os.remove(script.file_path)
                info_log.info('旧文件删除成功')
                resource_info.info('旧文件删除成功')
        os.rename(file_path, file_path.rsplit('/', 1)[0] + '/' + file_name)
        file_path = file_path.rsplit('/', 1)[0] + '/' + file_name
        if script.type == ScriptMapping.malicious_files.value:
            # 镜像和恶意文件分开保存
            script_path = os.path.join(config.SCRIPTS_PATH, file_name)
            if not os.path.exists(config.SCRIPTS_PATH):
                os.makedirs(config.SCRIPTS_PATH)
            shutil.move(file_path, script_path)
            file_path = script_path
        script.update({"file_path": file_path})
        info_log.info(f'文件{file_name}上传成功')
        resource_info.info(f'文件{file_name}上传成功')
        # 如果是镜像文件，需要把镜像load成镜像
        if script.type == ScriptMapping.attack_scripts.value:
            image_name = file_name.split('.tar')[0]
            try:
                res = exec_cmd_on_path(
                    f'echo %s | sudo -S docker load -i {file_path}' % config.PASSWORD)
                if 'Loaded image' in res and image_name in res:
                    info_log.info(f'镜像{image_name}导入成功')
                    resource_info.info(f'镜像{image_name}导入成功')
                else:
                    error_log.error(f'镜像{image_name}导入失败')
                    resource_error.error(f'镜像{image_name}导入失败')
                    os.remove(file_path)
                    FileDbManager.delete_one(script)
                    return {'code': sc.ImportImageFailed}
            except Exception as e:
                error_log.error(f'镜像{image_name}导入失败，msg：{e}')
                resource_error.error(f'镜像{image_name}导入失败，msg：{e}')
                os.remove(file_path)
                FileDbManager.delete_one(script)
                return {'code': sc.ImportImageFailed}
        return {'code': sc.Success, 'data': {'file_name': file_name,
                                             'file_path': file_path}}

    @staticmethod
    def download_file(uuid, is_run_image_script):
        """
        从服务器下载资源文件
        :param run_image_script: 是否是运行镜像的脚本
        :param uuid:
        :return:
        """
        script = FileDbManager.get_script_by_uuid(uuid)
        if not script:
            return {'code': sc.NotFound}
        if is_run_image_script:
            info_log.info(f'运行攻击脚本{script.name}脚本文件{script.name}下载成功')
            resource_info.info(f'运行攻击脚本{script.name}脚本文件{script.name}下载成功')
            return script.run_image_script_path
        if script.type == ScriptMapping.malicious_files.value and is_run_image_script:
            return {'code': sc.ParameterError}
        if script.type == ScriptMapping.attack_scripts.value and not is_run_image_script:
            info_log.info(f'攻击脚本{script.name}镜像下载成功')
            resource_info.info(f'攻击脚本{script.name}镜像下载成功')
            return script.file_path
        else:
            info_log.info(f'恶意文件{script.name}下载成功')
            resource_info.info(f'恶意文件{script.name}下载成功')
            return script.file_path

    def get_resource_file_from_flow_resource(self, uuid):
        search = [uuid]
        resource_type = ResourceType.script
        batch_resource_dict = self.flow_resource_client.batch_resource_info(search, resource_type)
        data = batch_resource_dict.get(uuid, {})
        return data


class ApiManager(object):
    def batch_resource_info(self, search, resource_type):
        resource_dict = {}
        if resource_type == ResourceType.pcap:
            qs = PcapHandler.batch_pcap_by_names(search)
            for obj in qs:
                info = obj.to_dict()
                filename = info["name"]
                info["file_path"] = os.path.join(PCAP_PATH, filename)
                resource_dict[filename] = info
        else:
            qs = FileDbManager.get_many_by_uuids(search)
            for obj in qs:
                info = obj.to_dict()
                obj_uuid = info["uuid"]
                resource_dict[obj_uuid] = info
        return resource_dict


if __name__ == "__main__":
    # not_found_name = PcapManagement().not_found_pcap_names_form_flow_resource(["dns31628735135.pcap"])
    # print('not_found_name', not_found_name)

    file_manager = FileManager()
    file_info = file_manager.get_resource_file_from_flow_resource("111")
    print('file_info', file_info)
