# -*- coding: utf-8 -*-
from werkzeug.routing import BaseConverter
import config
from flask import Flask
from flask_migrate import MigrateCommand
from flask_script import Manager
from app.configure.api_v1 import configure_blueprint
from app.monitor.api_v1 import monitor_blueprint
from app.monitor.api_v1.traffic_monitor import TrafficMonitorApplication
from app.resources.api_v1 import resource_blueprint
from app.software.api_v1 import software_blueprint
from app.task.api_v1 import task_blueprint
from common.celery_helper import make_celery
from extension import init_extension


class RegexConverter(BaseConverter):

    def __init__(self, url_map, *items):
        super(RegexConverter, self).__init__(url_map)
        self.regex = items[0]


def create_app(env_name):
    app = Flask(__name__, static_folder='media')
    app.config.from_object(config.contest_config.get(env_name))
    app.url_map.converters['regex'] = RegexConverter

    app.register_blueprint(configure_blueprint, url_prefix='/api/v1/configure')
    app.register_blueprint(monitor_blueprint, url_prefix='/api/v1/monitor')
    app.register_blueprint(resource_blueprint, url_prefix='/api/v1/resource')
    app.register_blueprint(software_blueprint, url_prefix='/api/v1/software')
    app.register_blueprint(task_blueprint, url_prefix='/api/v1/task')

    init_extension(app=app)
    manager = Manager(app=app)
    manager.add_command('db', MigrateCommand)
    return app, manager


app, manager = create_app('product')
celery = make_celery(app)
celery.config_from_object('celery_config')


def start_ws_server():
    from threading import Thread
    import fcntl
    import atexit
    try:
        f = open('./log/ws.lock', 'wb')

        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        th = Thread(target=socket_server)
        th.setDaemon(True)
        th.start()
    except Exception:
        pass

    def unlock():
        fcntl.flock(f, fcntl.LOCK_UN)
        f.close()

    atexit.register(unlock)


def socket_server():
    from geventwebsocket import WebSocketServer, Resource
    from collections import OrderedDict
    from app.task.api_v1.task_running_status import TaskRunningApplication
    WebSocketServer(('', 8888), Resource(OrderedDict([
        ('/task_running', TaskRunningApplication)
        # ('/traffic_monitor', TrafficMonitorApplication),
        # ('/system_resource', SystemMonitorApplication),
        # ('/service_status', ServiceMonitorApplication)
    ]))).serve_forever()


start_ws_server()

if __name__ == '__main__':
    # print(app.url_map)
    manager.run()
