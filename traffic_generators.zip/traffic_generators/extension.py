from flask_caching import Cache
from flask_mail import Mail
from flask_marshmallow import Marshmallow
from flask_migrate import Migrate
from flask_moment import Moment
from flask_restplus import Api
from flask_session import Session
from flask_sqlalchemy import SQLAlchemy
from flask_uploads import UploadSet, configure_uploads, patch_request_class, SCRIPTS, TEXT, DOCUMENTS, DATA, ARCHIVES

migrate = Migrate()
db = SQLAlchemy()

ma = Marshmallow()
cache = Cache()

api = Api()

session = Session()
mail = Mail()
moment = Moment()
# 文件上传
SCRIPTS_PY = tuple(['py'])
SCRIPTS_SH = tuple(['sh'])
IMAGES = tuple('jpg jpeg png gif'.split())
DEFAULT = TEXT + DOCUMENTS + IMAGES + DATA + SCRIPTS + ARCHIVES + tuple(['pdf', 'md', 'rar'])
files = UploadSet(name='uploads', extensions=DEFAULT)
upload_logo = UploadSet(name='logo', extensions=IMAGES)
scripts = UploadSet(name='scripts', extensions=SCRIPTS)
scripts_py = UploadSet(name='scripts', extensions=SCRIPTS_PY)
scripts_sh = UploadSet(name='scripts', extensions=SCRIPTS_SH)


def init_extension(app):
    api.init_app(app)
    db.init_app(app)
    migrate.init_app(app, db=db)
    cache.init_app(app)
    session.init_app(app)
    ma.init_app(app)
    mail.init_app(app)
    # 本地化日期和时间插件
    moment.init_app(app)

    # 上传的初始化
    configure_uploads(app, files)
    configure_uploads(app, scripts)
    configure_uploads(app, upload_logo)
    configure_uploads(app, scripts_py)
    configure_uploads(app, scripts_sh)
    # flask-uploads 设置上传文件大小，默认64M，设置为None，大小由MAX_CONTENT_LENGTH决定
    patch_request_class(app, size=None)
