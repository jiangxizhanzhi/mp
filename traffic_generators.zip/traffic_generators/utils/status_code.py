status_codes = {
    1000: ("Success", dict(zh="成功", en='Success')),
    1001: ("ParameterError", dict(zh='参数错误', en='ParameterError')),
    1002: ("NotFound", dict(zh='内容不存在', en='NotFound')),
    1003: ("FailDelete", dict(zh='删除失败', en='FailDelete')),
    1004: ("FileFormatError", dict(zh='文件格式错误', en='FileFormatError')),
    1005: ("AddFailed", dict(zh='新增失败', en='AddFailed')),
    1006: ("EditFailed", dict(zh='编辑失败', en='EditFailed')),
    1007: ("GetFailed", dict(zh='获取信息失败', en='GetFailed')),
    1008: ("DuplicateName", dict(zh='名称重复', en='DuplicateName')),
    1009: ("MissingRequiredParameter", dict(zh='缺少必填参数', en='MissingRequiredParameter')),
    1010: ("DeleteItemNotEmpty", dict(zh='删除项不能为空', en='DeleteItemNotEmpty')),
    1011: ("FileSizeExceedsLimit", dict(zh='文件大小超过限制', en='FileSizeExceedsLimit')),
    1012: ("FileUploadFailed", dict(zh='文件上传失败', en='FileUploadFailed')),
    1013: ("FileDownloadFailed", dict(zh='文件下载失败', en='FileDownloadFailed')),
    1014: ("FileAlreadyExists", dict(zh='文件已经存在', en='FileAlreadyExists')),
    1015: ("FileMD5VerificationFailed", dict(zh='文件md5校验失败', en='FileMD5VerificationFailed')),
    1016: ("FileTypeError", dict(zh='文件类型错误', en='FileTypeError')),
    1017: ("SystemError", dict(zh='系统异常', en='SystemError')),

    2000: ("GetPortFailed", dict(zh='获取网口失败', en='GetPortFailed')),
    2001: ("PortAcquired", dict(zh='有端口正被占用', en='PortAcquired')),
    2002: ("MacNotExist", dict(zh='mac不存在', en='mac not exist')),

    3000: ("PacketConstructFailed", dict(zh='构造包失败', en='PacketConstructFailed')),
    3001: ("AddPayLoadFailed", dict(zh='添加包载荷失败', en='AddPayLoadFailed')),

    4000: ("VerificationError", dict(zh='校验错误', en='VerificationError')),
    4001: ("ImportYamlFail", dict(zh='导入yaml配置文件失败', en='ImportYamlFail')),
    4002: ("IPFormatError", dict(zh='ip格式错误', en='IPFormatError')),

    5000: ("TagIsBeUsed", dict(zh='tag被使用中', en='TagIsBeUsed')),

    6000: ("DataSerializationFailed", dict(zh='数据序列化失败', en='DataSerializationFailed')),
    6001: ("TaskActionError", dict(zh='任务操作参数错误', en='TaskActionError')),
    6002: ("ExecuteCommandFail", dict(zh='执行启动命令失败', en='ExecuteCommandFail')),
    6003: ("StartTrexServerFail", dict(zh='启动trex服务失败', en='StartTrexServerFail')),
    6004: ("UnbindPortFail", dict(zh='解绑端口失败', en='UnbindPortFail')),
    6005: ("TaskStopFailed", dict(zh='任务停止失败', en='TaskStopFailed')),
    6006: ("GetStandardTaskResultFail", dict(zh='获取标准任务结果失败', en='GetStandardTaskResultFail')),
    6007: ("TaskRunning", dict(zh='任务正在运行', en='TaskRunning')),
    6008: ("TaskNotStopped", dict(zh='任务未停止', en='TaskNotStopped')),
    6009: ("TaskStopped", dict(zh='任务已停止', en='TaskStopped')),
    6010: ("GenerationTrexCfgFail", dict(zh='生成trex启动配置文件失败', en='GenerationTrexCfgFail')),
    6011: ("FileResourceTypeError", dict(zh='文件资源类型失败', en='FileResourceTypeError')),

    7000: ("StartCaptureFailed", dict(zh='开始抓取失败', en='StartCaptureFailed')),
    7001: ("StopCaptureFailed", dict(zh='停止抓取失败', en='StopCaptureFailed')),

    8000: ("ImportImageFailed", dict(zh='导入镜像失败', en='ImportImageFailed')),
    8001: ("DeleteImageFailed", dict(zh='删除镜像失败', en='DeleteImageFailed')),
    8002: ("UpdateImageFailed", dict(zh='修改镜像失败', en='UpdateImageFailed')),
    8003: ("DuplicateImageName", dict(zh='镜像名称重复', en='DuplicateImageName')),
    8004: ("UseDefaultImagesFailed", dict(zh='使用默认镜像失败', en='UseDefaultImagesFailed')),
    8005: ("ImageRunning", dict(zh='镜像运行中', en='ImageRunning')),
    8006: ("ImageInUse", dict(zh='镜像使用中', en='ImageInUse')),

}


def set_values_into_global(dest: dict):
    for k, v in status_codes.items():
        dest.update({v[0]: k})


set_values_into_global(globals())
