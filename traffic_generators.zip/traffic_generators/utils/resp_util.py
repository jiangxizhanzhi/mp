import hashlib
import os
import random
import sched
import string
import subprocess
import threading
import time
from logging import getLogger

from flask import g

from utils.status_code import status_codes

task_info = getLogger('task_info')


def code_mag(code):
    lan = g.get('lan', "zh")
    msg = status_codes[code][1][lan]
    return msg


def resp_message(data=None, code=1000, msg=None) -> dict:
    '''
    返回值包装器
    :param data: 返回的数据内容
    :param code: 状态码
    :param msg: 返回的信息
    :return:
    '''
    resp = {'code': code, 'msg': msg}
    if not msg:
        lan = g.get('lan', "zh")
        msg = status_codes[code][1][lan]
        resp.update({'msg': msg})
    if data:
        resp.update({'data': data})
    return resp


def storage_unit_switch(size: int or float, org_unit: str = ("B", "KB", "MB", "GB", "TB", "PB"),
                        target_unit: str = ("B", "KB", "MB", "GB", "TB", "PB")):
    """
    存储单位转换

    :param size: 值
    :param org_unit: 原单位
    :param target_unit: 目标单位
    :return: 精确到小数点后两位
    """
    unit = ("B", "KB", "MB", "GB")
    if org_unit not in unit or target_unit not in unit:
        raise TypeError
    else:
        org_index = unit.index(org_unit)
        target_index = unit.index(target_unit)
        result = size * (1024 ** (org_index - target_index))
        return round(result, 2)


def chunk_read(filepath, size=10 * 1024 * 1024):
    """
    分块读取，返回生成器

    :param filepath: 文件的绝对路径
    :param size: 每次读取文件的大小
    :return: generator
    """
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(size)
            if not chunk:
                break
            yield chunk


def hash_file(filepath, size=10 * 1024 * 1024):
    """
    计算文件MD5值

    :param filepath: 文件的绝对路径
    :param size: 每次读取文件的大小
    :returns: str 文件的MD5值
    """
    md5 = hashlib.md5()
    with open(filepath, 'rb') as f:
        while True:
            chunk = f.read(size)
            if not chunk:
                break
            md5.update(chunk)

    return md5.hexdigest()


def exec_cmd(cmd, check_exit_code=True, return_stderr=False):
    """
    执行linux命令的方法
    :param cmd: 命令
    :param check_exit_code:
    :param return_stderr:
    :return:
    """
    obj = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    _stdout, _stderr = (obj.communicate())
    obj.stdin.close()
    msg = "cmd stdout:%s, cmd stderr:%s" % (_stdout, _stderr)
    # task_info.info(f"{cmd} ==> exec cmd result: {msg}")
    if obj.returncode and check_exit_code:
        raise RuntimeError(msg)

    return return_stderr and (_stdout, _stderr) or _stdout


def exec_cmd_with_path(cmd, path=None, check_exit_code=True, return_stderr=False):
    """
    执行linux命令的方法
    :param path:
    :param cmd: 命令
    :param check_exit_code:
    :param return_stderr:
    :return:
    """
    if path:
        os.chdir(path)
    obj = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    _stdout, _stderr = (obj.communicate())
    obj.stdin.close()
    if _stderr:
        task_info.info(f"exec_cmd_with_path error: {_stderr}")
    msg = "cmd stdout:%s, cmd stderr:%s" % (_stdout, _stderr)
    # task_info.info(f"exec cmd result: {msg}")
    if obj.returncode and check_exit_code:
        raise RuntimeError(msg)

    return return_stderr and (_stdout, _stderr) or _stdout


def exec_script_on_path(cmd, path=None, return_stderr=False):
    """
    执行linux命令的方法
    :param path:
    :param cmd: 命令
    :param return_stderr:
    :return:
    """
    """
        执行linux命令的方法
        :param path:
        :param cmd: 命令
        :param check_exit_code:
        :param return_stderr:
        :return:
        """
    if path:
        os.chdir(path)
    process = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    try:
        stdout, stderr = process.communicate(timeout=30)
        exit_code = process.wait()
        if stderr:
            task_info.info(f"exec_script_on_path error: {stderr}")
        msg = "cmd stdout:%s, cmd stderr:%s" % (stdout, stderr)
        if exit_code != 0:
            raise RuntimeError(stderr)

        if process.returncode:
            raise RuntimeError(msg)
        return return_stderr and (stdout, stderr) or stdout
    except Exception as e:
        process.kill()
        raise RuntimeError(f"[{cmd}] command execution failed: {e}")


def exec_cmd_on_path(cmd, path=None):
    """
    在某个路径执行linux命令的方法
    :param cmd: 命令
    :param path: 执行命令的路径
    :param return_stderr:
    :return:
    """
    res = None
    try:
        if not path:
            data = os.popen(cmd)
        else:
            os.chdir(path)
            data = os.popen(cmd)
        res = data.read()
        task_info.info(f"exec_cmd_on_path result: {res}")
    except Exception as e:
        task_info.error(f"exec_cmd_on_path error: {e}")
        pass

    return res


def exec_by_system(path, cmd):
    """
    在指定的路径下，通过os.system()来执行命令
    :param path:
    :param cmd:
    :return:
    """
    os.chdir(path)
    res = os.system(cmd)
    return True if res == 0 else False


def new_task(function, delay_time, args: set):
    """
    创建延时任务

    :param function: 延时执行的方法
    :param delay_time: 延时时间
    :param args: 方法所需参数
    :return:
    """
    scheduler = sched.scheduler(time.time, time.sleep)
    scheduler.enter(delay_time, 10, function, args)
    thread = threading.Thread(target=scheduler.run)
    thread.start()

    return thread


def get_file_size(path):
    """
    获取绝对路径下某文件大小， 以合适单位显式
    :param path: 必须是存在的路径
    :return: str

    """
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    index = 0
    size = os.path.getsize(path)
    while size > 1024:
        size = size / 1024
        index += 1

    return str(int(size)) + units[index]


def unit_change(file_size):
    """
    单位转换
    :param file_size: int, 单位B
    :return: float, unit

    """
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    index = 0
    while file_size > 1024:
        file_size = file_size / 1024
        index += 1

    return round(file_size, 2), units[index]


def get_Random_String(n):
    """
    随即生成指定长度的ascii码值
    :param n:
    :return:
    """
    # string.printable=string.ascii_letters(大小写）+string.digits(数字)+string.punctuation(标点符号）+string.whitespace(空白符号）
    x = string.ascii_letters + string.digits + string.punctuation
    salt = ''
    for i in range(n):
        salt += random.choice(x)
    return salt
