import redis

from config import redis_config

EXPIRE_TIME = 60 * 60 * 24


def get_redis_client():
    redis_client = RedisUtil()
    return redis_client


class RedisUtil:
    def __init__(self):
        # 连接redis
        self.__redis = redis.StrictRedis(host=redis_config.get('cache_host'),
                                         password=redis_config.get('cache_password'),
                                         port=redis_config.get('cache_port'),
                                         db=redis_config.get('cache_db'))

        self.lock_script = """
        if redis.call("exists", KEYS[1]) == 0 then
            redis.call("set", KEYS[1], ARGV[1])
            return 1
        else
            return 0
        end
        """

    def lpush(self, key, value):
        self.__redis.lpush(key, value)

    def rpush(self, key, value):
        self.__redis.rpush(key, value)

    def rpop(self, key):
        return self.__redis.rpop(key)

    def lpop(self, key):
        return self.__redis.lpop(key)

    # list长度
    def llen(self, key):
        return self.__redis.llen(key)

    # 设置key-value
    def set(self, key, value):
        self.__redis.set(key, value)

    def set_with_expire(self, key, value, time):
        self.__redis.setex(key, time, value)

    # 获取key-value
    def get(self, key):
        value = self.__redis.get(key)
        return value if not value else value.decode()

    # 判断key是否存在
    def is_existsKey(self, key):
        # 返回1存在，0不存在
        return self.__redis.exists(key)

    # 添加集合操作
    def add_set(self, key, value):
        # 集合中存在该元素则返回0,不存在则添加进集合中，并返回1
        # 如果key不存在，则创建key集合，并添加元素进去,返回1
        return self.__redis.sadd(key, value)

    # 判断value是否在key集合中
    def is_Inset(self, key, value):
        '''判断value是否在key集合中，返回布尔值'''
        return self.__redis.sismember(key, value)

    def inc(self, key):
        return self.__redis.incr(key)

    def decr(self, key):
        return self.__redis.decr(key)

    def delete(self, key):
        return self.__redis.delete(key)

    def zadd(self, set_name, key, value):
        return self.__redis.zadd(set_name, {key: value})

    def zincrby_with_expire(self, set_name, key, amount):
        result = self.__redis.zincrby(set_name, amount, key)
        self.__redis.expire(set_name, EXPIRE_TIME)
        return result

    def zrevrange(self, set_name, start, end):
        return self.__redis.zrevrange(set_name, start, end, withscores=True)

    # 关闭连接
    def close(self):
        self.__redis.close()

    # 定义锁定函数
    def acquire_lock(self, lock_name, lock_value):
        result = self.__redis.eval(self.lock_script, 1, lock_name, lock_value)
        return result == 1

    # 定义释放锁函数
    def release_lock(self, lock_name):
        self.__redis.delete(lock_name)
