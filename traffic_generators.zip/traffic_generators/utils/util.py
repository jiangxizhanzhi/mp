import ctypes
import inspect
import os
import re
import socket
import struct
import subprocess
import random
import time
import traceback
import zipfile
import fcntl
from datetime import datetime
import psutil

import numpy as np
from scipy.stats import binom
from scipy.stats import norm
from logging import getLogger

from uuid import uuid4

import yaml

from config import TREX_PORT_START, TREX_PORT_END, DPDK_PATH, PASSWORD, BASE_DIR, TREX_DAEMON_PORT_CACHE
from utils.redis_util import get_redis_client
from utils.resp_util import exec_by_system

uuidChars = ("a", "b", "c", "d", "e", "f",
             "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
             "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
             "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
             "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
             "W", "X", "Y", "Z")

task_info = getLogger('task_info')


def generate_uuid():
    return str(uuid4()).split('-')[-1]

def get_available_port():
    """获取一个可用的端口号"""
    cmd = ['lsof', '-i:']
    try:
        while not get_redis_client().acquire_lock(TREX_DAEMON_PORT_CACHE + "_LOCK", TREX_DAEMON_PORT_CACHE + "_LOCK"):
            time.sleep(1)

        while True:
            port = int(get_redis_client().inc(TREX_DAEMON_PORT_CACHE))
            if port < TREX_PORT_START:
                port = TREX_PORT_START
                get_redis_client().set(TREX_DAEMON_PORT_CACHE, port)

            if port >= TREX_PORT_END:
                port = TREX_PORT_START
                get_redis_client().set(TREX_DAEMON_PORT_CACHE, port)

            # port = random.choice(range(TREX_PORT_START, TREX_PORT_END))
            cmd.append(port)
            p = subprocess.Popen('lsof -i:{port}'.format(**locals()), shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, universal_newlines=True)
            out, err = p.communicate()
            if not out:
                break
    except Exception as e:
        port = random.choice(range(TREX_PORT_START, TREX_PORT_END))
        task_info.error(f"get_available_port error: {e}")
        task_info.error(traceback.format_exc())
    finally:
        get_redis_client().release_lock(TREX_DAEMON_PORT_CACHE + "_LOCK")

    task_info.info(f"get_available_port : {port}")
    return port


def ip2int(ip):
    """
    将ip的字符串转换成整型
    :param ip: ip地址
    :return:
    """
    packedIP = socket.inet_aton(ip)
    return struct.unpack("!L", packedIP)[0]


def int2ip(int_ip):
    """
    将ip的整数转换成ip字符串类型
    :param int_ip:
    :return:
    """
    return socket.inet_ntoa(struct.pack('!L', int_ip))


def check_ip(ip):
    """
    检查输入的字符串是否是一个正常的ip
    :param ip: 输入的IP字符串
    :return:
    """
    compile_ip = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
    if compile_ip.match(ip):
        return True
    else:
        return False


def unbind_port_from_dpdk(port_pci):
    """
    将dpdk管理的端口解绑，重新绑定到linux内核中
    :param port_pci: 端口的pci号
    :return:
    """
    unbind_cmd = 'echo {} | sudo -S python3 dpdk_nic_bind.py -u {}'.format(PASSWORD, port_pci)
    bind_linux_cmd = 'echo {} | sudo -S python3 dpdk_nic_bind.py -b e1000 {}'.format(PASSWORD, port_pci)
    unbind_result = exec_by_system(path=DPDK_PATH, cmd=unbind_cmd)
    if not unbind_result:
        return False
    bind_result = exec_by_system(path=DPDK_PATH, cmd=bind_linux_cmd)
    if not bind_result:
        return False
    return True


def generate_short_uuid():
    """
    生成短的uuid
    :return:
    """
    uuid = str(uuid4()).replace('-', '')
    result = ''
    for i in range(0, 8):
        sub = uuid[i * 4: i * 4 + 4]
        x = int(sub, 16)
        result += uuidChars[x % 0x3E]
    return result


def get_trex_port_order_num_mapping(file_path):
    """
    根据一个trex配置文件，返回配置文件中的interfaces中端口号的index和实际端口的序号的对应关系
    :param file_path: trex配置文件的路径
    :return: {0: 1, 1: 2},其中key为在trex配置文件interface中的序号，value为端口的序号
    """
    from app.software.ops.db_handler import PortHandler
    with open(file_path, 'r') as f:
        content = yaml.load(f.read(), Loader=yaml.FullLoader)[0]
    interface_list = content.get('interfaces')
    port_index_order_dict = {}
    for index, interface in enumerate(interface_list):
        port_obj = PortHandler.get_ports_by_pci([interface])[0]
        port_index_order_dict[index] = port_obj.port

    return port_index_order_dict


def get_dict_key_by_value(source_dict, value):
    """
    根据字典的value值获取其对应的key值
    :param source_dict: 需要获取的字典
    :param value: 字典的值
    :return: 字典的key
    """
    return list(source_dict.keys())[list(source_dict.values()).index(value)]


def zipdir(files, ziph):
    for root, dirs, file in os.walk(files):
        ziph.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.join(file, '..')))


def compress_files_to_one_file(files, zip_name):
    """
    将多个文件整理到一个压缩文件中
    :param files: 需要压缩的文件列表
    :param zip_name: 压缩文件的路径，包含名称
    :return:
    """
    zipf = zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED)
    for file in files:
        zipf.write(file, os.path.relpath(os.path.join(BASE_DIR, file), os.path.join(file, '..')))
    zipf.close()


def _async_raise(tid, exctype):
    """raises the exception, performs cleanup if needed"""

    tid = ctypes.c_long(tid)

    if not inspect.isclass(exctype):
        exctype = type(exctype)

    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))

    if res == 0:

        raise ValueError("invalid thread id")

    elif res != 1:

        # """if it returns a number greater than one, you're in trouble,

        # and you should call it again with exc=NULL to revert the effect"""

        ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)

        raise SystemError("PyThreadState_SetAsyncExc failed")


def stop_thread(thread):
    try:
        _async_raise(thread.ident, SystemExit)
    except Exception as e:
        task_info.info(f"stop thread error for {e}")


def sorted_stream_id(streams):
    """
    首先根据时间排序，然后根据next将stream流排序出stream_id
    :param streams: stream流列表
    :return:
    """
    _tmp_list = []
    _streams = sorted(streams, key=lambda x: x.create_time)
    _stream_name_list = [stream.name for stream in _streams]
    for stream in _streams:
        if not stream.next:
            _tmp_list.append(stream)
        else:
            _tmp_list.append(stream)
            print(stream.next)
            next_index = _stream_name_list.index(stream.next)
            print(next_index)
            next_stream = _streams.pop(next_index)
            _tmp_list.append(next_stream)

    return _tmp_list


def calculate_traffic_rate(task_obj, round, size):
    """
    利用二分法计算流量包的发送速率
    :param task_obj: 任务对象
    :param round: 轮次
    :param size: 帧长
    :return:
    """
    from app.task.ops.db_handler import RFCTaskResultHandler
    task_uuid = task_obj.uuid
    rate_init = task_obj.payload_mode.get('rate_init')  # 初始速度pps
    rate_init_percent = task_obj.payload_mode.get('rate_init_percent')  # 初始速度百分比
    rate_lower = task_obj.payload_mode.get('rate_lower')  # 最低的百分比
    max_rate = rate_init / rate_init_percent * 100  # 用户输入的限制的最大速率
    min_rate = (max_rate * rate_lower) / 100  # 用户输入的限制的最小速率
    # 首先判断是否存在rfc_result记录，如果没有的话，使用初始速率，有的话使用二分法计算速率
    rfc_latest_result = RFCTaskResultHandler.get_latest_by_task_uuid(task_uuid, round, size)
    if not rfc_latest_result:
        # 证明是首次进行测试, 最大速度就是设置的最大速度，最小速度是设置的速度
        return rate_init, max_rate, min_rate
    return (
                       rfc_latest_result.max_rate + rfc_latest_result.min_rate) / 2, rfc_latest_result.max_rate, rfc_latest_result.min_rate


def calculate_traffic_rate_by_step(task_obj, round, size):
    """
    利用10%的步长计算流量包的发送速率
    :param task_obj: 任务对象
    :param round: 轮次
    :param size: 帧长
    :return: 当前测试应该使用的速度, 测试的丢失率结果
    """
    from app.task.ops.db_handler import RFCTaskResultHandler
    task_uuid = task_obj.uuid
    rate_init = task_obj.payload_mode.get('rate_init')  # 初始速度pps
    rate_init_percent = task_obj.payload_mode.get('rate_init_percent')  # 初始速度百分比
    max_rate = rate_init / rate_init_percent * 100  # 用户输入的限制的最大速率
    # 首先判断是否存在rfc_result记录，如果没有的话，首先使用最大速率，然后已10%的步长降低发送速度
    rfc_latest_result = RFCTaskResultHandler.get_latest_by_task_uuid(task_uuid, round, size)
    if not rfc_latest_result:
        # 证明是首次进行测试
        return max_rate, 0
    return rfc_latest_result.max_rate * (1 - 0.1), rfc_latest_result.result


def calculate_traffic_seconds(task_obj, round, size):
    """
    利用二分法计算流量包的发送时间(秒数)
    :param task_obj: 任务对象
    :param round: 轮次
    :param size: 帧长
    :return:
    """
    from app.task.ops.db_handler import RFCTaskResultHandler
    task_uuid = task_obj.uuid
    init_time = task_obj.payload_mode.get('init_time')  # 初始时间秒数
    min_time = task_obj.payload_mode.get('min_time')  # 最小的时间秒数
    max_time = task_obj.payload_mode.get('max_time')  # 最大的时间秒数
    # 首先判断是否存在rfc_result记录，如果没有的话，使用初始设置的时间秒数，有的话使用二分法计算时间秒数
    rfc_latest_result = RFCTaskResultHandler.get_latest_by_task_uuid(task_uuid, round, size)
    if not rfc_latest_result:
        # 证明是首次进行测试
        return init_time, max_time, min_time
    return (
                       rfc_latest_result.max_rate + rfc_latest_result.min_rate) / 2, rfc_latest_result.max_rate, rfc_latest_result.min_rate


def get_ip(if_name):  # get machine ip
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,
        struct.pack('256s', if_name[:15])
    )[20:24])


def get_local_ip():
    """
    获取本地ip
    :return:
    """
    local_ip = get_redis_client().get("LOCAL_IP")
    if not local_ip:
        local_ip = get_ip(b'ens3')
        get_redis_client().set("LOCAL_IP", local_ip)
    return local_ip


def get_time_diff_second(time_from, time_to):
    """
    获取2个时间差，单位：秒
    :param time_from: 格式 "2022-10-25 11:30:26"
    :param time_to: 格式 "2022-10-25 11:30:26"
    :return:
    """
    time_from_struct = datetime.strptime(time_from, "%Y-%m-%d %H:%M:%S")
    time_to_struct = datetime.strptime(time_to, "%Y-%m-%d %H:%M:%S")
    seconds = abs(time_to_struct - time_from_struct).seconds
    return seconds


def rand(rate_min, rate_max):
    """
    随机分布
    :return:
    """
    result = []
    for i in range(0, 30):
        rate = random.randint(rate_min, rate_max)
        result.append({"time": i, "bandwidth": rate})
    return result


def binomial(rate_min, rate_max):
    """
    二项分布
    :return:
    """
    n = 29  # 试验次数
    p = 0.5  # 成功概率

    # 生成x坐标和对应的二项分布概率质量函数值
    x = np.arange(0, n + 1)
    pmf = binom.pmf(x, n, p)

    # 将y值限制在0.01到0.99之间
    pmf = np.clip(pmf, 0.01, 0.99)
    result = []
    i = 1
    for y in pmf:
        percentage = round(y * 7, 2)
        rate = rate_max * percentage
        if rate < rate_min:
            rate = rate_min
        result.append({"time": i, "bandwidth": rate})
        i += 1
    return result


def exponential(rate_min, rate_max):
    """
    指数分布
    :param rate_min:
    :param rate_max:
    :return:
    """
    result = []
    max_y = 29 ** 2
    for i in range(0, 30):
        y = i ** 2
        rate_y = (y / max_y) * rate_max
        if rate_y < rate_min:
            rate_y = rate_min
        result.append({"time": i, "bandwidth": round(rate_y, 2)})
    return result


def gaussian(rate_min, rate_max):
    """
    高斯分布
    :param rate_min:
    :param rate_max:
    :return:
    """
    # 定义均值和标准差
    mu, sigma = 15, 3

    # 生成一组x值
    x = np.linspace(0, 30, num=30)

    # 计算概率密度函数
    pdf = norm.pdf(x, mu, sigma)

    # 获取y轴坐标集合
    y_coords = pdf.tolist()
    max_y = max(y_coords)

    result = []
    for i, y in enumerate(y_coords):
        rate_y = (y / max_y) * rate_max
        if rate_y < rate_min:
            rate_y = rate_min
        result.append({"time": i, "bandwidth": round(rate_y, 2)})

    return result


def kill_processes(thread_name):
    """
    杀掉包含thread_name的进程
    :param thread_name:
    :return:
    """

    for process in psutil.process_iter():
        try:
            # 获取进程的命令行参数
            cmdline = process.cmdline()

            # 检查命令行参数是否包含匹配的文本
            if any(thread_name in arg for arg in cmdline):
                process.terminate()  # 终止进程
        except Exception as e:
            pass
