class APIException(Exception):
    """
    api接口引发的异常
    """

    def __init__(self, code, message=None):
        self.code = code
        self.message = message

    def __str__(self):
        return self.message


class DataException(Exception):
    """
    数据操作引发的异常
    """

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class ServiceException(Exception):
    """
    业务逻辑引发的异常
    """

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class ValidateException(Exception):
    '''
    校验引起的异常
    '''
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class UpdatePortException(Exception):

    def __init__(self, code, message=None):
        self.code = code
        self.message = message

    def __str__(self):
        return self.message




# ----------------- ******** configure ******** -----------------
# ----------------- ******** flow cfg ******** -----------------
class FlowCfgNotFound(Exception):
    def __init__(self, project, message=''):
        self.project = project
        self.message = message

    def __str__(self):
        return "flow cfg could not be found: %s,reason:%s" % (self.project, self.message)


# ----------------- ******** network structure ******** -----------------
class NetworkStructureNotFound(Exception):
    def __init__(self, project, message=''):
        self.project = project
        self.message = message

    def __str__(self):
        return "network structure could not be found: %s,reason:%s" % (self.project, self.message)


# ----------------- ******** resources ******** -----------------
# ----------------- ******** pcap ******** -----------------
class PcapNotFound(Exception):
    def __init__(self, project, message=''):
        self.project = project
        self.message = message

    def __str__(self):
        return "pcap info could not be found: %s,reason:%s" % (self.project, self.message)


# ----------------- ******** task ******** -----------------
# ----------------- ******** standard ******** -----------------
class StandardTaskNotFound(Exception):
    def __init__(self, project, message=''):
        self.project = project
        self.message = message

    def __str__(self):
        return "pcap info could not be found: %s,reason:%s" % (self.project, self.message)