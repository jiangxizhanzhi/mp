from logging import getLogger
from trex_stl_lib.api import *
from trex.astf.api import *
from config import TREX_HOST, TREX_PLATFORM_NAME, IN_USED_PORT, BASE_DIR
from extension import cache
from utils.redis_util import get_redis_client

task_info = getLogger('task_info')
global_clients = dict()
lock = threading.Lock()


def _init(ports):
    """ 初始化 """
    global global_clients
    stl_client = None
    try:
        if not global_clients or not str(ports[0]) in global_clients:
            cache_ports = cache.get(TREX_PLATFORM_NAME + '_zmq_port')
            task_info.info(f"cache ports: {cache_ports}")
            if not cache_ports:
                # 从配置文件中加载端口配置
                trex_config_file_dir = os.path.join(BASE_DIR, 'media/trex_configs/trex_platform.yaml')
                with open(trex_config_file_dir, 'r', encoding='utf-8') as yaml_file:
                    trex_config = yaml.load(yaml_file, Loader=yaml.SafeLoader)
                    task_info.info(f"reload trex_config: {trex_config[0]}")
                    sync_port = trex_config[0].get('zmq_rpc_port')
                    async_port = trex_config[0].get('zmq_pub_port')
                    cache.set(TREX_PLATFORM_NAME + '_zmq_port', json.dumps([sync_port, async_port]), timeout=-1)
            else:
                sync_port, async_port = json.loads(cache_ports)
            task_info.info(f"get stateless client, sync_port:{sync_port}, async_port:{async_port}")
            stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)
            task_info.info('connect to client')

            # 连接trex客户端
            stl_client.connect()
            task_info.info(f'reset global client port:{ports[0]}')

            # # 将端口全部重置，排除影响
            stl_client.reset(ports=ports)
            stl_client.acquire(ports=ports)

        # 校验客户端是否正常连接
        if not stl_client:
            stl_client = global_clients[str(ports[0])]
        is_connected = stl_client.is_connected()
        task_info.info(f'stl_client is_connected: {is_connected}')
        if not is_connected:
            stl_client.connect()
            stl_client.reset(ports=ports)
            stl_client.acquire(ports=ports)

        global_clients[str(ports[0])] = stl_client
    except Exception as e:
        task_info.error(f"init client error: {e}")


def get_client(ports, reset=True):
    try:
        task_info.info("global client to get client start")
        _init(ports)
        t = threading.currentThread()
        while check_port_in_use(ports):
            time.sleep(1)
            task_info.info(f'{t.name}: port {str(ports[0])} is in use, please wait...')
        task_info.info("global client to get client end")

        stl_client = global_clients[str(ports[0])]
        if reset:
            is_connected = stl_client.is_connected()
            if not is_connected:
                stl_client.connect()
                stl_client.reset(ports=ports)
                stl_client.acquire(ports=ports)
        return global_clients[str(ports[0])]
    except Exception as e:
        task_info.error(f"get_client error: {e}")
        del_client(ports)


def check_port_in_use(ports):
    lock.acquire()
    try:
        port_in_use = get_redis_client().llen(IN_USED_PORT + str(ports[0])) and get_redis_client().llen(
            IN_USED_PORT + str(ports[0])) > 0
        if not port_in_use:
            get_redis_client().lpush(IN_USED_PORT + str(ports[0]), str(ports[0]))
        return port_in_use
    except Exception as e:
        task_info.error(f"check_port_in_use error: {e}")
    finally:
        lock.release()


def del_client(ports):
    if str(ports[0]) in global_clients:
        task_info.info(f'==========del global client port:{ports[0]}')
        del global_clients[str(ports[0])]
