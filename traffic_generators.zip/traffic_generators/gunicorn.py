import multiprocessing

bind = '0.0.0.0:5001'
worker_class = 'gthread'
workers = multiprocessing.cpu_count() * 1
daemon = False

loglevel = 'info'
errorlog = './log/error.log'
accesslog = './log/access.log'
