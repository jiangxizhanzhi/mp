#!/usr/bin/env bash

cp /opt/project_dirs/traffic_generators/setup/v2.88.tar.gz /opt
cd /opt
tar -zxf /opt/v2.88.tar.gz
cd v2.88
tar -zxf trex_client_v2.88.tar.gz
