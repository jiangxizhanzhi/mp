#!/usr/bin/env bash
## 由于第一遍编译会报错退出，所以在这需要再make一遍
# cd /nginx/nginx-1.10.2
# make -j && make install

touch /usr/local/nginx/conf/traffic_generator.conf
cat <<"EOF" > /usr/local/nginx/conf/traffic_generator.conf
events{
    worker_connections  1024;
}


http{

    limit_req_zone $binary_remote_addr zone=allips:500m rate=2000r/s;
server {
    listen       80;
    server_name
    charset utf-8;
    client_max_body_size 10000m;
    access_log  /var/log/nginx/access.log;
    error_log  /var/log/nginx/error.log;

    location /favicon.ico {
        log_not_found off;
        access_log off;
    }

    location /api {
        client_max_body_size    2048m;
        set $Real $proxy_add_x_forwarded_for;
        if ( $Real ~ (\d+)\.(\d+)\.(\d+)\.(\d+),(.*) ){
                set $Real $1.$2.$3.$4;
        }
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_redirect off;
        proxy_pass http://localhost:5001/api;
    }

    # nginx_upload上传镜像文件
    location /api/v1/resource/upload {
        upload_pass @upload_image;
        upload_pass_args on;
        upload_store /opt/project_dirs/traffic_generators/media/images;
        upload_state_store /opt/project_dirs/traffic_generators/media/state_store;
        upload_store_access user:r;
        upload_resumable on;

        # Set specified fields in request body
        upload_set_form_field $upload_field_name.name "$upload_file_name";
        upload_set_form_field $upload_field_name.content_type "$upload_content_type";
        upload_set_form_field $upload_field_name.path "$upload_tmp_path";

        # Inform backend about hash and size of a file
        upload_aggregate_form_field "$upload_field_name.md5" "$upload_file_md5";
        upload_aggregate_form_field "$upload_field_name.size" "$upload_file_size";

        # 允许的字段，允许全部可以 "^.*$"
        upload_pass_form_field "^.*$";
        # 每秒字节速度控制，0表示不受控制，默认0, 128K
        upload_limit_rate 0;
        # 如果pass页面是以下状态码，就删除此次上传的临时文件
        #upload_cleanup 400 404 499 500-505;
        }

    location @upload_image {
        rewrite ^ /api/v1/resource/scripts/upload$1 break;
        proxy_pass http://localhost:5001;
        limit_req zone=allips burst=50 nodelay;
        }
}
}

EOF



cat <<"EOF" > /usr/local/nginx/nginx.conf
#user  nobody;
worker_processes 1;
#error_log  logs/error.log;
#error_log  logs/error.log  notice;
#error_log  logs/error.log  info;

#pid        logs/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       mime.types;
    default_type  application/octet-stream;

    #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
    #                  '$status $body_bytes_sent "$http_referer" '
    #                  '"$http_user_agent" "$http_x_forwarded_for"';

    #access_log  logs/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    #keepalive_timeout  0;
    keepalive_timeout  65;

    #gzip  on;

    include /usr/local/nginx/conf/*.conf;
    #server {
    #    #listen       80;
    #    server_name  localhost;

    #    #charset koi8-r;

    #    #access_log  logs/host.access.log  main;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }

    #    #error_page  404              /404.html;

    #    # redirect server error pages to the static page /50x.html
    #    #
    #    error_page   500 502 503 504  /50x.html;
    #    location = /50x.html {
    #        root   html;
    #    }
    #    include /usr/local/nginx/conf/*.conf;
    #    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #    #
    #    #location ~ \.php$ {
    #    #    proxy_pass   http://127.0.0.1;
    #    #}

    #    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #    #
    #    #location ~ \.php$ {
    #    #    root           html;
    #    #    fastcgi_pass   127.0.0.1:9000;
    #    #    fastcgi_index  index.php;
    #    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    #    include        fastcgi_params;
    #    #}

    #    # deny access to .htaccess files, if Apache's document root
    #    # concurs with nginx's one
    #    #
    #    #location ~ /\.ht {
    #    #    deny  all;
    #    #}
    #}

    # another virtual host using mix of IP-, name-, and port-based configuration
    #
    #server {
    #    listen       8000;
    #    listen       somename:8080;
    #    server_name  somename  alias  another.alias;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}


    # HTTPS server
    #
    #server {
    #    listen       443;
    #    server_name  localhost;

    #    ssl                  on;
    #    ssl_certificate      cert.pem;
    #    ssl_certificate_key  cert.key;

    #    ssl_session_timeout  5m;

    #    ssl_protocols  SSLv2 SSLv3 TLSv1;
    #    ssl_ciphers  HIGH:!aNULL:!MD5;
    #    ssl_prefer_server_ciphers   on;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}

}
EOF

# 启动nginx
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/traffic_generator.conf

# 设置nginx开机自启
mkdir /usr/lib/systemd/system/
cat <<"EOF" > /usr/lib/systemd/system/nginx.service
[Unit]
Description=nginx
After=network.target

[Service]
Type=forking
PIDFile=/usr/local/nginx/logs/nginx.pid
ExecStart=/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/traffic_generator.conf
ExecReload=/usr/local/nginx/sbin/nginx -s reload
ExecStop=/usr/local/nginx/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl enable nginx
