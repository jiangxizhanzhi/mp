#!/usr/bin/env bash

# 拷贝文件夹到指定目录
mkdir -p /opt/project_dirs
mv /home/traffic_generators /opt/project_dirs/

## 更换阿里云源
cp /etc/apt/sources.list /etc/apt/sources.list.bak
cat <<EOF > /etc/apt/sources.list
deb http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-security main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-updates main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-proposed main restricted universe multiverse

deb http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ bionic-backports main restricted universe multiverse
EOF
apt-get update && echo $?
echo "---------------------------------------------------------------------------------------------"

# pip换阿里源
mkdir -p ~/.pip/
cat <<EOF > ~/.pip/pip.conf
[global]
index-url = http://mirrors.aliyun.com/pypi/simple/
[install]
trusted-host=mirrors.aliyun.com
EOF

## 安装基础软件
apt-get install -y gcc
apt-get install -y g++
apt-get install -y cmake
apt-get install -y python-pip
apt-get install -y python3-pip
apt-get install -y python3-distutils
apt-get install -y python3.6-dev
apt-get install -y supervisor
apt-get install -y redis
apt-get install -y mysql-server mysql-common mysql-client libmysqlclient-dev
apt-get install -y fonts-noto
apt-get install -y dos2unix
apt-get install -y zip
apt-get install -y openvswitch-switch
echo "---------------------------------------------------------------------------------------------"

## 更新supervisor、mysql配置文件
dos2unix /opt/project_dirs/traffic_generators/setup/setup_mysql_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_mysql_conf.sh

dos2unix /opt/project_dirs/traffic_generators/setup/setup_supervisor_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_supervisor_conf.sh
echo "---------------------------------------------------------------------------------------------"

# 安装python3包
# 项目
pip3 install -r /opt/project_dirs/traffic_generators/requirements.txt
echo "---------------------------------------------------------------------------------------------"

## 初始化数据库
mysql -e "
CREATE USER 'cyberpeace'@'localhost' IDENTIFIED BY '6CzZt1GUyIWmBJqS';
CREATE DATABASE FLOW DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
GRANT ALL PRIVILEGES ON FLOW.* TO 'cyberpeace'@'localhost';
"
mysql -ucyberpeace -p6CzZt1GUyIWmBJqS -DFLOW < /opt/project_dirs/traffic_generators/setup/FLOW.sql
mysql -ucyberpeace -p6CzZt1GUyIWmBJqS -DFLOW < /opt/project_dirs/traffic_generators/setup/pcap_manager.sql
echo "---------------------------------------------------------------------------------------------"

systemctl restart mysql
supervisorctl reload
supervisorctl restart all
echo "---------------------------------------------------------------------------------------------"

## 配置trex
dos2unix /opt/project_dirs/traffic_generators/setup/setup_trex_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_trex_conf.sh
echo "---------------------------------------------------------------------------------------------"

## 编译nginx—upload-module 和配置nginx
dos2unix /opt/project_dirs/traffic_generators/setup/setup_nginx_upload.sh
dos2unix /opt/project_dirs/traffic_generators/setup/setup_nginx_conf.sh
bash /opt/project_dirs/traffic_generators/setup/setup_nginx_upload.sh
bash /opt/project_dirs/traffic_generators/setup/setup_nginx_conf.sh
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/traffic_generator.conf
echo "---------------------------------------------------------------------------------------------"

