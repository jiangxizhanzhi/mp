import datetime

from extension import db
from utils.util import generate_uuid


class DbManager:
    """
    操作数据库的一些公共方法
    """

    @classmethod
    def save(cls, object):
        """
        保存单条数据到数据库中
        :return:
        """
        db.session.add(object)
        db.session.commit()

    @classmethod
    def save_all(cls, objects):
        """
        保存多条数据到数据库
        :param objects: 多条数据的列表
        :return:
        """
        db.session.add_all(objects)
        db.session.commit()

    @classmethod
    def commit(cls):
        """
        数据库的单独提交
        :return:
        """
        db.session.commit()

    @classmethod
    def rollback(cls):
        """
        数据库的回滚
        :return:
        """
        db.session.rollback()

    @classmethod
    def delete_all(cls):
        """
        删除某个表中全部数据
        :return:
        """
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def delete_one(cls, object):
        db.session.delete(object)
        db.session.commit()

    @classmethod
    def get_all(cls):
        objects = db.session.query(cls).all()
        return objects

    def to_dict(self, exclued=None):
        TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
        dict_ = dict()
        all = {c.name: getattr(self, c.name, None) for c in self.__table__.columns}
        if not exclued:
            for k, v in all.items():
                if isinstance(v, datetime.datetime):
                    dict_[k] = v.strftime(TIME_FORMAT)
                else:
                    dict_[k] = v
        else:
            for k, v in all.items():
                if k not in exclued:
                    if isinstance(v, datetime.datetime):
                        dict_[k] = v.strftime(TIME_FORMAT)
                    else:
                        dict_[k] = v
        return dict_

    @classmethod
    def paginate(cls, page=None, per_page=None, filters=None, order_by=None):
        """
        分页查询方法

        :param page: 页码， 默认第一页
        :param per_page: 每页数量， 默认每页20条
        :param filters: 过滤条件，列表 例：[DbBase.uuid==uuid, DbBase.deleted==True]
        :param session: SQLAlchemy session
        :param order_by: 排序字段 示例: 'created_at desc'
        :return: dict total 总条数， items 数据列表， error_out 异常输出列表
        """

        error_out = []
        if page is None:
            page = 1

        if per_page is None:
            per_page = 20

        if page < 1:
            error_out.append("page must gt 1")
            page = 1

        if per_page < 0:
            error_out.append("per_page must gt 0")
            per_page = 20

        # session = session or get_session()
        session = db.session
        if isinstance(filters, list) and not None:
            if order_by:
                items = session.query(cls).filter(*filters).order_by(db.text(order_by)).limit(per_page).offset(
                    (page - 1) * per_page).all()
            else:
                items = session.query(cls).filter(*filters).limit(per_page).offset((page - 1) * per_page).all()
        else:
            if order_by:
                items = session.query(cls).order_by(db.text(order_by)).limit(per_page).offset(
                    (page - 1) * per_page).all()
            else:
                items = session.query(cls).limit(per_page).offset((page - 1) * per_page).all()

        if not items and page != 1:
            error_out.append(f"page {page} per_page {per_page} get items is none")

        if page == 1 and len(items) < per_page:
            total = len(items)
        elif isinstance(filters, list) and not None:
            total = session.query(db.func.count(cls.uuid)).filter(*filters).scalar()
        else:
            total = session.query(db.func.count(cls.uuid)).scalar()
        return {"total": total, "items": items, "error_out": error_out}

    def update(self, values):
        """Make the model object behave like a dict"""
        for k, v in values.items():
            setattr(self, k, v)
        db.session.commit()

    @classmethod
    def batch_delete_by_uuids(cls, uuids):
        cls.query.filter(cls.uuid.in_(uuids)).delete(synchronize_session=False)
        db.session.commit()

    @classmethod
    def rollback(cls):
        """
        数据库回滚操作
        :return:
        """
        db.session.rollback()
        db.session.commit()

    @classmethod
    def verify_unique_name(cls, name, exclude=None):
        """
        校验名称是否唯一
        :param name: 需要校验的名称
        :param exclude: 编辑时候的对象的uuid
        :return: 唯一的话返回True，否则返回False
        """
        if exclude:
            obj = cls.query.filter(cls.uuid != exclude).filter(cls.name == name).first()
        else:
            obj = cls.query.filter(cls.name == name).first()
        return True if not obj else False

    @classmethod
    def verify_unique_file_path(cls, file_path, exclude=None):
        """
        校验路径是否唯一
        :param file_path: 需要校验的路径
        :param exclude: 编辑时候的对象的uuid
        :return: 唯一的话返回True，否则返回False
        """
        if exclude:
            obj = cls.query.filter(cls.uuid != exclude).filter(cls.file_path == file_path).first()
        else:
            obj = cls.query.filter(cls.file_path == file_path).first()
        return True if not obj else False

    @classmethod
    def get_one_by_uuid(cls, uuid):
        """
        通过uuid来获取一条记录
        :param uuid: 记录的uuid
        :return:
        """
        return cls.query.filter(cls.uuid == uuid).first()

    @classmethod
    def batch_get_by_uuids(cls, uuids):
        """
        通过uuids批量查询记录
        :param uuids: 记录的uuids
        :return:
        """
        return cls.query.filter(cls.uuid.in_(uuids)).all()

    @classmethod
    def create_obj(cls, data, postfix):
        if not data["uuid"]:
            part_uuid = generate_uuid()
            uuid = f"{part_uuid}_{postfix}"
            data["uuid"] = uuid
        obj = cls(**data)
        cls.save(obj)
        return obj

    @classmethod
    def batch_obj_name_by_name(cls, names):
        objs_name = db.session.query(cls.name).filter(cls.name.in_(names)).all()
        return objs_name
