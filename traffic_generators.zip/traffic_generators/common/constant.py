from enum import Enum


class TaskResultStatus(object):
    init = 0
    running = 1
    stopping = 2
    stopped = 3
    not_started = 4

    STATUS = (
        (init, '初始化'),
        (running, '正在运行'),
        (stopping, '正在停止'),
        (stopped, '已停止'),
        (not_started, '未启动过'),
    )
    CHOICES_DICT = dict(STATUS)


class TaskPortStatus(object):
    init = 0
    running = 1
    error = 2
    stopped = 3
    pause = 4
    preparing = 5

    STATUS = (
        (init, '初始化'),
        (running, '运行中'),
        (error, '异常'),
        (stopped, '已停止'),
        (pause, '暂停'),
        (preparing, '准备中')
    )
    TASK_PORT_STATUS_DICT = dict(STATUS)


class TaskAction:
    start = 1
    stop = 2
    reset = 3

    ACTION = (
        (start, '开始'),
        (stop, '停止'),
        (reset, '重置')
    )

    TASK_ACTION_DICT = dict(ACTION)


class TaskStatus:
    success = 1
    fail = 2

    RESULT = (
        (success, '成功'),
        (fail, '失败'),
    )

    TASK_RESULT_DICT = dict(RESULT)


class ScriptMapping(Enum):
    attack_scripts = 1  # 攻击脚本
    malicious_files = 2  # 恶意文件


class LogType:
    error = 'error'
    info = 'info'
    system = 'system'

    RESULT = (
        (error, '错误日志'),
        (info, '详细日志'),
        (system, '系统日志')
    )

    LOG_TYPE_RESULT = dict(RESULT)


class CaptureStatusMapping(Enum):
    capturing = 1  # 正在抓取中
    capture_complete = 2  # 抓取完成


class AllStreamVM(object):
    all_vm_info = {
        "STLVmFlowVar": {
            "type": "flow_var",
            "name": "Not defined",
            "size": 4,
            "op": "inc",
            "split_to_cores": True,
            "init_value": 0,
            "min_value": 0,
            "max_value": 0,
            "step": 1,
            # "value_list": [],  # 不知道是否支持
        },
        "STLVmWrFlowVar": {
            "type": "write_flow_var",
            "name": "",
            "pkt_offset": 0,
            "add_value": 0,
            "is_big_endian": True
        },
        "STLVmFixIpv4": {
            "type": "fix_checksum_ipv4",
            "pkt_offset": 0
        },
        "STLVmTupleGen": {
            "type": "tuple_flow_var",
            "name": "Not defined",
            "ip_min": 1,
            "ip_max": 10,
            "port_min": 1025,
            "port_max": 65535,
            "limit_flows": 100000,
            "flags": 0
        },
        "STLVmTrimPktSize": {
            "type": "trim_pkt_size",
            "name": ""
        }
    }
    vm_type = [info["type"] for info in all_vm_info.values()]


class AllStreamsProtocol(object):
    all_protocol_info = {
        "Ether": {
            "src": 0,
            "dst": 0,
            "type": 0,
        },
        "IP": {
            "version": 0,
            "ihl": 0,
            "tos": 0,
            "len": 0,
            "id": 0,
            "flags": 0,
            "frag": 0,
            "ttl": 0,
            "proto": 0,
            "chksum": 0,
            "src": 0,
            "dst": 0,
            "options": 0,
        },
        "ICMP": {
            "type": 0,
            "code": 0,
            "chksum": 0,
            "id": 0,
            "seq": 0,
            "ts_ori": 0,
            "ts_rx": 0,
            "ts_tx": 0,
            "gw": 0,
            "ptr": 0,
            "reserved": 0,
            "length": 0,
            "addr_mask": 0,
            "nexthopmtu": 0,
            "unused": 0,
        },
        "TCP": {
            "sport": 0,
            "dport": 0,
            "seq": 0,
            "ack": 0,
            "dataofs": 0,
            "reserved": 0,
            "flags": 0,
            "window": 0,
            "chksum": 0,
            "urgptr": 0,
            "options": 0,
        },
        "UDP": {
            "sport": 0,
            "dport": 0,
            "len": 0,
            "chksum": 0,
        },
        "Raw": {
            "Text": "",
            "File": "",
            "Random ascii": 0
        }
    }


class IpVersions(object):
    ipv4 = "ipv4"
    ipv6 = "ipv6"

    CHOICES = (
        (ipv4, u"ipv4"),
        (ipv6, u"ipv6"),
    )

    CHOICES_DICT = dict(CHOICES)


class DutRole(object):
    gateway = "gateway"
    server = "server"

    CHOICES = (
        (gateway, u"网关设备"),
        (server, u"应用服务"),
    )

    CHOICES_DICT = dict(CHOICES)


class DutMode(object):
    TP = "TP"
    NAT = "NAT"

    CHOICES = (
        (TP, u"透明模式"),
        (NAT, u"路由模式"),
    )

    CHOICES_DICT = dict(CHOICES)


class NetworkStructureType(object):
    stl = 1
    astf = 2

    CHOICES = (
        (stl, u"无状态"),
        (astf, u"高级全状态"),
    )

    CHOICES_DICT = dict(CHOICES)


class StandardTaskType(object):
    ddos = 1
    scan = 2
    blast = 3
    other = 4
    app = 5

    RESULT = (
        (ddos, "DDOS"),
        (scan, "扫描"),
        (blast, "爆破"),
        (other, "其他"),
        (app, "中台使用"),
    )

    STANDARD_TASK_TYPE_DICT = dict(RESULT)


class ImageType:
    docker = 1
    kvm = 2

    RESULT = (
        (docker, "Docker"),
        (kvm, "Kvm")
    )

    IMAGE_TYPE_DICT = dict(RESULT)


class DDosType(object):
    TCPv4SinglePacketAttack = "TCPv4SinglePacketAttack"
    ICMPv4SinglePacketAttack = "ICMPv4SinglePacketAttack"
    ARPv4SinglePacketAttack = "ARPv4SinglePacketAttack"

    CHOICES = (
        (TCPv4SinglePacketAttack, u"TCPv4单包攻击"),
        (ICMPv4SinglePacketAttack, u"ICMPv4单包攻击"),
        (ARPv4SinglePacketAttack, u"ARPv4单包攻击"),
    )

    CHOICES_DICT = dict(CHOICES)


class ValueSolution(object):
    random = 1
    inc = 2,
    dec = 3,

    CHOICES = (
        (random, "random"),
        (inc, "inc"),
        (dec, "dec"),
    )

    CHOICES_DICT = dict(CHOICES)


class AstfDistribution(object):
    rand = 1
    seq = 2,

    CHOICES = (
        (rand, u"随机"),
        (seq, u"增加"),
    )

    CHOICES_DICT = dict(CHOICES)


class PortStatus(object):
    release = "release"
    acquire = "acquire"

    CHOICES = (
        (release, "释放"),
        (acquire, "锁定")
    )

    PORT_STATUS_DICT = dict(CHOICES)


class PcapType(object):
    strike = "strike"
    normal = "normal"

    CHOICES = (
        (strike, "武器库"),
        (normal, "普通")
    )

    PORT_STATUS_DICT = dict(CHOICES)


class Category(object):
    scan = 1
    blast = 2
    other = 3

    CHOICES = (
        (scan, "扫描"),
        (blast, "爆破"),
        (other, "其他"),
    )

    CHOICES_DICT = dict(CHOICES)


class TrexClientRecord:
    clients = {}


class ThreadingRecord:
    threads = {}


class RFCType:
    throughput = 1
    frame_loss_rate = 2
    latecy = 3
    back_to_back_frame = 4

    CHOICES = (
        (throughput, "吞吐量"),
        (frame_loss_rate, "丢包率"),
        (latecy, "时延"),
        (back_to_back_frame, "背靠背帧")
    )

    RFC_TYPE_DICT = CHOICES

    PORT_STATUS_DICT = dict(CHOICES)


class ResourceType(object):
    pcap = 1
    script = 2

    CHOICES = (
        (pcap, "流量包"),
        (script, "脚本"),
    )

    CHOICES_DICT = dict(CHOICES)
