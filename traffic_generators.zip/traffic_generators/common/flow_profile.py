import os

from trex.astf.api import *

from app.configure.ops.db_handler import CfgFlowsHandler
from app.resources.ops.db_handler import PcapHandler
from common.constant import AstfDistribution
from config import PCAP_PATH


class FlowProfile(object):
    def __init__(self, flow_uuid):
        self.flow_uuid = flow_uuid
        self.flows_handler = CfgFlowsHandler()
        self.flow_cfg_obj = self.flows_handler.get_obj_by_uuid(self.flow_uuid)
        self.pcap_handler = PcapHandler()

    def astf_ip_gen_dist(self, info):
        """
        :param info:
        :return: 返回trex的ASTFIPGenDist对象
        """
        ip_range_str = info["ip_range"]
        ip_range = ip_range_str.split("-")
        distribution = info["distribution"]
        if distribution == AstfDistribution.rand:
            distribution = "rand"
        else:
            distribution = "seq"
        astf_ip_gen_dist_obj = ASTFIPGenDist(ip_range=ip_range, distribution=distribution)
        return astf_ip_gen_dist_obj

    def astf_ip_gen(self, client_info, server_info):
        """

        :param client_info:
        :param server_info:
        :return: 返回trex的ASTFIPGen对象
        """
        ip_gen_c = self.astf_ip_gen_dist(client_info)
        ip_gen_s = self.astf_ip_gen_dist(server_info)
        ip_gen_obj = ASTFIPGen(dist_client=ip_gen_c, dist_server=ip_gen_s)
        return ip_gen_obj

    def astf_cap_info(self, cap_info):
        """

        :param cap_info:
        :return: 返回trex的ASTFCapInfo对象
        """
        pcap_uuid = cap_info["pcap_uuid"]
        pcap_obj = self.pcap_handler.get_obj_by_uuid(pcap_uuid)
        pcap_name = pcap_obj.name
        pcap_file_path = os.path.join(PCAP_PATH, pcap_name)
        cps = cap_info.get("cps")
        port = cap_info.get("port")
        cap_data = {
            "file": pcap_file_path,
            "port": port,
            "cps": cps,
        }
        cap_client = cap_info.get("client")
        cap_server = cap_info.get("server")
        if cap_client and cap_client:
            cap_ip_gen = self.astf_ip_gen(cap_client, cap_server)
            cap_data["ip_gen"] = cap_ip_gen
        astf_cap_info_obj = ASTFCapInfo(**cap_data)
        return astf_cap_info_obj

    def gen_astf_profile_obj_by_flow_cfg(self):
        """

        :return: 返回trex的ASTFProfile对象
        """
        astf_profile_data = {}
        flow_profile = self.flow_cfg_obj.profile
        default_client = flow_profile.get("client")
        default_server = flow_profile.get("server")
        default_ip_gen = self.astf_ip_gen(default_client, default_server)
        cap_list = []
        cap_info_list = flow_profile["cap_list"]
        for cap_info in cap_info_list:
            cap_info_obj = self.astf_cap_info(cap_info)
            cap_list.append(cap_info_obj)
        astf_profile_data["cap_list"] = cap_list
        astf_profile_data["default_ip_gen"] = default_ip_gen
        astf_profile_obj = ASTFProfile(**astf_profile_data)
        return astf_profile_obj


if __name__ == "__main__":
    # from trex.examples.astf import astf_path

    from manage import app

    with app.app_context():
        server = "192.168.33.40"
        c = ASTFClient(server=server)

        # connect to server
        c.connect()

        try:
            c.reset()

            # load ASTF profile
            # profile_path = os.path.join(astf_path.get_profiles_path(), 'http_simple.py')
            flow_profile = FlowProfile("c5a3d0d60fcb_flow")
            astf_profile_obj = flow_profile.gen_astf_profile_obj_by_flow_cfg()
            c.load_profile(astf_profile_obj)
            # c.load_profile(a)

            c.start(duration=5)
            # c.clear_profile()

        except ASTFError as e:
            print(e)
