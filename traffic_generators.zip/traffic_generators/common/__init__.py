from .models import *
from logging import getLogger

error_log = getLogger('error')
info_log = getLogger('info')