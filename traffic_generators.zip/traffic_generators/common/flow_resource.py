import requests

import config
from utils import status_code as sc


class FlowResourceClient(object):
    ResourceUrl = f"http://{config.FLOWRES}/api/v1/resource"

    @classmethod
    def batch_resource_info(cls, search, resource_type):
        '''
        批量获取资源信息
        :param search: 要查找的资源列表
        :param resource_type: 资源类型 ResourceType
        :return:
        '''

        url = f"{cls.ResourceUrl}/batch_resource_info"
        data = {
            "search": search,
            "resource_type": resource_type
        }
        print(data)
        # try:
        resp = requests.post(url, json=data, timeout=30)
        resp_json = resp.json()
        resp_status_code = resp_json.get("code")
        if resp_status_code == sc.Success:
            data = resp_json.get("data", {})
        else:
            data = {}
        # except Exception as e:
        #     error_log.error(f"request {url} error:{e}")

        return data


if __name__ == "__main__":
    from common.constant import ResourceType

    search = ["dns.pcap"]
    resource_type = ResourceType.pcap
    r = FlowResourceClient.batch_resource_info(search, resource_type)
    print("result", r)
