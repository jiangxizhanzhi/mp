from datetime import datetime

from common.db_manage import DbManager
from extension import db


class Tag(db.Model, DbManager):
    """"标签表    表名tag"""

    __tablename__ = "tag"
    id = db.Column(db.Integer, primary_key=True)  # 标签id
    name = db.Column(db.String(100))  # 标签名
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间


class License(db.Model):
    """认证管理表    表名license"""

    __tablename__ = "license"
    id = db.Column(db.Integer, primary_key=True)  # id
    key = db.Column(db.String(50))  # key值
    value = db.Column(db.String(200))  # value值


class Category(db.Model):
    """类别表    表名category"""

    __tablename__ = "category"
    id = db.Column(db.Integer, primary_key=True)  # 类别id
    name = db.Column(db.String(100))  # 类别名称
    description = db.Column(db.String(1024), default='')  # 类别描述信息
    parent_id = db.Column(db.Integer, default='')  # 父级id
    create_time = db.Column(db.DateTime, default=datetime.now)  # 创建时间
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)  # 更新时间
