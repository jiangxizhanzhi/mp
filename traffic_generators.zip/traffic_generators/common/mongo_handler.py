import config


class MongoDBClient:
    """
    封装的mongodb查询的方法
    """

    def __init__(self):
        """

        :param mongo_uri:
        :param db_name: 要链接的数据库名称
        :param collection_name: 要查询的集合的名称
        """
        try:
            import pymongo
        except ImportError:
            raise RuntimeError('未找到pymongo模块')
        self.mongo_uri = config.MONGO_URI
        self.db_name = config.MONGO_DB_NAME
        self.collection_name = config.MONGO_COLLECTION_NAME
        try:
            self._client = pymongo.MongoClient(self.mongo_uri)
            self._db = self._client.get_database(self.db_name)
            self._collection = self._db.get_collection(self.collection_name)
        except Exception as e:
            raise ConnectionRefusedError('mongo数据库链接失败')

    def get_one(self, filter_data):
        """
        根据输入的条件查询出一条数据
        :param filter_data: 查询条件,类型是一个字典
        :return:
        """
        return self._collection.find_one(filter_data, projection={'_id': False})

    def get_all(self, filter_data={}, per_page=10, page=1):
        """
        根据输入的条件将所有的数据查询返回
        :param filter_data: 查询条件
        :param per_page: 显示的最大数量
        :param page: 页码
        :return:
        """
        page = per_page * (page - 1)
        datas = self._collection.find(filter_data, projection={'_id': False}).limit(per_page).skip(page)
        return [data for data in datas]

    def get_one_between_fields(self, start_field, end_field, value):
        """
        返回两个字段范围之间的一条记录
        :param start_field: 要比较的第一个字段
        :param end_field: 要比较的第二个字段
        :param value: 需要比较的值
        :return:
        """
        return self._collection.find_one({start_field: {'$lte': value}, end_field: {'$gte': value}},
                                         projection={'_id': False})

    def get_all_between_fields(self, start_field, end_field, value, per_page=10, page=1):
        """
        返回两个字段范围之间的所有记录
        :param start_field: 要比较的第一个字段
        :param end_field: 要比较的第二个字段
        :param value: 需要比较的值
        :param per_page: 显示的最大数量
        :param page: 页码
        :return:
        """
        page = per_page * (page - 1)
        return self._collection.find({start_field: {'$lte': value}, end_field: {'$gte': value}},
                                     projection={'_id': False}).limit(per_page).skip(page)

    def get_count(self, filter_data={}):
        return self._collection.count(filter=filter_data)
