﻿from concurrent.futures.thread import ThreadPoolExecutor
from logging import getLogger

import psutil
from dpkt.ssl import TLS
from scapy.layers.dns import DNS
from trex_stl_lib.api import *
from trex.astf.api import *
import config
from app.resources.controller.resource_manager import PcapManagement
from app.resources.ops.db_handler import FileDbManager, PcapHandler
from extension import cache, db
from manage import celery
from config import BASE_DIR, TREX_HOST, PASSWORD
from common import error_log, info_log
from common.constant import TaskResultStatus, TaskStatus, PortStatus, TrexClientRecord, CaptureStatusMapping, \
    NetworkStructureType, ThreadingRecord, RFCType, ImageType, TaskPortStatus
from common.flow_profile import FlowProfile
from common.trex_handler import TrexDaemonHandler, TrexHandler
from tasks.global_client import get_client
from utils.exception_tools import DataException, APIException, ServiceException
from utils import status_code as sc
from utils.redis_util import get_redis_client
from utils.resp_util import exec_cmd, get_Random_String, exec_cmd_with_path, exec_script_on_path
from utils.util import generate_short_uuid, get_trex_port_order_num_mapping, \
    calculate_traffic_rate, calculate_traffic_rate_by_step, calculate_traffic_seconds, stop_thread, get_ip, \
    get_local_ip, get_available_port, rand, binomial, exponential, gaussian, get_time_diff_second, kill_processes
from app.monitor.ops.db_handler import TmpPcapHandler
from app.monitor.schema.validate import TmpPcapSchema
from app.configure.ops.db_handler import NetworkHandler
from app.software.ops.db_handler import PortHandler
from app.task.controller.ddos_task_manager import DDosStlAttackDeal, DDosStfAttackDeal
from app.task.ops.db_handler import CustomTaskHandler, TaskResultHandler, StandardTaskHandler, RFCTaskHandler, \
    RFCTaskResultHandler, TaskFlowRecordsHandler, TaskAttackFlowRecordsHandler, TaskPortManagerHandler
from scapy.layers.inet import IP, UDP, Ether
from app.task.controller.task_manager import generate_stl_start_file, init_stl_server, stop_task
from scapy.all import *
from datetime import datetime, timedelta
from threading import Thread
from app.task.schema.validate import TaskFlowRecordsSchema, TaskAttackFlowRecordsSchema
from scapy.layers.inet import *

celery_log = getLogger('celery_log')
task_error = getLogger('task_error')
task_info = getLogger('task_info')
lock = threading.Lock()


def send_stateless_traffic(task_uuid, task_time):
    """
    发送无状态模式的流量
    :param task_time: 任务开始时间
    :param task_uuid: 任务的uuid
    :return:
    """
    from manage import app
    with app.app_context():
        task_info.info(f'prepare to send stateless flow: {task_uuid}')
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result.status_detail
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_name = task.name
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        network_config = network.network_config
        client_port = network_config.get('client', [])
        # server_port = network_config.get('server', [])
        target_ip = client_port[0].get('default_gw')
        node_name = client_port[0].get('node_name')
        client_port_obj = PortHandler.get_one_by_node_name_and_mac(node_name, client_port[0].get('port'))

        task_info.info('client port:{}'.format(client_port_obj.port))
        # task_info.info('server网口信息:{}'.format(server_port_obj.port))

        try:
            # 生成无状态trex启动的配置文件
            generate_stl_start_file(network, task_name)
            task_info.info(f"start stateless task: {task_name}, generate trex config file success")
        except Exception as e:
            task_error.info(f"start stateless task: {task_name}, generate trex config file error: {e}")
            status_detail_list.append('generate trex config file error')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'result_detail':
                    'generate trex config file error', 'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
            )
            raise APIException(sc.GenerationTrexCfgFail)

        try:
            # 根据任务生成的trex启动配置文件启动trex
            trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
            # 获取trex启动的时候，是以ipv4启动的，还是ipv6启动的
            trex_args = '' if network.ip_versions == 'ipv4' else 'ipv6'

            daemon_server_status = TrexDaemonHandler.start_daemon_server(task_name, NetworkStructureType.stl)
            daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME)
            task_info.info(f"stateless task trex_daemon_port：{daemon_port}")
            if not daemon_server_status:
                task_info.error("start stateless task trex daemon failed")
                status_detail_list.append('restart trex daemon failed')
                task_result.update(
                    {'status_detail': status_detail_list, 'result': TaskStatus.fail,
                     'result_detail': 'restart trex daemon failed',
                     'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
                )
                raise APIException(sc.ExecuteCommandFail)

            trex_handler = TrexHandler(trex_host=TREX_HOST,
                                       trex_daemon_port=daemon_port,
                                       trex_args=trex_args)

            task_info.info("start trex service")
            trex_handler.start_stateless_server({'cfg': trex_config_path})
        except Exception as e:
            task_info.error(f'start stateless trex service failed: {e}')
            try:
                # 关闭服务
                trex_handler.stop()
                # 关闭守护进程
                TrexDaemonHandler.stop_daemon_server(task_name, NetworkStructureType.stl)
            except Exception as e2:
                task_info.error(f'stop stateless trex service failed: {e2}')

            # 删除缓存的守护进程port
            cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME)
            status_detail_list.append('start stateless trex service failed')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail,
                 'result_detail': 'start stateless trex service failed',
                 'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
            )
            raise APIException(sc.ExecuteCommandFail)

        stl_client = None
        try:
            sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
            task_info.info(f"create stateless client, sync_port:{sync_port}, async_port:{async_port}")
            stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)

            # 连接trex客户端
            stl_client.connect()
            # 将端口全部重置，排除影响
            stl_client.reset()
            stl_client.acquire()

            task_config = task.config
            specifics = task_config.get("specifics")
            # duration = specifics.get("duration")
            src_ip_range = specifics.get("src_ip_range")
            clients_start, clients_end = src_ip_range.split("-")
            mult_count = specifics.get("mult")

            if clients_start == '127.0.0.1' and clients_end == '127.0.0.1':
                # 来源ip未指定时，直接用本地ip作为来源ip
                local_ip = get_local_ip()
                clients_start = local_ip
                clients_end = local_ip

            dst_ip_range = specifics.get("dst_ip_range")
            servers_start, servers_end = dst_ip_range.split("-")

            cap_list = specifics["cap_list"]
            for item in cap_list:
                pcap_name = item.get("name")
                pcap_file = os.path.join(config.PCAP_PATH, pcap_name)

            vm = create_vm({"start": clients_start, "end": clients_end}, {"start": servers_start, "end": servers_end})
            stl_client.push_pcap(pcap_filename=pcap_file,  # our local PCAP file
                                 # ports=[{client_port_obj.port}, {server_port_obj.port}],             # use 'port'
                                 # duration=duration,
                                 ipg_usec=2000,  # IPG
                                 count=mult_count,
                                 force=True,
                                 vm=vm  # provide VM object
                                 )

            task_info.info('=======start to send flow')
            # 更改任务结果数据库状态
            status_detail_list.append('start to send flow')
            task_result.update({'status_detail': status_detail_list})
            # 将任务表中的无状态相关的启动数据添加到start方法中
            stl_client.start(force=True)

            # 另起一个线程，轮询当前发送流量状态
            status_thread = Thread(target=get_status, args=(stl_client, [0], task_uuid, task_time))
            status_thread.start()

            stl_client.wait_on_traffic()
            task_result.update({'result': 1, 'result_detail': 'send flow success'})

            # 停止获取流量状态线程
            stop_thread(status_thread)

            stl_client.stop()
            stl_client.release()

            status_detail_list.append('send flow success, prepare to stop trex server')
            task_result.update({'status': TaskResultStatus.stopping, 'status_detail': status_detail_list})
            task_info.info('=======start to stop trex server')
            trex_handler.stop()

            if os.path.exists(trex_config_path):
                os.remove(trex_config_path)
            # 删除缓存
            cache.delete(task_name + '_zmq_port')
            ThreadingRecord.threads.pop(task_uuid, None)

            status_detail_list.append('trex server stopped')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            task_info.info('send flow success')
        except Exception as e:
            task_error.error('{} task send flow failed: {}'.format(task_uuid, e))
            try:
                # 关闭服务
                trex_handler.stop()
                # 关闭守护进程
                TrexDaemonHandler.stop_daemon_server(task_name, 1)
            except Exception as e2:
                task_info.error(f'stateless trex service stop failed: {e2}')

            # 删除缓存的守护进程port
            cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME)
            status_detail_list.append('send flow failed')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'end_time': datetime.now(),
                 'status': TaskResultStatus.stopped}
            )

            task_info.info('stop flow failed, relevant service has stopped')
        finally:
            # 最后将链接断开
            if stl_client:
                stl_client.disconnect()


def send_stateless_traffic_with_global_client(task_uuid, task_time):
    """
    发送无状态模式的流量
    :param task_uuid: 任务id
    :param task_time: 任务开始时间
    :return:
    """
    from manage import app
    with app.app_context():
        task_info.info('check trex server status')
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_info.info(f'prepare to send stateless flow: {task_uuid}')
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        # task_info.info(f'==========task_result: {task_result.__dict__}')

        res = exec_cmd("sudo ps -ef | grep trex_platform |grep -v grep | awk '{print $2}'")
        str_res = str(res, 'utf-8')
        task_info.info(f"check trex server result: {str_res}")
        try:
            if not str_res:
                if not get_redis_client().get(config.RESTARTING_TREX_SERVER):
                    get_redis_client().set_with_expire(config.RESTARTING_TREX_SERVER, config.RESTARTING_TREX_SERVER, 60)
                    task_info.info('restart trex server')
                    init_stl_server()
                else:
                    task_info.info("waiting for trex server restart")
                    time.sleep(10)
        except Exception as e:
            task_result.update({
                'result': TaskStatus.fail,
                'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': TaskResultStatus.stopped}
            )
            return

        str_mac = exec_cmd(f"sudo ifconfig ens3|grep ether|tr -s ' ' |cut -d' ' -f3")
        out_mac = str(str_mac, 'utf-8').strip()

        status_detail_list = task_result.status_detail
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        network_config = network.network_config
        client_port = network_config.get('client', [])
        node_name = client_port[0].get('node_name')
        client_port_obj = PortHandler.get_one_by_node_name_and_mac(node_name, client_port[0].get('port'))

        ports = [client_port_obj.port]
        cur_mac = client_port_obj.mac
        is_out = out_mac == cur_mac
        task_info.info(f"client port: {ports}")

        task_status = TaskStatus.fail
        try:
            stl_client = get_client(ports)
            task_info.info(f"stl_client: {stl_client}")
            task_config = task.config
            specifics = task_config.get("specifics")
            # duration = specifics.get("duration")
            src_ip_range = specifics.get("src_ip_range")
            clients_start, clients_end = src_ip_range.split("-")
            mult_count = specifics.get("mult")

            push_remote = False

            if clients_start == '127.0.0.1' and clients_end == '127.0.0.1':
                # 来源ip未指定时，直接用本地ip作为来源ip
                local_ip = get_local_ip()
                clients_start = local_ip
                clients_end = local_ip

            dst_ip_range = specifics.get("dst_ip_range")
            servers_start, servers_end = dst_ip_range.split("-")

            cap_list = specifics["cap_list"]
            for item in cap_list:
                pcap_name = item.get("name")
                pcap_file = os.path.join(config.PCAP_PATH, pcap_name)

            packages = rdpcap(pcap_file)
            if len(packages) > 10000:
                push_remote = True

            if push_remote:
                tmp_pcap = []
                for pkt in packages:
                    try:
                        if pkt.haslayer("IP"):
                            pkt.getlayer("IP").chksum = None
                            pkt['IP'].src = clients_start
                            pkt['IP'].dst = servers_start
                        tmp_pcap.append(pkt)
                    except Exception as e:
                        print(f"read pcap error: {e}")
                        pass
                wrpcap(pcap_file, tmp_pcap)
                task_info.info(f'start to push remote for task: {task_uuid}')
                stl_client.push_remote(pcap_filename=pcap_file,  # our local PCAP file
                                       ports=ports,  # use 'port'
                                       count=1,
                                       force=True
                                       )
            else:
                task_info.info(f'start to push_pcap for task: {task_uuid}')
                vm = create_vm({"start": clients_start, "end": clients_end},
                               {"start": servers_start, "end": servers_end})
                stl_client.push_pcap(pcap_filename=pcap_file,  # our local PCAP file
                                     ports=ports,  # use 'port'
                                     ipg_usec=2000,  # IPG
                                     count=mult_count,
                                     force=True,
                                     vm=vm  # provide VM object
                                     )

                task_info.info(f'start to send flow for task: {task_uuid}')
                # 更改任务结果数据库状态
                status_detail_list.append('start to send flow')

                # 将任务表中的无状态相关的启动数据添加到start方法中
                stl_client.start(force=True)
                # stl_client.start(mult=str(mult_count), duration=duration, force=True, ports=ports)

            if is_out:
                send_thread = Thread(target=send_pkt, args=(pcap_file, clients_start, servers_start))
                send_thread.start()

            # 另起一个线程，轮询当前发送流量状态
            status_thread = Thread(target=get_status, args=(stl_client, ports, task_uuid, task_time))
            status_thread.start()
            ThreadingRecord.threads[task.uuid + "_status"] = status_thread

            stl_client.wait_on_traffic()
            task_result.update({'result': TaskStatus.success, 'result_detail': 'send flow success'})

            # 停止获取流量状态线程
            stop_thread(status_thread)
            task_status = TaskStatus.success
            status_detail_list.append('send flow success')
            stl_client.stop()
            stl_client.release()
            stl_client.disconnect()
            task_info.info(f'======= send flow success for task: {task_uuid}')
        except Exception as e:
            status_detail_list.append('send flow failed')
            task_info.error('{} task send flow failed: {}'.format(task_uuid, e))
        finally:
            task_result.update(
                {'status_detail': status_detail_list, 'result': task_status,
                 'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'status': TaskResultStatus.stopped}
            )
            # 最后删除网口使用缓存
            task_info.info(f'del cache list for task: {task_uuid} with port: {ports[0]}')
            get_redis_client().rpop(config.IN_USED_PORT + str(ports[0]))


def sync_batch_send_all(task_uuids, node_id, task_time):
    from manage import app
    with app.app_context():
        get_port_status_background_th = None
        get_port_status_attack_th = None
        task_status = TaskStatus.fail
        try:
            task_info.info('sync batch check trex server status')
            is_background_running = False
            is_attack_running = False
            stl_client = None
            for i, task_uuid in enumerate(task_uuids):
                task = StandardTaskHandler.get_one_by_uuid(task_uuid)
                if not task.file_resource_uuid:
                    # 背景流量，校验trex服务是否启动
                    res = exec_cmd("sudo ps -ef | grep trex_platform |grep -v grep | awk '{print $2}'")
                    str_res = str(res, 'utf-8')
                    task_info.info(f"check trex server result: {str_res}")
                    if not str_res:
                        if not get_redis_client().get(config.RESTARTING_TREX_SERVER):
                            get_redis_client().set_with_expire(config.RESTARTING_TREX_SERVER,
                                                               config.RESTARTING_TREX_SERVER, 60)
                            task_info.info('restart trex server')
                            init_stl_server()
                        else:
                            task_info.info("waiting for trex server restart")
                            time.sleep(10)

                    # 背景流量
                    task_info.info(f'sync batch prepare to send stateless flow: {task_uuid}')
                    # 将网络结构数据实例化为一个对象
                    network_structure = task.config.get("network_structure")
                    network = NetworkHandler(**network_structure)
                    network_config = network.network_config
                    client_port = network_config.get('client', [])
                    node_name = client_port[0].get('node_name')
                    client_port_obj = PortHandler.get_one_by_node_name_and_mac(node_name, client_port[0].get('port'))
                    ports = [client_port_obj.port]
                    task_info.info(f"client port[{i}]: {ports}")

                    try:
                        stl_client = get_client(ports, not is_background_running)
                        task_info.info(f"stl_client: {stl_client}")
                        task_config = task.config
                        specifics = task_config.get("specifics")
                        src_ip_range = specifics.get("src_ip_range")
                        clients_start, clients_end = src_ip_range.split("-")
                        mult_count = specifics.get("mult")

                        if clients_start == '127.0.0.1' and clients_end == '127.0.0.1':
                            # 来源ip未指定时，直接用本地ip作为来源ip
                            local_ip = get_local_ip()
                            clients_start = local_ip
                            clients_end = local_ip

                        dst_ip_range = specifics.get("dst_ip_range")
                        servers_start, servers_end = dst_ip_range.split("-")

                        cap_list = specifics["cap_list"]
                        for item in cap_list:
                            pcap_name = item.get("name")
                            pcap_file = os.path.join(config.PCAP_PATH, pcap_name)

                        vm = create_vm({"start": clients_start, "end": clients_end},
                                       {"start": servers_start, "end": servers_end})
                        task_info.info(f"sync stl_client sync push pcap: {pcap_file}")
                        stl_client.push_pcap(pcap_filename=pcap_file,  # our local PCAP file
                                             ports=ports,  # use 'port'
                                             ipg_usec=2000,  # IPG
                                             count=mult_count,
                                             force=True,
                                             vm=vm  # provide VM object
                                             )

                        task_info.info(f'sync batch start to send flow for task: {task_uuid}')

                        # 将任务表中的无状态相关的启动数据添加到start方法中
                        stl_client.start(force=True)
                        if not is_background_running:
                            # 另起一个线程，轮询当前发送流量状态
                            is_background_running = True
                            get_port_status_background_th = Thread(target=get_batch_status,
                                                                   args=(stl_client, ports, node_id, task_time))
                            get_port_status_background_th.start()
                            ThreadingRecord.threads[
                                "sync_batch_get_background_status" + node_id] = get_port_status_background_th

                        stl_client.wait_on_traffic()
                        task_status = TaskStatus.success
                        task_info.info(f'======= sync batch send flow success for task: {task_uuid}')
                    except Exception as e:
                        task_status = TaskStatus.fail
                        task_info.error('sync {} task send flow failed: {}'.format(task_uuid, e))
                    finally:
                        TaskResultHandler.update_status_by_task_id(TaskResultStatus.stopped, task_uuid, task_status)
                        # 最后删除网口使用缓存
                        task_info.info(f'sync del cache list for task: {task_uuid} with port: {ports[0]}')
                        get_redis_client().rpop(config.IN_USED_PORT + str(ports[0]))
                else:
                    # 攻击流量
                    if not is_attack_running:
                        is_attack_running = True
                        # 查询端口的详细信息
                        port_obj = PortHandler.get_one_by_port_mac(task.port)
                        # 起线程获取网口流量状态
                        get_port_status_attack_th = Thread(target=get_port_flow_status,
                                                           args=(port_obj.port_name, node_id, task_time))
                        get_port_status_attack_th.start()
                        ThreadingRecord.threads["sync_batch_get_attack_status" + node_id] = get_port_status_attack_th

                    info_log.info('sync batch prepare to run attack script')
                    status_detail_list = []
                    task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)

                    # 从此项目获取资源
                    file_resource_data = FileDbManager.get_one_by_uuid(task.file_resource_uuid)
                    file_resource_image_type = file_resource_data.image_type
                    file_resource_run_cmd = file_resource_data.run_cmd

                    if file_resource_image_type == ImageType.docker:
                        # 将port的状态更改为锁定,同时更新任务的uuid
                        status_detail_list.append('sync reset port success, start to prepare network')
                        task_result_obj.update(
                            {'status': TaskResultStatus.running, 'status_detail': status_detail_list}
                        )  # 调用异步任务去启动容器运行脚本
                        info_log.info('sync batch start calling task to run script')
                        sync_running_attack_scripts_local(task.uuid, file_resource_run_cmd)
        except Exception as e:
            task_info.error('sync batch send all error: {}'.format(e))
            # 批量更新任务运行结果
            TaskResultHandler.batch_update_result_status(TaskResultStatus.stopped, task_status, task_uuids)
        finally:
            task_info.info('sync batch run task end')
            # 批量更新任务运行结果
            TaskResultHandler.batch_update_result_status(TaskResultStatus.stopped, task_status, task_uuids)
            # 更新任务批量运行状态为结束
            TaskResultHandler.update_status_by_task_id(TaskResultStatus.stopped, node_id, TaskStatus.success)

            # 停止获取运行结果线程
            if get_port_status_background_th:
                stop_thread(get_port_status_background_th)
            if get_port_status_attack_th:
                stop_thread(get_port_status_attack_th)

            if stl_client:
                try:
                    stl_client.stop()
                    stl_client.release()
                    stl_client.disconnect()
                except Exception as e:
                    task_info.info(f"stl_client stop error for {e}")


def send_pkt(pcap_path, src_ip, dst_ip):
    exec_cmd(f"sudo python3 /opt/sendp.py {pcap_path} {src_ip} {dst_ip}")


def batch_send_traffic_with_global_client(task_uuids, node_id, task_time):
    """
    批量发送无状态模式的流量
    :param node_id: 节点id
    :param task_uuids: 任务id集合
    :param task_time: 任务开始时间
    :return:
    """
    from manage import app
    with app.app_context():
        get_port_status_background_th = None
        stl_client = None
        task_uuid = ""
        try:
            task_info.info('batch check trex server status')
            res = exec_cmd("sudo ps -ef | grep trex_platform |grep -v grep | awk '{print $2}'")
            str_res = str(res, 'utf-8')
            task_info.info(f"check trex server result: {str_res}")
            if not str_res:
                if not get_redis_client().get(config.RESTARTING_TREX_SERVER):
                    get_redis_client().set_with_expire(config.RESTARTING_TREX_SERVER, config.RESTARTING_TREX_SERVER, 60)
                    task_info.info('restart trex server')
                    init_stl_server()
                else:
                    task_info.info("waiting for trex server restart")
                    time.sleep(10)

            tasks = StandardTaskHandler.batch_get_by_uuids(task_uuids)

            # 并行
            task_info.info('batch prepare to send async stateless flow')
            ports = []
            task_result_list = []
            tmp_pcap = []

            thread_pool = ThreadPoolExecutor(max_workers=len(tasks))
            for i, task in enumerate(tasks):
                task_uuid = task.uuid
                task_result = TaskResultHandler.get_one_task_result(task_uuid)
                task_result_list.append(task_result)

                # 将网络结构数据实例化为一个对象
                network_structure = task.config.get("network_structure")
                network = NetworkHandler(**network_structure)
                network_config = network.network_config
                client_port = network_config.get('client', [])
                node_name = client_port[0].get('node_name')
                client_port_obj = PortHandler.get_one_by_node_name_and_mac(node_name, client_port[0].get('port'))
                ports = [client_port_obj.port]
                task_info.info(f"client port[{i}]: {ports}")

                task_status = TaskStatus.fail
                task_config = task.config
                specifics = task_config.get("specifics")
                src_ip_range = specifics.get("src_ip_range")
                clients_start, clients_end = src_ip_range.split("-")
                mult_count = specifics.get("mult")

                if clients_start == '127.0.0.1' and clients_end == '127.0.0.1':
                    # 来源ip未指定时，直接用本地ip作为来源ip
                    local_ip = get_local_ip()
                    clients_start = local_ip
                    clients_end = local_ip

                dst_ip_range = specifics.get("dst_ip_range")
                servers_start, servers_end = dst_ip_range.split("-")

                cap_list = specifics["cap_list"]
                for item in cap_list:
                    pcap_name = item.get("name")
                    pcap_file = os.path.join(config.PCAP_PATH, pcap_name)

                vm = create_vm({"start": clients_start, "end": clients_end},
                               {"start": servers_start, "end": servers_end})
                task_info.info(f"stl_client async load pcap: {pcap_file}")

                thread_pool.submit(split_pcap, pcap_file, tmp_pcap, clients_start, servers_start)

            thread_pool.shutdown(wait=True)
            new_pcap_file = os.path.join(config.PCAP_PATH, node_id + ".pcap")
            wrpcap(new_pcap_file, tmp_pcap)
            task_info.info(f'start to push remote for task node: {node_id}')

            if not stl_client:
                stl_client = get_client(ports)
                task_info.info(f"stl_client: {stl_client}")
            get_port_status_background_th = Thread(target=get_batch_status,
                                                   args=(stl_client, ports, node_id, task_time))
            get_port_status_background_th.start()
            ThreadingRecord.threads['get_port_status_background_th' + node_id] = get_port_status_background_th
            stl_client.push_remote(pcap_filename=new_pcap_file,
                                   ports=ports,
                                   count=1,
                                   force=True
                                   )
            # profile = STLProfile.load_pcap(new_pcap_file,
            #                                ipg_usec=2000,
            #                                vm=vm
            #                                )
            # stl_client.add_streams(profile.get_streams())
            task_info.info(f'start to send remote for task node: {node_id}')
            stl_client.wait_on_traffic()

            # 启动流量
            # stl_client.start(force=True)
            # # 启动线程，获取流量发送状态
            # get_port_status_background_th = Thread(target=get_batch_status,
            #                                        args=(stl_client, ports, node_id, task_time))
            # get_port_status_background_th.start()
            # ThreadingRecord.threads['get_port_status_background_th' + node_id] = get_port_status_background_th
            #
            # stl_client.wait_on_traffic()

            task_status = TaskStatus.success
            task_info.info('======= batch send flow success')
        except Exception as e:
            task_status = TaskStatus.fail
            task_info.error('{} batch task send flow failed: {}'.format(task_uuid, e))
            # task_info.error('batch_send_traffic_with_global_client error: {}'.format(e))
            # 批量更新任务运行结果
            TaskResultHandler.batch_update_result_status(TaskResultStatus.stopped, task_status, task_uuids)
        finally:
            # 删除网口使用缓存
            task_info.info(f'del cache list for task: {task_uuid} with port: {ports[0]}')
            get_redis_client().rpop(config.IN_USED_PORT + str(ports[0]))
            # 批量更新任务运行结果
            TaskResultHandler.batch_update_result_status(TaskResultStatus.stopped, task_status, task_uuids)

            # 背景流量运行结束，删除运行标志
            get_redis_client().lpop(config.BATCH_RUN_RESULT + node_id)
            if 0 == get_redis_client().llen(config.BATCH_RUN_RESULT + node_id):
                try:
                    task_info.info(f'batch run background task end')
                    TaskResultHandler.update_status_by_task_id(TaskResultStatus.stopped, node_id, TaskStatus.success)

                    if stl_client and stl_client.is_connected():
                        stl_client.stop()
                        stl_client.release()
                        stl_client.disconnect()

                    # 停止获取背景流量记录
                    if get_port_status_background_th and get_port_status_background_th.ident:
                        stop_thread(get_port_status_background_th)
                        ThreadingRecord.threads.pop('get_port_status_background_th' + node_id, None)
                except Exception as e:
                    task_info.error(f"stop get_port_status_background_th error:{e}")
                    pass

                try:
                    # 停止获取攻击流量记录
                    get_port_status_attack_th = ThreadingRecord.threads.get('get_port_status_attack_th' + node_id)
                    if get_port_status_attack_th and get_port_status_attack_th.ident:
                        stop_thread(get_port_status_attack_th)
                        ThreadingRecord.threads.pop('get_port_status_attack_th' + node_id, None)
                except Exception as e:
                    task_info.error(f"stop get_port_status_attack_th error:{e}")
                    pass


def split_pcap(pcap_file, tmp_pcap, clients_start, servers_start):
    packages = rdpcap(pcap_file)
    for n, pkt in enumerate(packages):
        try:
            pkt.time = time.time()

            if pkt.haslayer("IP"):
                pkt.getlayer("IP").chksum = None
                pkt['IP'].src = clients_start
                pkt['IP'].dst = servers_start
            tmp_pcap.append(pkt)
        except Exception as e:
            task_info.error(f"split pcap error: {e}")
            pass


def create_vm(ip_src_range, ip_dst_range):
    if not ip_src_range and not ip_dst_range:
        return None

    vm = []

    # task_info.info(f"===ip_src_range:{ip_src_range}")
    if ip_src_range:
        vm += [STLVmFlowVar(name="src",
                            min_value=ip_src_range['start'],
                            max_value=ip_src_range['end'],
                            size=4, op="inc"),
               # STLVmWrFlowVar(fv_name="src",pkt_offset= "IP.src")
               STLVmWrFlowVar(fv_name="src", pkt_offset=26)
               ]

    if ip_dst_range:
        vm += [STLVmFlowVar(name="dst",
                            min_value=ip_dst_range['start'],
                            max_value=ip_dst_range['end'],
                            size=4, op="inc"),

               # STLVmWrFlowVar(fv_name="dst",pkt_offset= "IP.dst")
               STLVmWrFlowVar(fv_name="dst", pkt_offset=30)
               ]

    vm += [  # STLVmFixIpv4(offset = "IP")
        STLVmFixIpv4(offset=14)
    ]

    return vm


def send_custom_traffic(task_uuid, task_time):
    """
    发送自定义流量
    :param task_time:
    :param task_uuid: 任务的uuid
    :return:
    """
    from manage import app
    with app.app_context():
        task_info.info(f'prepare to send custom flow: {task_uuid}')
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result.status_detail
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_name = task.name
        # 将网络结构数据实例化为一个对象
        network_structure = task.config.get("network_structure")
        network = NetworkHandler(**network_structure)
        network_config = network.network_config
        client_port = network_config.get('client', [])
        node_name = client_port[0].get('node_name')
        client_port_obj = PortHandler.get_one_by_node_name_and_mac(node_name, client_port[0].get('port'))
        task_info.info('client port:{}'.format(client_port_obj.port))

        try:
            # 生成自定义任务trex启动的配置文件
            generate_stl_start_file(network, task_name)
            task_info.info(f"start custom task: {task_name}, generate trex config file success")
        except Exception as e:
            task_error.info(f"start custom task: {task_name}, generate trex config file error: {e}")
            status_detail_list.append('generate trex config file error')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'result_detail':
                    'generate trex config file error', 'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
            )
            raise APIException(sc.GenerationTrexCfgFail)

        try:
            # 根据任务生成的trex启动配置文件启动trex
            trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
            # 获取trex启动的时候，是以ipv4启动的，还是ipv6启动的
            trex_args = '' if network.ip_versions == 'ipv4' else 'ipv6'

            daemon_server_status = TrexDaemonHandler.start_daemon_server(task_name, NetworkStructureType.stl)
            daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME)
            task_info.info(f"custom task trex_daemon_port：{daemon_port}")
            if not daemon_server_status:
                task_info.error("start custom task trex daemon failed")
                status_detail_list.append('restart trex daemon failed')
                task_result.update(
                    {'status_detail': status_detail_list, 'result': TaskStatus.fail,
                     'result_detail': 'restart trex daemon failed',
                     'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
                )
                raise APIException(sc.ExecuteCommandFail)

            trex_handler = TrexHandler(trex_host=TREX_HOST,
                                       trex_daemon_port=daemon_port,
                                       trex_args=trex_args)

            task_info.info("start trex service")
            trex_handler.start_stateless_server({'cfg': trex_config_path})
        except Exception as e:
            task_info.error(f'start custom trex service failed: {e}')
            try:
                # 关闭服务
                trex_handler.stop()
                # 关闭守护进程
                TrexDaemonHandler.stop_daemon_server(task_name, NetworkStructureType.stl)
            except Exception as e2:
                task_info.error(f'stop custom trex service failed: {e2}')

            # 删除缓存的守护进程port
            cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME)
            status_detail_list.append('start custom trex service failed')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail,
                 'result_detail': 'start custom trex service failed',
                 'end_time': datetime.now(), 'status': TaskResultStatus.stopped}
            )
            raise APIException(sc.ExecuteCommandFail)

        stl_client = None
        try:
            sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
            task_info.info(f"create custom client, sync_port:{sync_port}, async_port:{async_port}")
            stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)

            # 连接trex客户端
            stl_client.connect()
            ports = [0]
            # 将端口全部重置，排除影响
            stl_client.reset(ports=ports)
            stl_client.acquire(ports=ports)

            task_config = task.config
            specifics = task_config.get("specifics")
            duration = specifics.get("duration")
            src_ip_range = specifics.get("src_ip_range")
            clients_start, clients_end = src_ip_range.split("-")
            dst_ip_range = specifics.get("dst_ip_range")
            servers_start, servers_end = dst_ip_range.split("-")
            flow_protocol = specifics.get("flow_protocol")
            content = specifics.get("content")
            mult = str(specifics.get("mult"))

            if clients_start == '127.0.0.1' and clients_end == '127.0.0.1':
                # 来源ip未指定时，直接用本地ip作为来源ip
                local_ip = get_local_ip()
                clients_start = local_ip
                clients_end = local_ip

            src = {"start": clients_start, "end": clients_end}
            dst = {"start": servers_start, "end": servers_end}
            task_info.info(f"create custom src:{src}, dst:{dst}")
            s1 = STLStream(packet=create_pkt(src, dst, flow_protocol, content), mode=STLTXCont(pps=100))
            stl_client.add_streams([s1], ports)

            task_info.info('start to send custom flow')
            # 更改任务结果数据库状态
            status_detail_list.append('start to send custom flow')
            task_result.update({'status_detail': status_detail_list})
            # 将任务表中的无状态相关的启动数据添加到start方法中
            stl_client.start(mult=mult, duration=duration, force=True, ports=ports)

            # 另起一个线程，轮询当前发送流量状态
            status_thread = Thread(target=get_status, args=(stl_client, ports, task_uuid, task_time))
            status_thread.start()

            stl_client.wait_on_traffic()
            task_result.update({'result': 1, 'result_detail': 'send custom flow success'})

            # 停止获取流量状态线程
            stop_thread(status_thread)
            stl_client.stop()
            stl_client.release()

            status_detail_list.append('send custom flow success, prepare to stop trex server')
            task_result.update({'status': TaskResultStatus.stopping, 'status_detail': status_detail_list})
            task_info.info('start to stop trex server')
            trex_handler.stop()

            if os.path.exists(trex_config_path):
                os.remove(trex_config_path)
            # 删除缓存
            cache.delete(task_name + '_zmq_port')
            ThreadingRecord.threads.pop(task_uuid, None)

            status_detail_list.append('trex server stopped')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            task_info.info('send custom flow success')
        except Exception as e:
            task_error.error('{} task send custom flow failed: {}'.format(task_name, e))
            try:
                # 关闭服务
                trex_handler.stop()
                # 关闭守护进程
                TrexDaemonHandler.stop_daemon_server(task_name, 1)
            except Exception as e2:
                task_info.error(f'custom trex service stop failed: {e2}')

            # 删除缓存的守护进程port
            cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME)
            status_detail_list.append('send flow failed')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'end_time': datetime.now(),
                 'status': TaskResultStatus.stopped}
            )

            task_info.info('stop custom flow failed, relevant service has stopped')
        finally:
            # 最后将链接断开
            if stl_client:
                stl_client.disconnect()


def get_status(stl_client, ports, task_uuid, task_time):
    from manage import app
    with app.app_context():
        if not ports:
            ports = [0]
        i = 1
        now = datetime.now()
        offset = timedelta(seconds=1)
        # 当前执行次数
        group_count = TaskFlowRecordsHandler.get_max_group_count_by_task_uuid(task_uuid) + 1
        task_info.info("====1111")
        while stl_client.is_connected():
            try:
                stats = stl_client.get_stats(ports)
                task_info.info(f"stats['total']：{stats['total']}")
                opackets = round(stats['total']['opackets'])
                obytes = round(stats['total']['obytes'])
                tx_bps = round(stats['total']['tx_bps'] / 8, 2)
                oerrors = round(stats['total']['oerrors'])

                flow_record = {
                    'task_uuid': task_uuid,
                    'group_count': group_count,
                    'second': i,
                    'opackets': opackets,
                    'obytes': obytes,
                    'tx_bps': tx_bps,
                    'oerrors': oerrors,
                    'status': 0,
                    'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                }
                response, errors = TaskFlowRecordsSchema().load(flow_record, session=db.session)
                if errors:
                    error_log.error('create task flow records error：{}'.format(errors))
                    return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                TaskFlowRecordsHandler.save(response)
            except Exception as e:
                task_info.error(f"stl_client get_stats error: {e}")
                pass

            time.sleep(1)
            i = i + 1
            task_time = task_time + offset
            now = now + offset


def get_batch_status(stl_client, ports, node_id, task_time):
    from manage import app
    with app.app_context():
        if not ports:
            ports = [0]
        i = 1
        now = datetime.now()
        offset = timedelta(seconds=1)
        # 当前执行次数
        group_count = TaskFlowRecordsHandler.get_max_group_count_by_task_uuid(node_id) + 1

        while stl_client.is_connected():
            stats = stl_client.get_stats(ports)
            # task_info.info(f"==========stats port: {stats[ports[0]]}")
            task_info.info(f"==========stats total: {stats['total']}")
            opackets = round(stats['total']['opackets'])
            obytes = round(stats['total']['obytes'])
            tx_bps = round(stats['total']['tx_bps'] / 8, 2)
            oerrors = round(stats['total']['oerrors'])

            flow_record = {
                'task_uuid': node_id,
                'group_count': group_count,
                'second': i,
                'opackets': opackets,
                'obytes': obytes,
                'tx_bps': tx_bps,
                'oerrors': oerrors,
                'status': 0,
                'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
            }
            response, errors = TaskFlowRecordsSchema().load(flow_record, session=db.session)
            if errors:
                error_log.error('batch create task flow records error：{}'.format(errors))
                return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
            TaskFlowRecordsHandler.save(response)

            time.sleep(1)
            i = i + 1
            task_time = task_time + offset
            now = now + offset


def get_pcap_stream(pcap_path, src, dst):
    pg_id = cache.get("pg_id")
    if not pg_id:
        pg_id = 1
    pg_id = pg_id + 1
    cache.set("pg_id", pg_id)
    task_info.info(f"===========pg_id: {pg_id}")

    vm = [
        # src
        STLVmFlowVar(name="src",
                     min_value=src['start'],
                     max_value=src['end'],
                     size=4, op="inc"),
        STLVmWrFlowVar(fv_name="src", pkt_offset="IP.src"),

        # dst
        STLVmFlowVar(name="dst",
                     min_value=dst['start'],
                     max_value=dst['end'],
                     size=4, op="inc"),
        STLVmWrFlowVar(fv_name="dst", pkt_offset="IP.dst"),

        # checksum
        STLVmFixIpv4(offset="IP")
    ]

    return [STLStream(packet=STLPktBuilder(pkt=pcap_path, vm=vm),
                      mode=STLTXCont(pps=100),
                      flow_stats=STLFlowLatencyStats(pg_id=pg_id))]


def create_pkt(src, dst, flow_protocol, content):
    task_info.info(f"custom task create_pkt flow_protocol: {flow_protocol}, content: {content}")
    vm = [
        # src
        STLVmFlowVar(name="src",
                     min_value=src['start'],
                     max_value=src['end'],
                     size=4, op="inc"),
        STLVmWrFlowVar(fv_name="src", pkt_offset="IP.src"),

        # dst
        STLVmFlowVar(name="dst",
                     min_value=dst['start'],
                     max_value=dst['end'],
                     size=4, op="inc"),
        STLVmWrFlowVar(fv_name="dst", pkt_offset="IP.dst"),

        # checksum
        STLVmFixIpv4(offset="IP")
    ]

    base = eval(flow_protocol)
    base = base / Padding(content)
    pad = max(0, len(base)) * 'x'

    return STLPktBuilder(pkt=base / pad, vm=vm)


def send_DDos_stateless_traffic(task_uuid):
    '''
    无状态DDos流量发生
    :param task_uuid:
    :return:
    '''
    from manage import app
    with app.app_context():
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_name = task.name
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        # 生成流数据
        task_config = task.config
        specifics = task_config.get("specifics")
        stl_attack_deal = DDosStlAttackDeal()
        DDos_type = specifics.get("DDos_type")
        deal_func = stl_attack_deal.attack_func.get(DDos_type)
        stream_list = deal_func(specifics)
        # 从缓存中去取zmq_port的值
        trex_daemon_port = cache.get(task.name)
        trex_handler = TrexHandler(trex_host=TREX_HOST, trex_daemon_port=trex_daemon_port)
        sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
        task_info.info(
            f'启动DDos任务：{task_name}，成功获取sync_port：{sync_port} async_port：{async_port} trex_daemon_port：{trex_daemon_port}')
        stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)
        try:
            # 连接trex客户端
            stl_client.connect()
            # 将端口全部重置，排除影响
            stl_client.reset()
            stl_client.acquire()
            # 将端口管理表中的port状态更改为占用
            network_structure = task.config.get("network_structure")
            network_config = network_structure.get("network_config")
            port_num_list = [client["port"] for client in network_config.get('client')]
            for port_num in port_num_list:
                PortHandler.update_by_port(port_num, {'status': 'acquire', 'task_uuid': task_uuid})
            # stl_client.set_service_mode()
            task_info.info(f'启动DDos任务：{task_name}，开始加载stream流')
            result_status_detail = task_result.status_detail
            stl_client.add_streams(stream_list)
            # 将任务表中的无状态相关的启动数据添加到start方法中
            duration = specifics.get("duration")
            stl_client.start(duration=duration)
            # 更改任务结果数据库状态
            task_info.info(f'启动DDos任务：{task_name}，开始发送流量')
            result_status_detail.append('开始发送流量')
            task_result.update({'status_detail': result_status_detail})
            stl_client.wait_on_traffic()
            result_status_detail.append('流量发送成功')
            task_result.update(
                {'status_detail': result_status_detail, 'result': TaskStatus.success, 'result_detail': '流量发送成功',
                 'end_time': datetime.datetime.now()})
            stl_client.stop()
            stl_client.release()
        except STLError as e:
            task_error.error(f'启动DDos任务：{task_name}，任务发送流量失败: {e}')
            error_log.error(f'启动DDos任务：{task_name}，任务发送流量失败: {e}')
            result_status_detail.append('流量发送失败')
            task_result.update(
                {'status_detail': result_status_detail, 'result': TaskStatus.fail, 'result_detail': '流量发送失败',
                 'end_time': datetime.datetime.now()})
        stl_client.disconnect()
        for port_num in port_num_list:
            PortHandler.update_by_port(port_num, {'status': 'release', 'task_uuid': ''})
        result_status_detail.append('端口已经释放，准备停止trex服务器')
        task_result.update({'status': TaskResultStatus.stopping, 'status_detail': result_status_detail})
        trex_handler.stop()
        task_info.info(f'启动DDos任务：{task_name}，停止trex服务')
        info_log.info(f'启动DDos任务：{task_name}，停止trex服务')
        task_type = network_structure.get("type")
        TrexDaemonHandler.stop_daemon_server(task.name, int(task_type))
        task_info.info(f'启动DDos任务：{task_name}，杀掉trex守护进程服务')
        info_log.info(f'启动DDos任务：{task_name}，杀掉trex守护进程服务')
        result_status_detail.append('trex服务器已停止')
        task_result.update({'status': TaskResultStatus.stopped, 'status_detail': result_status_detail})
        task_info.info(f'启动DDos任务：{task_name}，任务结束')
        info_log.info(f'启动DDos任务：{task_name}，任务结束')
        # 删除生成的配置文件及缓存
        path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
        if os.path.exists(path):
            os.remove(path)
        # 删除缓存
        cache.delete(task_name + '_zmq_port')
        cache.delete(task_name)
        ThreadingRecord.threads.pop(task.uuid, None)


def send_stateful_traffic(task_uuid):
    """
    发送有状态流量
    :param task_uuid: 任务的uuid
    :return:
    """
    from manage import app
    with app.app_context():
        task = CustomTaskHandler.get_one_by_uuid(task_uuid)
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result.status_detail
        # 从缓存中去取zmq_port的值
        network = NetworkHandler.get_one_by_uuid(task.network_uuid)
        client_port_pci_list = []
        # port_capture_list = []
        for client in network.network_config.get('client'):
            port_obj = PortHandler.get_one_by_port(client.get('port'))
            # 判断是否需要捕获流量
            client_port_pci_list.append(port_obj.pci)
            # if client.get('capture'):
            #     port_capture_list.append({client.get('port'): client.get('capture_limit')})
        server_port_pci_list = []
        for server in network.network_config.get('server'):
            port_obj = PortHandler.get_one_by_port(server.get('port'))
            server_port_pci_list.append(port_obj.pci)
            # # 判断是否需要捕获流量
            # if server.get('capture'):
            #     port_capture_list.append({server.get('port'): server.get('capture_limit')})
        # 将port_capture_list中的key,根据pci和配置文件对应起来，解析成trex识别的端口号
        config_file_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task.name))
        port_index_order_dict = get_trex_port_order_num_mapping(config_file_path)
        # port_capture_list = [
        #     {get_dict_key_by_value(port_index_order_dict, list(port_capture.keys())[0]): list(port_capture.values())[0]}
        #     for port_capture in port_capture_list]

        trex_handler = TrexHandler(trex_host=TREX_HOST, master_daemon_port=cache.get(task.name))
        sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
        astf_client = ASTFClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)
        # 将trex发送流量时的客户端存储到全局字典中，便于捕获流量使用
        TrexClientRecord.clients[task_uuid] = astf_client
        try:
            # 连接全状态trex客户端
            astf_client.connect()
            # 将端口全部重置，排除影响
            astf_client.reset()
            # 将端口管理表中的port状态更改为占用
            ports_list = PortHandler.get_ports_by_pci(client_port_pci_list + server_port_pci_list)
            for port in ports_list:
                port.update({'status': PortStatus.acquire, 'task_uuid': task_uuid})

            # 加载flow配置文件
            task_info.info('开始加载Flow配置文件')
            info_log.info('开始加载Flow配置文件')
            flow_profile = FlowProfile(task.configuration_uuid)
            astf_profile_obj = flow_profile.gen_astf_profile_obj_by_flow_cfg()
            astf_client.load_profile(astf_profile_obj)
            astf_client.start(
                mult=task.multiplier,
                duration=task.duration,
                nc=bool(task.block),
                block=bool(task.block),
                latency_pps=task.latency_pps,
                ipv6=bool(task.ipv6)
            )

            # 更改任务结果数据库状态
            task_info.info('开始发送流量')
            info_log.info('开始发送流量')
            status_detail_list.append('开始发送流量')
            task_result.update({'status_detail': status_detail_list})
            # astf_client.acquire(force=True)
            # _id = astf_client.start_capture(rx_ports=[0], tx_ports=[0])

            # # 判断端口是否需要捕获流量，如果捕获，则开始抓取
            # if port_capture_list:
            #     capture_status, tmp_pcap_objs = start_capture_pcap(astf_client, port_capture_list,
            #                                                        port_index_order_dict, task_uuid)
            #     if not capture_status:
            #         task_info.error('开始捕获流量失败')
            #         error_log.error('开始捕获流量失败')
            #     else:
            #         task_info.info('开始捕获流量成功，流量捕获中')
            #         info_log.info('开始捕获流量成功，流量捕获中')

            # astf_client.set_service_mode()
            astf_client.wait_on_traffic()
            task_result.update({'result': 1, 'result_detail': '流量发送成功'})
            # astf_client.stop_capture(int(_id['id']), './simple.pcap')

            # 停止捕获流量
            # if port_capture_list:
            #     for tmp_pcap_obj in tmp_pcap_objs:
            #         capture_id = tmp_pcap_obj.capture_id
            #         output = os.path.join(BASE_DIR, tmp_pcap_obj.pcap_path)
            #         astf_client.stop_capture(capture_id=capture_id, output=output)
            #         tmp_pcap_obj.update(
            #             {'end_time': datetime.datetime.now(), 'status': CaptureStatusMapping.capture_complete.value})
            #     task_info.info('停止抓取流量，已保存')
            #     info_log.info('停止抓取流量，已保存')

            astf_client.stop()
            for port in ports_list:
                port.update({'status': PortStatus.release, 'task_uuid': ''})
            status_detail_list.append('流量发送成功，端口已经释放，准备停止trex服务器')
            task_result.update({'status': TaskResultStatus.stopping, 'status_detail': status_detail_list})
            task_info.info('开始停止trex服务')
            info_log.info('开始停止trex服务')
            trex_handler.stop()
            trex_handler.stop_trex_daemon()
            task_info.info('开始停止trex守护进程服务')
            info_log.info('开始停止trex守护进程服务')
            TrexDaemonHandler.stop_daemon_server(task.name, task.type)
            # 删除生成的配置文件及缓存
            CustomTaskHandler.delete_trex_config_by_task_uuid(task_uuid)
            # 删除缓存
            cache.delete(task.name + '_zmq_port')
            cache.delete(task.name)

            status_detail_list.append('trex服务器已停止')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            task_info.info('全状态流量发送成功,相关服务已停止')
            info_log.info('全状态流量发送成功,相关服务已停止')

        except TRexError as e:
            pass
        except ASTFError as e:
            task_error.error('{}任务发送流量失败: {}'.format(task.name, e))
            error_log.error('{}任务发送流量失败: {}'.format(task.name, e))
            status_detail_list.append('全状态流量发送失败')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            # 将端口状态释放
            for port in ports_list:
                port.update({'status': PortStatus.release, 'task_uuid': ''})
        finally:
            # 最后将链接断开
            astf_client.disconnect()
            TrexClientRecord.clients.pop(task_uuid, None)
            ThreadingRecord.threads.pop(task.uuid, None)


def send_DDos_stateful_traffic(task_uuid):
    """
       DDOS stl流量发生
       :param task_uuid: 任务的uuid
       :return:
    """
    from manage import app
    with app.app_context():
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result.status_detail
        # 从缓存中去取zmq_port的值
        network_structure = task.config.get("network_structure")
        network_config = network_structure.get("network_config")

        all_port_info = network_config.get('client', []) + network_config.get('server', [])
        port_num_list = [info["port"] for info in all_port_info]
        sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
        trex_args = '' if network_structure.get("ip_versions") == 'ipv4' else 'ipv6'
        trex_handler = TrexHandler(trex_host=TREX_HOST, master_daemon_port=cache.get(task.name),
                                   trex_zmq_port=async_port, trex_args=trex_args)
        if not trex_handler.is_running():
            trex_handler.restart_trex_daemon()
        task_name = task.name
        # 将端口管理表中的port状态更改为占用
        for port_num in port_num_list:
            PortHandler.update_by_port(port_num, {'status': 'acquire', 'task_uuid': task_uuid})
            task_info.info(f'启动DDos任务：{task_name}，成功占用端口{port_num}')
            info_log.info(f'启动DDos任务：{task_name}，成功占用端口{port_num}')

        trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(task_name))
        if network_structure.get("dut_mode") == 'NAT':
            # 此处的learn_mode，目前默认为第一种模式，后期可以添加2 3模式
            start_args = {'cfg': trex_config_path, 'learn_mode': 1}
        else:
            start_args = {'cfg': trex_config_path}

        # 生成yaml文件
        task_config = task.config
        specifics = task_config.get("specifics")
        DDos_type = specifics.get("DDos_type")
        stf_attack_deal = DDosStfAttackDeal()
        deal_func = stf_attack_deal.attack_func.get(DDos_type)
        deal_func(task_name, specifics)
        task_info.info(f"启动DDos任务：{task_name}，成功生成stf配置文件")
        info_log.info(f"启动DDos任务：{task_name}，成功生成stf配置文件")

        duration = int(specifics.get("duration"))
        traffic_yaml_path = os.path.join(BASE_DIR, 'media/stf', f"{task_name}.yaml")
        # TODO: 是否有能力在启动trex前 发送arp校验是否能联通dut
        try:
            trex_handler.start_trex(f=traffic_yaml_path, d=duration, **start_args)
            info_log.info(f'启动DDos任务：{task_name}，成功启动stl状态trex服务，并开始发送流量')
            task_info.info(f'启动DDos任务：{task_name}，成功启动stl状态trex服务，并开始发送流量')
            status_detail_list.append('trex服务器已启动，并发送流量')
            task_result.update({'status': TaskResultStatus.running, 'status_detail': status_detail_list})
            i = 600
            while i > 0:
                if trex_handler.is_idle():
                    i -= 1
                    break
            status_detail_list.append('流量发送成功')
            task_result.update({'status_detail': status_detail_list, 'result': TaskStatus.success,
                                'end_time': datetime.datetime.now()})
        except Exception as e:
            task_info.error(f'启动DDos任务：{task_name}, 执行stl状态trex服务出错:{e}')
            error_log.error(f'启动DDos任务：{task_name}, 执行stl状态trex服务出错')
            status_detail_list.append('trex服务出错')
            task_result.update(
                {'status_detail': status_detail_list, 'result': TaskStatus.fail, 'end_time': datetime.datetime.now()})
        task_result.update({'status': TaskResultStatus.stopping})
        trex_handler.stop()
        task_info.info(f'启动DDos任务：{task_name}，停止trex服务')
        info_log.info(f'启动DDos任务：{task_name}，停止trex服务')
        trex_handler.stop_trex_daemon()
        task_info.info(f'启动DDos任务：{task_name}，停止trex守护进程服务')
        info_log.info(f'启动DDos任务：{task_name}，停止trex守护进程服务')
        TrexDaemonHandler.stop_daemon_server(task.name, task.type)
        task_info.info(f'启动DDos任务：{task_name}，杀掉trex守护进程服务')
        info_log.info(f'启动DDos任务：{task_name}，杀掉trex守护进程服务')
        status_detail_list.append('trex服务器已停止')
        task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list})
        for port_num in port_num_list:
            PortHandler.update_by_port(port_num, {'status': 'release', 'task_uuid': ''})
            task_info.info(f'启动DDos任务：{task_name}，成功释放占用端口{port_num}')
            info_log.info(f'启动DDos任务：{task_name}，成功释放占用端口{port_num}')
        task_info.info(f'启动DDos任务：{task_name}，任务结束')
        info_log.info(f'启动DDos任务：{task_name}，任务结束')
        ThreadingRecord.threads.pop(task.uuid, None)


@celery.task
def running_attack_scripts_old(task_uuid, image_name, run_cmd, port_name, script_path):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param image_name: 镜像名称
    :param run_cmd: 运行命令
    :param port_name: 使用的网口的名称
    :param script_path: 需要导入镜像中的攻击脚本的路径
    :return:
    """
    from manage import app
    with app.app_context():
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result_obj.status_detail
        bridge_name = generate_short_uuid()
        cache.set(task.name + '_bridge', bridge_name, timeout=-1)
        # 由于资源是放在资源服务器上的，所以这里需要把路径替换下
        script_path = script_path.replace('flow_resource', 'traffic_generators')
        # 由于资源是放在资源服务器上的，所以需要在执行任务服务器上将镜像文件load成镜像
        image_path = os.path.join(config.IMAGE_PATH, image_name) + '.tar'
        load_image = 'echo {} | sudo -S docker load -i {}'.format(config.PASSWORD, image_path)
        # 创建网桥
        create_bridge_cmd = 'echo {} | sudo -S ovs-vsctl add-br {}'.format(PASSWORD, bridge_name)
        # 将端口和网桥绑定
        bind_port_to_bridge_cmd = 'echo {} | sudo -S ovs-vsctl add-port {} {}'.format(PASSWORD, bridge_name, port_name)
        # 启动容器
        run_docker_cmd = 'echo {} | sudo -S docker run -itd --name {} {} /bin/bash'.format(PASSWORD, task.uuid,
                                                                                           image_name)
        # 将容器的网络挂载到网桥上
        bind_docker_bridge_cmd = 'echo {} | sudo -S ovs-docker add-port {} eth1 {} --ipaddress={}'.format(PASSWORD,
                                                                                                          bridge_name,
                                                                                                          task.uuid,
                                                                                                          task.source_ip)
        chmod_cmd = 'echo {}| sudo chmod +x {}'.format(PASSWORD, script_path)
        # 将用户上传的攻击脚本文件导入docker容器中
        inject_file_to_container_cmd = 'echo {}| sudo -S docker cp {} {}:/root/'.format(PASSWORD, script_path,
                                                                                        task.uuid)
        run_cmd = 'echo {}| sudo -S docker exec {} /root/{} {}'.format(PASSWORD, task.uuid, run_cmd, task.target_ip)

        cmd_list = [load_image, create_bridge_cmd, bind_port_to_bridge_cmd, run_docker_cmd, bind_docker_bridge_cmd,
                    chmod_cmd, inject_file_to_container_cmd, run_cmd]
        for cmd in cmd_list:
            try:
                exec_cmd(cmd)
            except Exception as e:
                status_detail_list.append('运行脚本命令失败')
                task_result_obj.update(
                    {'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                     'result': TaskStatus.fail, 'result_detail': '运行脚本命令失败'}
                )
                celery_log.error('执行命令{}失败：{}'.format(cmd, e))
                error_log.error('执行命令{}失败：{}'.format(cmd, e))
                return False
        status_detail_list.append('运行脚本命令成功')
        task_result_obj.update(
            {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
             'result': TaskStatus.success, 'result_detail': '运行脚本命令成功'}
        )
        celery_log.info('运行攻击脚本成功')
        info_log.info('运行攻击脚本成功')
        return True


@celery.task
def running_attack_scripts_local(task_uuid, run_cmd, port_name, task_time):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param run_cmd: 运行命令
    :param port_name: 使用的网口的名称
    :param task_time: 任务执行时间
    :return:
    """
    from manage import app
    with app.app_context():
        from threading import Thread
        # 起线程获取网口流量状态
        get_port_status_th = Thread(target=get_port_flow_status, args=(port_name, task_uuid, task_time))
        get_port_status_th.start()

        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result_obj.status_detail
        celery_log.info('run_cmd: %s' % run_cmd)
        result = TaskStatus.success
        err_msg = "run command success"

        try:
            # 任务状态更新为运行中
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
                 'result': TaskStatus.success, 'result_detail': 'run command failed'}
            )
            exec_script_on_path(run_cmd, "/opt/project_dirs/traffic_generators/media/run_images_scripts")

            info_log.info('run attack command success')
        except Exception as e:
            result = TaskStatus.fail
            err_msg = e.args[0][e.args[0].find("Exception: "):]
            error_log.error('run command {} failed: {}'.format(run_cmd, err_msg))
        finally:
            TaskResultHandler.update_status_by_task_id_with_msg(TaskResultStatus.stopped, task_uuid, result, err_msg)
            stop_thread(get_port_status_th)


def sync_running_attack_scripts_local(task_uuid, run_cmd):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param run_cmd: 运行命令
    :return:
    """
    task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
    status_detail_list = task_result_obj.status_detail
    info_log.info('run_cmd: %s' % run_cmd)
    result = TaskStatus.success

    try:
        # 任务状态更新为运行中
        task_result_obj.update(
            {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
             'result': TaskStatus.success, 'result_detail': 'run command init'}
        )
        exec_cmd_with_path(run_cmd, "/opt/project_dirs/traffic_generators/media/run_images_scripts")

        info_log.info('run attack command success')
        status_detail_list.append('run command success')
    except Exception as e:
        status_detail_list.append('run command failed')
        result = TaskStatus.fail
        error_log.error('run command {} failed: {}'.format(run_cmd, e))
    finally:
        TaskResultHandler.update_status_by_task_id(TaskResultStatus.stopped, task_uuid, result)


def batch_running_attack_scripts_local(task_uuid, run_cmd):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param run_cmd: 运行命令
    :return:
    """
    from manage import app
    with app.app_context():
        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result_obj.status_detail
        info_log.info('batch run_cmd: %s' % run_cmd)
        result = TaskStatus.success

        try:
            # 任务状态更新为运行中
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
                 'result': TaskStatus.success, 'result_detail': 'batch run command init'}
            )
            exec_script_on_path(run_cmd, "/opt/project_dirs/traffic_generators/media/run_images_scripts")

            info_log.info('batch run attack command success')
            status_detail_list.append('batch run command success')
        except Exception as e:
            status_detail_list.append('batch run command failed')
            result = TaskStatus.fail
            error_log.error('batch run command {} failed: {}'.format(run_cmd, e))
            status_detail_list.append('run command failed')
        finally:
            TaskResultHandler.update_status_by_task_id(TaskResultStatus.stopped, task_uuid, result)


@celery.task
def running_attack_scripts(task_uuid, image_name, run_cmd, port_name, script_path, task_time):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param image_name: 镜像名称
    :param run_cmd: 运行命令
    :param port_name: 使用的网口的名称
    :param script_path: 需要导入镜像中的攻击脚本的路径
    :param task_time: 任务执行时间
    :return:
    """
    from manage import app
    with app.app_context():
        from threading import Thread
        # 起线程获取网口流量状态
        get_port_status_th = Thread(target=get_port_flow_status, args=(port_name, task_uuid, task_time))
        get_port_status_th.start()

        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result_obj.status_detail
        # 由于资源是放在资源服务器上的，所以这里需要把路径替换下
        script_path = script_path.replace('flow_resource', 'traffic_generators')
        # 由于资源是放在资源服务器上的，所以需要在执行任务服务器上将镜像文件load成镜像
        image_path = os.path.join(config.IMAGE_PATH, image_name) + '.tar'

        start_file = os.path.join(BASE_DIR, 'tasks/running_attack_scripts')
        cmd = f'{start_file} {task.uuid} {image_name} {port_name} {task.source_ip} {task.target_ip} {script_path} "{run_cmd}"'
        celery_log.info('exec_cmd: %s' % cmd)

        try:
            # 任务状态更新为运行中
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
                 'result': TaskStatus.success, 'result_detail': 'run command failed'}
            )
            exec_cmd(cmd)
        except Exception as e:
            stop_thread(get_port_status_th)
            status_detail_list.append('run command failed')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                 'result': TaskStatus.fail, 'result_detail': 'run command failed'}
            )
            error_log.error('run command {} failed: {}'.format(cmd, e))
            return False
        stop_thread(get_port_status_th)
        status_detail_list.append('run command success')
        task_result_obj.update(
            {'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
             'result': TaskStatus.success, 'result_detail': 'run command success'}
        )
        info_log.info('run attack command success')
        return True


def get_port_flow_status(port_name, task_uuid, task_time):
    """
    获取网口流量状态信息
    :param port_name: 网口名称
    :param task_uuid: 任务id
    :param task_time: 任务时间
    :return:
    """
    from manage import app
    with app.app_context():
        i = 1
        now = None
        offset = timedelta(seconds=1)
        # 当前执行次数
        group_count = TaskAttackFlowRecordsHandler.get_max_group_count_by_task_uuid(task_uuid) + 1
        pre_packets_sent = -1
        pre_bytes_sent = -1
        pre_errout = -1
        try:
            while True:
                if i % 5 == 0:
                    task_results = TaskResultHandler.get_task_result_by_task_uuid(task_uuid)
                    if task_results:
                        newed_result_obj = task_results[0]
                        status = newed_result_obj.status
                        if status == TaskResultStatus.stopped:
                            task_info.info(f"{task_uuid} task is stopped, cancel get port flow status")
                            break

                port_flow_status = psutil.net_io_counters(pernic=True)
                port_flow = port_flow_status.get(port_name)
                # info_log.info(f'get [{port_name}] flow status result: {port_flow}')
                packets_sent = round(port_flow.packets_sent)
                bytes_sent = round(port_flow.bytes_sent)
                errout = round(port_flow.errout)
                task_info.info(f"====script packets_sent: {packets_sent}")

                if pre_packets_sent == -1:
                    pre_packets_sent = packets_sent
                    pre_bytes_sent = bytes_sent
                    pre_errout = errout
                else:
                    if packets_sent != pre_packets_sent:
                        if not now:
                            now = datetime.now()
                        opackets = packets_sent - pre_packets_sent
                        obytes = bytes_sent - pre_bytes_sent
                        oerrors = errout - pre_errout
                        # 计算平均发包速率
                        tx_bps = round(obytes / i, 2)
                        attack_flow_record = {
                            'task_uuid': task_uuid,
                            'group_count': group_count,
                            'second': i,
                            'opackets': opackets,
                            'obytes': obytes,
                            'tx_bps': tx_bps,
                            'oerrors': oerrors,
                            'packets_sent': packets_sent,
                            'bytes_sent': bytes_sent,
                            'errout': errout,
                            'status': 0,
                            'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                            'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                        }
                        response, errors = TaskAttackFlowRecordsSchema().load(attack_flow_record, session=db.session)
                        if errors:
                            error_log.error('create attack task flow records error：{}'.format(errors))
                            return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                        TaskFlowRecordsHandler.save(response)
                        i = i + 1
                        now = now + offset
                    time.sleep(1)
                    task_time = task_time + offset
        except Exception as e:
            task_info.error(f"get port flow status error: {e}")


def batch_running_attack_scripts(task_uuid, image_name, run_cmd, port_name, script_path):
    """
    运行攻击脚本
    :param task_uuid: 任务的uuid
    :param image_name: 镜像名称
    :param run_cmd: 运行命令
    :param port_name: 使用的网口的名称
    :param script_path: 需要导入镜像中的攻击脚本的路径
    :return:
    """
    from manage import app
    with app.app_context():
        task = StandardTaskHandler.get_one_by_uuid(task_uuid)
        task_result_obj = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result_obj.status_detail
        start_file = os.path.join(BASE_DIR, 'tasks/running_attack_scripts')
        cmd = f'{start_file} {task.uuid} {image_name} {port_name} {task.source_ip} {task.target_ip} {script_path} "{run_cmd}"'
        celery_log.info('exec_cmd: %s' % cmd)

        try:
            # 任务状态更新为运行中
            task_result_obj.update(
                {'status': TaskResultStatus.running, 'status_detail': status_detail_list,
                 'result': TaskStatus.success, 'result_detail': 'run command failed'}
            )
            exec_cmd(cmd)
        except Exception as e:
            status_detail_list.append('run command failed')
            task_result_obj.update(
                {'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                 'result': TaskStatus.fail, 'result_detail': 'run command failed'}
            )
            error_log.error('run command {} failed: {}'.format(cmd, e))
            return False
        status_detail_list.append('run command success')
        task_result_obj.update(
            {'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
             'result': TaskStatus.success, 'result_detail': 'run command success'}
        )
        info_log.info('run attack command success')
        return True


def start_capture_pcap(trex_client, port_capture_list, port_index_order_dict, task_uuid):
    """
    在发送流量的过程中捕获流量包
    :param stl_client: 无状态trex客户端
    :param port_capture_list: 端口捕获信息的列表
    :param port_index_order_dict: 配置文件中的interfaces中端口号的index和实际端口的序号的对应关系
    :param task_uuid: 任务的uuid
    :return:
    """
    capture_list = []
    for port_capture_obj in port_capture_list:
        capture_params = {}
        port_index = list(port_capture_obj.keys())[0]
        _limit = list(port_capture_obj.values())[0]
        trex_client.set_service_mode(port_index)
        # 数据库中存储的tx rx为portmanager数据库中端口的序号
        capture_obj = trex_client.start_capture(tx_ports=[port_index], rx_ports=[port_index], limit=_limit)
        capture_params['capture_id'] = capture_obj.get('id')
        capture_params['name'] = task_uuid + '_' + str(time.time()).replace('.', '') + '.pcap'
        capture_params['tx_port'] = port_index_order_dict.get(port_index)
        capture_params['rx_port'] = port_index_order_dict.get(port_index)
        capture_params['filter'] = ''  # 目前暂未启用过滤
        capture_params['limit'] = _limit
        capture_params['status'] = CaptureStatusMapping.capturing.value
        capture_params['task_uuid'] = task_uuid
        capture_list.append(capture_params)

    response, error = TmpPcapSchema(many=True).load(capture_list, session=db.session)
    if error:
        error_log.error(error)
        celery_log.error(error)
    try:
        TmpPcapHandler.save_all(response)
        celery_log.info('网口流量抓取记录成功')
        info_log.info('网口流量抓取记录成功')
        return True, response
    except Exception as e:
        TmpPcapHandler.rollback()
        error_log.error(e)
        celery_log.error(e)
        return False, ''


def send_rfc_stateless_traffic(task_uuid):
    """
    发送rfc2544任务无状态模式的流量
    :param task_uuid: 任务的uuid
    :return:
    """
    from manage import app
    with app.app_context():
        task = RFCTaskHandler.get_one_by_uuid(task_uuid)
        task_result = TaskResultHandler.get_one_task_result(task_uuid)
        status_detail_list = task_result.status_detail
        # 从缓存中去取zmq_port的值
        port_pci_list = []
        for client in task.network_config.get('client'):
            port_obj = PortHandler.get_one_by_port(client.get('port'))
            port_pci_list.append(port_obj.pci)
        trex_handler = TrexHandler(trex_host=TREX_HOST, trex_daemon_port=cache.get(task.name))
        sync_port, async_port = json.loads(cache.get(task.name + '_zmq_port'))
        stl_client = STLClient(server=TREX_HOST, sync_port=sync_port, async_port=async_port)
        # 将trex发送流量时的客户端存储到全局字典中，便于捕获流量使用, 目前没有使用
        TrexClientRecord.clients[task_uuid] = stl_client
        try:
            # 连接trex客户端
            stl_client.connect()
            # 将端口全部重置，排除影响
            stl_client.reset()
            stl_client.acquire()
            # 将端口管理表中的port状态更改为占用
            ports_list = PortHandler.get_ports_by_pci(port_pci_list)
            for port in ports_list:
                port.update({'status': PortStatus.acquire, 'task_uuid': task_uuid})

            client_base_pkt = Ether(dst=task.dst_mac, src=task.source_mac) / IP(dst=task.dst_ip,
                                                                                src=task.source_ip) / UDP(
                sport=task.source_port,
                dport=task.dst_port)
            server_base_pkt = Ether(dst=task.source_mac, src=task.dst_mac) / IP(dst=task.source_ip,
                                                                                src=task.dst_ip) / UDP(
                sport=task.dst_port,
                dport=task.source_port)
            # 更改任务结果数据库状态
            task_info.info('开始发送流量')
            info_log.info('开始发送流量')
            status_detail_list.append('开始发送流量')
            task_result.update({'status_detail': status_detail_list})

            # 测试吞吐量
            if task.type == RFCType.throughput:
                test_throughput(stl_client, task, client_base_pkt, server_base_pkt)
            # 测试丢包率
            elif task.type == RFCType.frame_loss_rate:
                test_frame_loss_rate(stl_client, task, client_base_pkt, server_base_pkt)
            # 测试时延
            elif task.type == RFCType.latecy:
                test_latecy(stl_client, task, client_base_pkt, server_base_pkt)
            # 测试背靠背
            else:
                test_back_to_back_frame(stl_client, task, client_base_pkt, server_base_pkt)

            # 将多次测试的结果的平均值求出来，更新到任务表中
            average_result_list = []
            for y in task.frame_length.get('defined'):
                _dict = {}
                _dict[y] = sum([RFCTaskResultHandler.get_latest_by_task_uuid(task_uuid, x, y).result for x in
                                range(1, task.rounds + 1)]) / task.rounds
                average_result_list.append(_dict)
            task_info.info('此处是平均结果：{}'.format(average_result_list))
            info_log.info('此处是平均结果：{}'.format(average_result_list))
            task.update({'result': average_result_list})
            task_result.update({'result': 1, 'result_detail': '流量发送成功'})
            stl_client.stop()
            stl_client.release()
            for port in ports_list:
                port.update({'status': PortStatus.release, 'task_uuid': ''})
            status_detail_list.append('流量发送成功，端口已经释放，准备停止trex服务器')
            task_result.update({'status': TaskResultStatus.stopping, 'status_detail': status_detail_list})
            task_info.info('开始停止trex服务')
            info_log.info('开始停止trex服务')
            trex_handler.stop()
            task_info.info('开始停止trex守护进程服务')
            info_log.info('开始停止trex守护进程服务')
            TrexDaemonHandler.stop_daemon_server(task.name, task.type)

            status_detail_list.append('trex服务器已停止')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            task_info.info('测试流量发送成功,相关服务已停止')
            info_log.info('测试流量发送成功,相关服务已停止')
        except (STLError, DataException) as e:
            task_error.error('RFC2544任务{}发送流量失败: {}'.format(task.name, e))
            error_log.error('RFC2544任务{}发送流量失败: {}'.format(task.name, e))
            status_detail_list.append('测试流量发送失败')
            task_result.update({'status': TaskResultStatus.stopped, 'status_detail': status_detail_list,
                                'end_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            # 将端口状态释放
            for port in ports_list:
                port.update({'status': PortStatus.release, 'task_uuid': ''})
            task_info.info('测试流量发送失败,相关服务已停止')
            info_log.info('测试流量发送失败,相关服务已停止')
        finally:
            # 最后将链接断开
            stl_client.disconnect()
            TrexClientRecord.clients.pop(task_uuid, None)
            ThreadingRecord.threads.pop(task.uuid, None)


def test_throughput(stl_client, task, client_base_pkt, server_base_pkt):
    """
    测试吞吐量
    :param stl_client: 无状态客户端
    :param task: 任务对象
    :param client_base_pkt: 构建的客户端的基础的包对象
    :param server_base_pkt: 构建的服务端的基础的包对象
    :return:
    """
    frame_length_list = task.frame_length.get('defined')
    base_pkt_size = len(client_base_pkt)
    rate_init = task.payload_mode.get('rate_init')  # 初始速度pps
    rate_init_percent = task.payload_mode.get('rate_init_percent')  # 初始速度百分比
    resolution = task.payload_mode.get('resolution')  # 精度百分比
    rate_lower = task.payload_mode.get('rate_lower')  # 最低的百分比
    init_max_rate = (rate_init / rate_init_percent) * 100  # 用户输入的限制的最大速率
    init_min_rate = (init_max_rate * rate_lower) / 100  # 用户输入的限制的最小速率
    round = 1  # 初始轮数，默认第一轮
    while round <= task.rounds:
        for size in frame_length_list:
            task_info.info('开始进行{}帧长的测试'.format(size))
            info_log.info('开始进行{}帧长的测试'.format(size))
            payload = get_Random_String(size - base_pkt_size)
            # 目前采用双向各一条流的方式进行测试
            client_pkt = STLPktBuilder(client_base_pkt / Raw(load=payload))
            server_pkt = STLPktBuilder(server_base_pkt / Raw(load=payload))
            while True:
                # 计算循环这一次的速度应该是多少
                current_rate, max_rate, min_rate = calculate_traffic_rate(task, round, size)
                task_info.info(f'当前速度：{current_rate}，最大速度：{max_rate}，最小速度：{min_rate}')
                info_log.info(f'当前速度：{current_rate}，最大速度：{max_rate}，最小速度：{min_rate}')
                if (max_rate - min_rate) <= (resolution / 100 * init_max_rate):
                    # 证明达到了最大吞吐量的精度，跳出循环
                    break
                elif current_rate > init_max_rate:
                    # 证明当前速度已经超过最大速度限制了，跳出循环
                    break
                elif current_rate < init_min_rate:
                    # 证明当前速度已经超过最小速度限制了，跳出循环
                    break
                else:
                    # 否则都是正常条件，正常循环
                    task_info.info(f'帧长{size}，轮次{round}的测试速度为{current_rate}')
                    info_log.info(f'帧长{size}，轮次{round}的测试速度为{current_rate}')
                    client_stream = STLStream(packet=client_pkt, mode=STLTXCont(pps=current_rate),
                                              flow_stats=STLFlowStats(pg_id=1))
                    server_stream = STLStream(packet=server_pkt, mode=STLTXCont(pps=current_rate),
                                              flow_stats=STLFlowStats(pg_id=2))
                    stl_client.add_streams(client_stream, ports=[0])
                    stl_client.add_streams(server_stream, ports=[1])
                    stl_client.start(ports=[0, 1], duration=int(task.duration))  # 双向互发
                    stl_client.set_service_mode(ports=[0, 1])
                    stl_client.wait_on_traffic()
                    # 获取流量的统计数据
                    statistic_data = stl_client.get_stats()
                    client = statistic_data.get(0)
                    send_packets = client.get('opackets')
                    _recive_packet = client.get('ipackets')
                    task_info.info('0口发的数据包个数：{}'.format(send_packets))  # 发出多少包
                    task_info.info('0口收的数据包个数：{}'.format(_recive_packet))  # 收到多少包
                    server = statistic_data.get(1)
                    recive_packets = server.get('ipackets')
                    _send_packet = server.get('opackets')
                    task_info.info('1口收到的数据包个数：{}'.format(recive_packets))  # 收到多少包
                    task_info.info('1口发送的数据包个数：{}'.format(_send_packet))  # 发出多少包
                    # 使用service模式获取完数量之后，需要解除service模式
                    stl_client.set_service_mode(ports=[0, 1], enabled=False)
                    # 判断是否丢包，如果没有丢包的话，提高通过二分法计算的速度，同时设置最小速度为当前速度
                    if (send_packets + _send_packet) == (recive_packets + _recive_packet):
                        _min_rate = current_rate
                        _max_rate = max_rate
                    elif (send_packets + _send_packet) > (recive_packets + _recive_packet):
                        _max_rate = current_rate
                        _min_rate = min_rate
                    else:
                        # 如果发送的包数量小于接受的包数量，证明出现问题
                        task_error.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        error_log.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        _min_rate = current_rate
                        _max_rate = max_rate

                    # 查询一下最后一次的结果的发送和接收的包的个数，用本次总的减去上次记录中的，就是本次发送的
                    task_result = RFCTaskResultHandler.get_latest_by_task_uuid(task.uuid, round, size)
                    # 存入rfc_result表
                    rfc_result_data = {
                        "rfc_task_uuid": task.uuid,
                        "round": round,
                        "frame_length": size,
                        "result": float('%.2f' % ((_max_rate + _min_rate) / 2)),
                        "max_rate": float('%.2f' % _max_rate),
                        "min_rate": float('%.2f' % _min_rate),
                        "transmit_packets": (send_packets + _send_packet) if not task_result else (
                                                                                                          send_packets + _send_packet) - task_result.transmit_packets,
                        "receive_packets": (recive_packets + _recive_packet) if not task_result else (
                                                                                                             recive_packets + _recive_packet) - task_result.receive_packets
                    }
                    try:
                        RFCTaskResultHandler.create_obj(rfc_result_data, '_rfcResult')
                    except Exception as e:
                        task_error.error('保存rfc入库结果报错: {}'.format(e))
                        error_log.error('保存rfc入库结果报错: {}'.format(e))
                        raise DataException('保存rfc入库结果失败')

        round += 1
    return True


def test_frame_loss_rate(stl_client, task, client_base_pkt, server_base_pkt):
    """
    测试帧丢失率
    :param stl_client: 无状态客户端
    :param task: 任务对象
    :param client_base_pkt: 构建的客户端的基础的包对象
    :param server_base_pkt: 构建的服务端的基础的包对象
    :return:
    """
    frame_length_list = task.frame_length.get('defined')
    base_pkt_size = len(client_base_pkt)
    rate_init = task.payload_mode.get('rate_init')  # 初始速度pps
    rate_init_percent = task.payload_mode.get('rate_init_percent')  # 初始速度百分比
    resolution = task.payload_mode.get('resolution')  # 精度百分比
    rate_lower = task.payload_mode.get('rate_lower')  # 最低的百分比
    init_max_rate = (rate_init / rate_init_percent) * 100  # 用户输入的限制的最大速率
    init_min_rate = (init_max_rate * rate_lower) / 100  # 用户输入的限制的最小速率
    round = 1  # 初始轮数，默认第一轮
    while round <= task.rounds:
        for size in frame_length_list:
            task_info.info('开始进行{}帧长的测试'.format(size))
            info_log.info('开始进行{}帧长的测试'.format(size))
            payload = get_Random_String(size - base_pkt_size)
            # 目前采用双向各一条流的方式进行测试
            client_pkt = STLPktBuilder(client_base_pkt / Raw(load=payload))
            server_pkt = STLPktBuilder(server_base_pkt / Raw(load=payload))
            while True:
                # 计算循环这一次的速度应该是多少
                current_rate, _result = calculate_traffic_rate_by_step(task, round, size)
                task_info.info(f'当前测试速度：{current_rate}')
                info_log.info(f'当前测试速度：{current_rate}')

                if current_rate < init_min_rate or _result > (resolution / 100):
                    # 证明当前速度已经超过最小速度限制了或者丢包率超过限制精度了，跳出循环
                    break
                else:
                    # 否则都是正常条件，正常循环
                    task_info.info(f'帧长{size}，轮次{round}的测试速度为{current_rate}')
                    info_log.info(f'帧长{size}，轮次{round}的测试速度为{current_rate}')
                    client_stream = STLStream(packet=client_pkt, mode=STLTXCont(pps=current_rate),
                                              flow_stats=STLFlowStats(pg_id=1))
                    server_stream = STLStream(packet=server_pkt, mode=STLTXCont(pps=current_rate),
                                              flow_stats=STLFlowStats(pg_id=2))
                    stl_client.add_streams(client_stream, ports=[0])
                    stl_client.add_streams(server_stream, ports=[1])
                    stl_client.start(ports=[0, 1], duration=int(task.duration))  # 双向互发
                    stl_client.set_service_mode(ports=[0, 1])
                    stl_client.wait_on_traffic()
                    # 获取流量的统计数据
                    statistic_data = stl_client.get_stats()
                    client = statistic_data.get(0)
                    send_packets = client.get('opackets')
                    _recive_packet = client.get('ipackets')
                    task_info.info('0口发的数据包个数：{}'.format(send_packets))  # 发出多少包
                    task_info.info('0口收的数据包个数：{}'.format(_recive_packet))  # 收到多少包
                    server = statistic_data.get(1)
                    recive_packets = server.get('ipackets')
                    _send_packet = server.get('opackets')
                    task_info.info('1口收到的数据包个数：{}'.format(recive_packets))  # 收到多少包
                    task_info.info('1口发送的数据包个数：{}'.format(_send_packet))  # 发出多少包
                    # 使用service模式获取完数量之后，需要解除service模式
                    stl_client.set_service_mode(ports=[0, 1], enabled=False)
                    # 计算丢包率，同时设置最大速度为当前速度
                    if (send_packets + _send_packet) < (recive_packets + _recive_packet):
                        task_error.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        error_log.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        frame_loss_rate = 0
                    else:
                        frame_loss_rate = ((send_packets + _send_packet) - (recive_packets + _recive_packet)) / (
                                send_packets + _send_packet)

                    # 查询一下最后一次的结果的发送和接收的包的个数，用本次总的减去上次记录中的，就是本次发送的
                    task_result = RFCTaskResultHandler.get_latest_by_task_uuid(task.uuid, round, size)
                    # 存入rfc_result表
                    rfc_result_data = {
                        "rfc_task_uuid": task.uuid,
                        "round": round,
                        "frame_length": size,
                        "result": float('%.2f' % frame_loss_rate),
                        "max_rate": float('%.2f' % current_rate),
                        "transmit_packets": (send_packets + _send_packet) if not task_result else (
                                                                                                          send_packets + _send_packet) - task_result.transmit_packets,
                        "receive_packets": (recive_packets + _recive_packet) if not task_result else (
                                                                                                             recive_packets + _recive_packet) - task_result.receive_packets
                    }
                    try:
                        RFCTaskResultHandler.create_obj(rfc_result_data, '_rfcResult')
                        if current_rate == init_max_rate and frame_loss_rate < (resolution / 100):
                            # 证明最大速度都没有丢包，跳出循环
                            break
                    except Exception as e:
                        task_error.error('保存rfc入库结果报错: {}'.format(e))
                        error_log.error('保存rfc入库结果报错: {}'.format(e))
                        raise DataException('保存rfc入库结果失败')

        round += 1
    return True


def test_latecy(stl_client, task, client_base_pkt, server_base_pkt):
    """
    测试时延
    :param stl_client: 无状态客户端
    :param task: 任务对象
    :param client_base_pkt: 构建的客户端的基础的包对象
    :param server_base_pkt: 构建的服务端的基础的包对象
    :return:
    """
    frame_length_list = task.frame_length.get('defined')
    base_pkt_size = len(client_base_pkt)
    rate_init = task.payload_mode.get('rate_init')  # 初始速度pps
    round = 1  # 初始轮数，默认第一轮
    client_pg = 1
    server_pg = 2
    while round <= task.rounds:
        for size in frame_length_list:
            task_info.info('开始进行{}帧长的测试, 其中的pg_id为：{}、{}'.format(size, client_pg, server_pg))
            info_log.info('开始进行{}帧长的测试, 其中的pg_id为：{}、{}'.format(size, client_pg, server_pg))
            payload = get_Random_String(size - base_pkt_size)
            # 目前采用双向各一条流的方式进行测试
            client_pkt = STLPktBuilder(client_base_pkt / Raw(load=payload))
            server_pkt = STLPktBuilder(server_base_pkt / Raw(load=payload))
            task_info.info(f'当前测试速度：{rate_init}')
            info_log.info(f'当前测试速度：{rate_init}')
            task_info.info(f'帧长{size}，轮次{round}的测试速度为{rate_init}')
            info_log.info(f'帧长{size}，轮次{round}的测试速度为{rate_init}')
            client_stream = STLStream(packet=client_pkt, mode=STLTXCont(pps=rate_init),
                                      flow_stats=STLFlowLatencyStats(pg_id=client_pg))
            server_stream = STLStream(packet=server_pkt, mode=STLTXCont(pps=rate_init),
                                      flow_stats=STLFlowLatencyStats(pg_id=server_pg))
            stl_client.add_streams(client_stream, ports=[0])
            stl_client.add_streams(server_stream, ports=[1])
            stl_client.start(ports=[0, 1], duration=int(task.duration))  # 双向互发
            stl_client.set_service_mode(ports=[0, 1])
            stl_client.wait_on_traffic()
            # 使用service模式获取完数量之后，需要解除service模式
            stl_client.set_service_mode(ports=[0, 1], enabled=False)
            pgid_stats = stl_client.get_pgid_stats([client_pg, server_pg])
            client_average_latency = pgid_stats.get('latency').get(client_pg).get('latency')['average']  # 单位是微秒
            server_average_latency = pgid_stats.get('latency').get(server_pg).get('latency')['average']  # 单位是微秒
            task_info.info('客户端的平均时延为:{}, 服务端的平均时延为:{}'.format(client_average_latency, server_average_latency))
            info_log.info('客户端的平均时延为:{}, 服务端的平均时延为:{}'.format(client_average_latency, server_average_latency))

            # 存入rfc_result表
            rfc_result_data = {
                "rfc_task_uuid": task.uuid,
                "round": round,
                "frame_length": size,
                "result": float('%.2f' % (float(client_average_latency + server_average_latency) / 2)),
            }
            try:
                RFCTaskResultHandler.create_obj(rfc_result_data, '_rfcResult')
            except Exception as e:
                task_error.error('保存rfc入库结果报错: {}'.format(e))
                error_log.error('保存rfc入库结果报错: {}'.format(e))
                raise DataException('保存rfc入库结果失败')

            client_pg += 2
            server_pg += 2

        round += 1

    return True


def test_back_to_back_frame(stl_client, task, client_base_pkt, server_base_pkt):
    """
    测试背靠背帧
    :param stl_client: 无状态客户端
    :param task: 任务对象
    :param client_base_pkt: 构建的客户端的基础的包对象
    :param server_base_pkt: 构建的服务端的基础的包对象
    :return:
    """
    frame_length_list = task.frame_length.get('defined')
    base_pkt_size = len(client_base_pkt)
    rate_init = task.payload_mode.get('rate_init')  # 初始速度pps
    resolution = task.payload_mode.get('resolution')  # 精度，包的个数
    init_min_time = task.payload_mode.get('min_time')  # 最小发送流量的时间
    init_max_time = task.payload_mode.get('max_time')  # 最大发送流量的时间
    round = 1  # 初始轮数，默认第一轮
    while round <= task.rounds:
        for size in frame_length_list:
            task_info.info('开始进行{}帧长的测试'.format(size))
            info_log.info('开始进行{}帧长的测试'.format(size))
            payload = get_Random_String(size - base_pkt_size)
            # 目前采用双向各一条流的方式进行测试
            client_pkt = STLPktBuilder(client_base_pkt / Raw(load=payload))
            server_pkt = STLPktBuilder(server_base_pkt / Raw(load=payload))
            while True:
                # 计算循环这一次的速度应该是多少
                current_time, max_time, min_time = calculate_traffic_seconds(task, round, size)
                task_info.info(f'当前时间：{current_time}，最大时间：{max_time}，最小时间：{min_time}')
                info_log.info(f'当前时间：{current_time}，最大时间：{max_time}，最小时间：{min_time}')
                if (max_time - min_time) <= resolution:
                    # 证明达到了最大的精度，跳出循环
                    break
                elif current_time > init_max_time:
                    # 证明当前时间已经超过最大时间限制了，跳出循环
                    break
                elif current_time < init_min_time:
                    # 证明当前时间已经超过最小时间限制了，跳出循环
                    break
                else:
                    # 否则都是正常条件，正常循环
                    task_info.info(f'帧长{size}，轮次{round}的测试时间为{current_time}')
                    info_log.info(f'帧长{size}，轮次{round}的测试时间为{current_time}')
                    client_stream = STLStream(packet=client_pkt, mode=STLTXCont(pps=rate_init),
                                              flow_stats=STLFlowStats(pg_id=1))
                    server_stream = STLStream(packet=server_pkt, mode=STLTXCont(pps=rate_init),
                                              flow_stats=STLFlowStats(pg_id=2))
                    stl_client.add_streams(client_stream, ports=[0])
                    stl_client.add_streams(server_stream, ports=[1])
                    stl_client.start(ports=[0, 1], duration=int(current_time))  # 双向互发
                    stl_client.set_service_mode(ports=[0, 1])
                    stl_client.wait_on_traffic()
                    # 获取流量的统计数据
                    statistic_data = stl_client.get_stats()
                    client = statistic_data.get(0)
                    send_packets = client.get('opackets')
                    _recive_packet = client.get('ipackets')
                    task_info.info('0口发的数据包个数：{}'.format(send_packets))  # 发出多少包
                    task_info.info('0口收的数据包个数：{}'.format(_recive_packet))  # 收到多少包
                    server = statistic_data.get(1)
                    recive_packets = server.get('ipackets')
                    _send_packet = server.get('opackets')
                    task_info.info('1口收到的数据包个数：{}'.format(recive_packets))  # 收到多少包
                    task_info.info('1口发送的数据包个数：{}'.format(_send_packet))  # 发出多少包
                    # 使用service模式获取完数量之后，需要解除service模式
                    stl_client.set_service_mode(ports=[0, 1], enabled=False)
                    # 判断是否丢包，如果没有丢包的话，提高通过二分法计算的速度，同时设置最小速度为当前速度
                    if (send_packets + _send_packet) == (recive_packets + _recive_packet):
                        _min_time = current_time
                        _max_time = max_time
                        _result = send_packets
                    elif (send_packets + _send_packet) > (recive_packets + _recive_packet):
                        _max_time = current_time
                        _min_time = min_time
                        _result = recive_packets
                    else:
                        # 如果发送的包数量小于接受的包数量，证明出现问题
                        task_error.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        error_log.error('发送的流量包数量小于接收的流量包数量, 按照没有丢包计算')
                        _min_time = current_time
                        _max_time = max_time
                        _result = send_packets

                    # 查询一下最后一次的结果的发送和接收的包的个数，用本次总的减去上次记录中的，就是本次发送的
                    task_result = RFCTaskResultHandler.get_latest_by_task_uuid(task.uuid, round, size)
                    # 存入rfc_result表
                    rfc_result_data = {
                        "rfc_task_uuid": task.uuid,
                        "round": round,
                        "frame_length": size,
                        "result": _result,
                        "max_rate": float('%.2f' % _max_time),
                        "min_rate": float('%.2f' % _min_time),
                        "transmit_packets": (send_packets + _send_packet) if not task_result else (
                                                                                                          send_packets + _send_packet) - task_result.transmit_packets,
                        "receive_packets": (recive_packets + _recive_packet) if not task_result else (
                                                                                                             recive_packets + _recive_packet) - task_result.receive_packets
                    }
                    try:
                        RFCTaskResultHandler.create_obj(rfc_result_data, '_rfcResult')
                    except Exception as e:
                        task_error.error('保存rfc入库结果报错: {}'.format(e))
                        error_log.error('保存rfc入库结果报错: {}'.format(e))
                        raise DataException('保存rfc入库结果失败')

        round += 1
    return True


def v2_send_stl_flow(task, task_time, server_time_from):
    """
    发送无状态模式的流量
    :param task: 流量任务
    :param task_time: 任务开始时间
    :param server_time_from: 任务调用时间
    :return:
    """
    from manage import app
    with app.app_context():
        task_id = task.get("task_id")
        resource_type = task.get("resource_type")
        if resource_type == 0:
            # 运行pcap包
            task_info.info(f"run pcap flow for: {task_id}")
            v2_running_pcap(task, task_time, server_time_from)
        else:
            # 运行攻击脚本
            task_info.info(f"run script flow for: {task_id}")
            v2_running_attack_scripts(task, task_time, server_time_from)


def v2_init_conf_file(task):
    """
    生成trex任务的配置文件
    :param task: 流量任务
    :return:
    """
    task_id = task.get("task_id")
    task_info.info(f"init_task_start_file start for {task_id}")
    file_name = config.TREX_SERVER_PRE_NAME + task_id
    trex_config_path = os.path.join(BASE_DIR, 'media/trex_configs/{}.yaml'.format(file_name))
    # 配置文件已存在，直接删除
    if os.path.exists(trex_config_path):
        os.remove(trex_config_path)

    task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
    port_name = task_port_obj.port_name
    target_ip = task_port_obj.target_ip
    index = target_ip.rfind(".")
    gateway_ip = target_ip[0:index] + ".254"

    # 解析网络结构中的数据
    network_data = {
        'version': 2,
        'prefix': file_name,
        'low_end': True
    }
    zmq_pub_port = get_available_port()
    zmq_rpc_port = get_available_port()
    network_data['zmq_pub_port'] = zmq_pub_port
    network_data['zmq_rpc_port'] = zmq_rpc_port
    network_data['port_info'] = []
    network_data['interfaces'] = []

    # local_ip = get_local_ip()
    str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
    port_ip = str(str_ip, 'utf-8').strip()
    task_info.info(f"{port_name}===========port_ip：{port_ip}")

    count = 0
    while not port_ip:
        if count > 60:
            break
        time.sleep(2)
        str_ip = exec_cmd(f"sudo ifconfig {port_name}|grep netmask|tr -s ' ' |cut -d' ' -f3")
        port_ip = str(str_ip, 'utf-8').strip()
        task_info.info(f"{port_name}===========port_ip_again：{port_ip}")

    if not port_ip:
        raise ServiceException(code=sc.SystemError, message=f'get port ip failed for {port_name}')

    network_data['interfaces'].append(port_name)
    network_data['interfaces'].append('dummy')
    network_data['port_info'].append({
        'ip': port_ip,
        'default_gw': gateway_ip,
        'dest_mac': "FF:FF:FF:FF:FF:FF"
    })
    network_data['port_limit'] = 2
    task_info.info(f"init task conf file result: {network_data}")

    # 将组合的数据序列化到yaml文件中
    with open(trex_config_path, 'w+') as f:
        yaml.dump([network_data], f, default_flow_style=False)
    task_info.info(f"init_task_start_file end for {task_id}")


def v2_running_pcap(task, task_time, server_time_from):
    """
    运行pcap包
    :param task: 流量任务
    :param task_time: 任务执行开始时间
    :param server_time_from: 任务调用时间
    :return:
    """
    from manage import app
    with app.app_context():
        task_id = task.get("task_id")
        task_info.info(f'prepare to send pcap flow: {task_id}')
        flow_desc = ""
        try:
            # 生成trex配置文件
            v2_init_conf_file(task)

            flow_id = task.get("flow_id")
            kill_processes("trex_" + task_id)
            flow_obj = PcapHandler.get_obj_by_uuid(flow_id)
            file_name = flow_obj.file_path
            flow_desc = flow_obj.description
            task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
            pcap_file = os.path.join(config.PCAP_PATH, file_name)
            new_pcap_file = os.path.join(config.PCAP_PATH, task_id + "_" + file_name)
            mac = task_port_obj.mac
            target_ip = task_port_obj.target_ip
        except Exception as e:
            task_info.error(f"init conf file error for :{e}")
            TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                "init config failed")
            return

        # 启动服务端
        try:
            # 根据任务生成的trex启动配置文件启动trex
            trex_config_path = os.path.join(BASE_DIR,
                                            'media/trex_configs/{}.yaml'.format(config.TREX_SERVER_PRE_NAME + task_id))
            daemon_server_status = TrexDaemonHandler.start_task_daemon_server(task_id)
            daemon_port = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)

            task_info.info(f"v2 init stl server trex_daemon_port：{daemon_server_status}")
            if not daemon_server_status or not daemon_port:
                task_info.error("v2 init stl server trex daemon failed")
                return

            try:
                while not get_redis_client().acquire_lock(config.TREX_SERVER_IS_STARTING, task_id):
                    task_info.info(f'{get_redis_client().get(config.TREX_SERVER_IS_STARTING)}: single start server is starting, please wait...')
                    time.sleep(1)
                trex_handler = TrexHandler(trex_host=TREX_HOST,
                                           trex_daemon_port=daemon_port,
                                           trex_args="")
                task_info.info("start trex service")
                trex_handler.start_stateless_server({'cfg': trex_config_path})
            except Exception as e1:
                task_info.error(f"start_stateless_server error: {e1}")
                raise SystemError("start stateless server error")
            finally:
                get_redis_client().release_lock(config.TREX_SERVER_IS_STARTING)
        except Exception as e:
            task_info.error(f'start stateless trex service failed: {e}')
            try:
                # 关闭守护进程
                TrexDaemonHandler.stop_task_daemon_server(task_id)
                # 关闭服务端
                trex_handler.stop()
            except Exception as e2:
                task_info.error(f'stop stateless trex service failed: {e2}')

            TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                "start stateless trex service failed")
            return

        # 启动客户端
        ports = [0]
        load_lists = []
        status_thread = None
        try:
            # 从配置文件中加载端口配置
            with open(trex_config_path, 'r', encoding='utf-8') as yaml_file:
                trex_config = yaml.load(yaml_file, Loader=yaml.SafeLoader)
                task_info.info(f"read trex config info for pcap: {trex_config[0]}")
                sync_port = trex_config[0].get('zmq_rpc_port')
                async_port = trex_config[0].get('zmq_pub_port')

            stl_client = STLClient(server='127.0.0.1', sync_port=sync_port, async_port=async_port)
            # 连接trex客户端
            stl_client.connect()
            # 将端口全部重置，排除影响
            stl_client.reset(ports=ports)
            stl_client.acquire(ports=ports)

            local_ip = get_local_ip()
            isg = 0
            ipg = None
            common_conf = task.get("common_conf")
            if common_conf:
                latency = common_conf.get("latency") if common_conf.get("latency") else 0
                jitter = common_conf.get("jitter") if common_conf.get("jitter") else 0
                isg = (latency - random.randint(0, jitter)) * 1000
                if isg < 0:
                    isg = 0
                ipg = common_conf.get("ipg") if common_conf.get("ipg") else 0
                ipg = (ipg - random.randint(0, jitter)) * 1000
                if ipg <= 0:
                    ipg = None
            keep_running = task.get("keep_running")  # 持续运行：0 否，1 是

            duration = None
            if 0 == keep_running and common_conf:
                duration = common_conf.get("duration")

            replay = task.get("replay")  # 是否流量重放：0 否，1 是
            if replay == 0:
                flags = ""

                flow_conf = task.get("flow_conf")
                tcp_conf = flow_conf.get("tcp_conf")
                mss = tcp_conf.get("mss")
                ack = tcp_conf.get("ack")
                ugr = tcp_conf.get("ugr")
                psh = tcp_conf.get("psh")
                rst = tcp_conf.get("rst")
                syn = tcp_conf.get("syn")
                fin = tcp_conf.get("fin")
                sport = tcp_conf.get("sport")
                dport = tcp_conf.get("dport")

                if 1 == ugr:
                    flags = "U"
                if 1 == psh:
                    flags = flags + "P"
                if 1 == rst:
                    flags = flags + "R"
                if 1 == syn:
                    flags = flags + "S"
                if 1 == fin:
                    flags = flags + "F"
                if 1 == ack:
                    flags = flags + "A"

                ipv4_conf = flow_conf.get("ipv4_conf")
                if ipv4_conf.get("sip"):
                    local_ip = ipv4_conf.get("sip")
                if ipv4_conf.get("dip"):
                    target_ip = ipv4_conf.get("dip")
                ttl = ipv4_conf.get("ttl")
                tos = ipv4_conf.get("tos")
                src = {"start": local_ip, "end": local_ip}
                dst = {"start": target_ip, "end": target_ip}
                vm = create_vm(src, dst)

                # 修改pcap包配置
                packets = rdpcap(pcap_file)
                # 遍历每个数据包并修改它的TCP头字段
                for packet in packets:
                    # 检查是否为TCP数据包
                    if TCP in packet:
                        # 修改TCP头字段
                        if flags:
                            packet[TCP].flags = flags  # flags标志
                        if mss:
                            packet[TCP].options = [('MSS', mss)]  # 设置MSS选项
                        if sport:
                            packet[TCP].sport = sport
                        if dport:
                            packet[TCP].dport = dport
                        packet[TCP].checksum = None
                    if IP in packet:
                        if ttl:
                            packet[IP].ttl = ttl
                        if tos:
                            packet[IP].tos = tos
                        # packet[IP].tos |= int('111000', 2)  #set dscp
                        packet[IP].checksum = None
                wrpcap(new_pcap_file, packets)

                mult = "1"
                rate_unlimited = task.get("rate_unlimited")  # 速率无限制：0 否，1 是
                if 0 == rate_unlimited:
                    rate_conf = task.get("rate_conf")
                    load_mode = rate_conf.get("load_mode")  # 发生模式：0 均匀分布、1 随机分布、2 二项分布、3 指数分布、4 高斯分布
                    rate_min = rate_conf.get("rate_min")  # 最小速率(单位Mb/s)
                    rate_max = rate_conf.get("rate_max")  # 最大速率(单位Mb/s)
                    if rate_max:
                        mult = str(rate_max) + "mbps"
                    elif rate_min:
                        mult = str(rate_min) + "mbps"
                    if load_mode == 1:
                        load_lists = rand(rate_min, rate_max)
                    elif load_mode == 2:
                        load_lists = binomial(rate_min, rate_max)
                    elif load_mode == 3:
                        load_lists = exponential(rate_min, rate_max)
                    elif load_mode == 4:
                        load_lists = gaussian(rate_min, rate_max)

                total_pkt_num = 20000
                pkts = PCAPReader(new_pcap_file).read_all(None, None, 1)
                for n, (cap, ts) in enumerate(pkts, start=0):
                    if n <= total_pkt_num:
                        try:
                            s = STLStream(packet=STLPktBuilder(pkt_buffer=cap, vm=vm),
                                          mode=STLTXCont(),
                                          isg=isg  # 延迟发送，单位：微秒
                                          )
                            stl_client.add_streams(s, ports)
                        except Exception as e1:
                            # task_info.warn(f"gen STLStream error: {e1}")
                            pass

                # 任务状态改为运行中
                task_info.info('=== start to send flow ===')
                TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)
                if duration:
                    stl_client.start(mult=mult, duration=duration, force=True, ports=ports)
                else:
                    stl_client.start(mult=mult, force=True, ports=ports)
            else:
                task_info.info(f"local_ip: {local_ip}")
                cmd_line = "sudo ip a | grep -A1 " + mac + " | tail -n 1 |awk '{print $2}'| cut -d '/' -f 1"
                res = exec_cmd(cmd_line)
                str_ip = str(res, 'utf-8').strip()
                task_info.info(f"get local port ip result for pcap: {str_ip}")
                if str_ip:
                    local_ip = str_ip

                push_remote = False
                packages = rdpcap(pcap_file)
                if len(packages) > 10000:
                    push_remote = True

                if push_remote:
                    tmp_pcap = []
                    for pkt in packages:
                        try:
                            if pkt.haslayer("IP"):
                                pkt.getlayer("IP").chksum = None
                                pkt['IP'].src = local_ip
                                pkt['IP'].dst = target_ip
                            tmp_pcap.append(pkt)
                        except Exception as e:
                            print(f"read pcap error: {e}")
                            pass

                    tmp_pcap_file = os.path.join(config.PCAP_PATH, "TMP_" + task_id + "_" + file_name)
                    wrpcap(tmp_pcap_file, tmp_pcap)
                    task_info.info(f'replay to push remote for task: {task_id}')
                    stl_client.push_remote(pcap_filename=tmp_pcap_file,  # our local PCAP file
                                           ports=ports,  # use 'port'
                                           count=1,
                                           ipg_usec=ipg,
                                           force=True
                                           )
                else:
                    src = {"start": local_ip, "end": local_ip}
                    dst = {"start": target_ip, "end": target_ip}
                    vm = create_vm(src, dst)

                    if not ipg:
                        ipg = 1000
                    stl_client.push_pcap(pcap_filename=pcap_file,
                                         count=1,
                                         force=True,
                                         ipg_usec=ipg,
                                         vm=vm
                                         )
                    task_info.info(f'replay to push pcap for task: {task_id}')

                # 任务状态改为运行中
                TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)

            server_time_to = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            # 计算任务启动耗时，修正任务实际运行时间
            diff_seconds = get_time_diff_second(server_time_from, server_time_to)
            task_time = task_time + timedelta(seconds=diff_seconds)
            # 另起一个线程，轮询当前发送流量状态
            status_thread = Thread(target=get_update_status_for_pcap,
                                   args=(stl_client, ports, task_id, task_time, load_lists, flow_desc, duration))
            status_thread.start()
            ThreadingRecord.threads[config.RUNNING_STATUS_THREAD + task_id] = status_thread

            # 流量回放
            if replay == 1:
                if keep_running == 1 or duration:
                    # 持续运行
                    while True:
                        if push_remote:
                            stl_client.push_remote(pcap_filename=tmp_pcap_file,  # our local PCAP file
                                                   ports=ports,  # use 'port'
                                                   count=1,
                                                   ipg_usec=ipg,
                                                   force=True)
                        else:
                            stl_client.start(force=True)
                        stl_client.wait_on_traffic()
                else:
                    if not push_remote:
                        stl_client.start(force=True)
                    stl_client.wait_on_traffic()
            else:
                stl_client.wait_on_traffic()

            stl_client.stop()
            stl_client.release()
            stl_client.disconnect()

            TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id, "success")
            task_info.info('=== send flow success ===')
        except Exception as e:
            daemon_port_now = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
            if daemon_port == daemon_port_now:
                TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id,
                                                                    "start stateless trex service failed")
            task_info.error(f'{task_id} send flow failed：{e}')
            task_info.error(traceback.format_exc())
        finally:
            daemon_port_now = cache.get(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
            if daemon_port == daemon_port_now:
                try:
                    # 停止获取流量状态线程
                    stop_thread(status_thread)
                    ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)
                    # 关闭服务
                    trex_handler.stop()
                    # 关闭守护进程
                    TrexDaemonHandler.stop_task_daemon_server(task_id)
                except Exception as e2:
                    task_info.error(f'stateless trex service stop failed: {e2}')
                # 删除缓存的守护进程
                cache.delete(config.TREX_DAEMON_SERVER_PORT_NAME + task_id)
            else:
                kill_processes("trex_daemon_server start -p " + str(daemon_port))


def v2_running_attack_scripts(task, task_time, server_time_from):
    """
    运行攻击脚本
    :param task: 流量任务
    :param task_time: 任务执行开始时间
    :param server_time_from: 任务调用时间
    :return:
    """
    from manage import app
    with app.app_context():
        task_id = task.get("task_id")
        flow_id = task.get("flow_id")
        attack_confs = task.get("attack_confs")

        task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
        port_name = task_port_obj.port_name
        target_ip = task_port_obj.target_ip
        flow_obj = PcapHandler.get_obj_by_uuid(flow_id)
        file_name = flow_obj.file_path
        suffix = file_name.split('.')[-1]

        server_time_to = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # 计算任务启动耗时，修正任务实际运行时间
        diff_seconds = get_time_diff_second(server_time_from, server_time_to)
        task_time = task_time + timedelta(seconds=diff_seconds)
        # 起线程获取网口流量状态
        get_port_status_th = Thread(target=get_port_status_for_script, args=(port_name, task_id, task_time))
        get_port_status_th.start()
        ThreadingRecord.threads[config.RUNNING_STATUS_THREAD + task_id] = get_port_status_th

        try:
            # 任务状态更新为运行中
            TaskPortManagerHandler.update_status_by_task_id(TaskPortStatus.running, task_id)
            run_cmd = ""
            attack_flow_path = os.path.join(BASE_DIR, 'media/run_images_scripts/{}'.format(file_name))
            new_file_name = task_id + "_" + file_name
            new_attack_flow_path = os.path.join(BASE_DIR, 'media/run_images_scripts/{}'.format(new_file_name))

            # 更新配置
            # 打开文件
            with open(attack_flow_path, 'r') as f:
                # 读取文件内容
                file_content = f.read()
                new_file_content = file_content

            if attack_confs:
                for attack_conf in attack_confs:
                    if str(attack_conf.get('conf_key')) == 'ip':
                        new_file_content = new_file_content.replace("$ip", target_ip)
                    else:
                        # 替换字符串
                        new_file_content = new_file_content.replace("$" + str(attack_conf.get('conf_key')),
                                                                    str(attack_conf.get("conf_value")))
            # 保存文件
            with open(new_attack_flow_path, 'w') as f:
                f.write(new_file_content)

            if suffix == "sh":
                run_cmd = "bash " + new_file_name
            else:
                run_cmd = "python " + new_file_name

            task_info.info(f"======script run_cmd: {run_cmd}")
            exec_cmd_with_path(run_cmd, "/opt/project_dirs/traffic_generators/media/run_images_scripts")
        except Exception as e:
            err_msg = e.args[0][e.args[0].find("Exception: "):]
            if not "Exception" in err_msg:
                err_msg = e
            # 更新任务异常状态和信息
            TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.error, task_id, err_msg)
            task_info.error('[{}] script run failed for: {}'.format(run_cmd, err_msg))
            return False
        finally:
            stop_thread(get_port_status_th)
            ThreadingRecord.threads.pop(config.RUNNING_STATUS_THREAD + task_id, None)

        TaskPortManagerHandler.update_status_msg_by_task_id(TaskPortStatus.stopped, task_id, "success")
        task_info.info('run script command success')
        return True


def get_port_status_for_script(port_name, task_uuid, task_time):
    """
    获取网口流量状态信息
    :param port_name: 网口名称
    :param task_uuid: 任务id
    :param task_time: 任务时间
    :return:
    """
    from manage import app
    with app.app_context():
        i = 1
        now = None
        offset = timedelta(seconds=1)
        # 当前执行次数
        group_count = TaskAttackFlowRecordsHandler.get_max_group_count_by_task_uuid(task_uuid) + 1
        pre_packets_sent = -1
        pre_bytes_sent = -1
        pre_bytes_recv = -1
        pre_errout = -1
        tx_pps = 0
        try:
            while True:
                if i % 5 == 0:
                    task_results = TaskPortManagerHandler.get_by_task_id(task_uuid)
                    if task_results:
                        if task_results.status == TaskResultStatus.stopped:
                            task_info.info(f"{task_uuid} task is stopped, cancel get port flow status")
                            break

                port_flow_status = psutil.net_io_counters(pernic=True)
                port_flow = port_flow_status.get(port_name)
                # task_info.info(f"========port_flow: {port_flow}")
                packets_sent = round(port_flow.packets_sent)
                bytes_sent = round(port_flow.bytes_sent)
                errout = round(port_flow.errout)
                bytes_recv = round(port_flow.bytes_recv)
                dropin = port_flow.dropin
                task_info.info(f"[{task_uuid}] script packets_sent: {packets_sent}")

                if pre_packets_sent == -1:
                    pre_packets_sent = packets_sent
                    pre_bytes_sent = bytes_sent
                    pre_bytes_recv = bytes_recv
                    pre_errout = errout
                else:
                    if packets_sent != pre_packets_sent:
                        if not now:
                            now = datetime.now()
                        opackets = packets_sent - pre_packets_sent
                        obytes = bytes_sent - pre_bytes_sent
                        oerrors = errout - pre_errout
                        # 计算平均发包速率
                        tx_bps = round(obytes / i, 2)
                        rbytes = bytes_recv - pre_bytes_recv
                        total_rx = round(rbytes / i, 2)
                        # 实时发包数
                        tx_pps = opackets

                        attack_flow_record = {
                            'task_uuid': task_uuid,
                            'group_count': group_count,
                            'second': i,
                            'opackets': opackets,
                            'obytes': obytes,
                            'tx_bps': tx_bps,
                            'oerrors': oerrors,
                            'tx_pps': tx_pps,
                            'latency': 0,
                            'jitter': 0,
                            'total_tx_L2': tx_bps,
                            'total_tx_L1': tx_bps,
                            'total_rx': total_rx,
                            'queue_full': 0,
                            'drop_rate': dropin,
                            'packets_sent': packets_sent,
                            'bytes_sent': bytes_sent,
                            'errout': errout,
                            'status': 0,
                            'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                            'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                        }
                        response, errors = TaskAttackFlowRecordsSchema().load(attack_flow_record, session=db.session)
                        if errors:
                            error_log.error('create attack task flow records error：{}'.format(errors))
                            return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                        TaskFlowRecordsHandler.save(response)
                        i = i + 1
                        now = now + offset
                    time.sleep(1)
                    task_time = task_time + offset
        except Exception as e:
            task_info.error(f"get port flow status error: {e}")


def get_update_status_for_pcap(stl_client, ports, task_id, task_time, load_lists, flow_desc, duration):
    from manage import app
    with app.app_context():
        if not ports:
            ports = [0]
        i = 1
        try:
            now = datetime.now()
            offset = timedelta(seconds=1)
            # 当前执行次数
            group_count = TaskFlowRecordsHandler.get_max_group_count_by_task_uuid(task_id) + 1
            task_port_obj = TaskPortManagerHandler.get_by_task_id(task_id)
            port_name = task_port_obj.port_name
        except Exception as e:
            task_info.error(f"get_update_status_for_pcap for {e}")
            return

        # 带宽实际循环次数
        count = 1
        while stl_client.is_connected():
            try:
                if duration and i > duration:
                    stop_task_thread = Thread(target=stop_task, args=(task_id, ))
                    stop_task_thread.start()
                    break

                stats = stl_client.get_stats(ports)
                # task_info.info(f"stats['total']：{stats['total']}")
                task_info.info(f"{task_id} opackets：{stats['total']['opackets']}")
                opackets = round(stats['total']['opackets'])
                obytes = round(stats['total']['obytes'])
                tx_bps = round(stats['total']['tx_bps'], 2)
                oerrors = round(stats['total']['oerrors'])
                tx_pps = round(stats['total']['tx_pps'])
                total_tx_L2 = round(stats['total']['tx_bps'], 2)
                total_tx_L1 = round(stats['total']['tx_bps_L1'], 2)
                total_rx = round(stats['total']['rx_bps'], 2)
                queue_full = round(stats['global']['queue_full'])
                drop_rate = round(stats['global']['rx_drop_bps'], 2)
                latency = 0
                jitter = 0

                if stats['latency'] and len(stats['latency']) > 1:
                    latency = stats['latency'][0]['latency']['average']
                    jitter = stats['latency'][0]['latency']['jitter']

                protocol_objs = json.loads(flow_desc)
                for protocol in protocol_objs:
                    num = math.ceil(tx_pps * protocol_objs.get(protocol) / 100)
                    # task_info.info(f"task [{task_id}] {protocol}: {num}")
                    get_redis_client().zincrby_with_expire("PROTOCOLS::" + task_id, protocol, num)

                # pgid_stats = stl_client.get_pgid_stats()
                # lat_stats = stats['latency']
                # task_info.info(f"======pgid_stats: {pgid_stats}")
                # jitter_latency = stl_client.get_jitter_latency()
                # task_info.info(f"======jitter_latency: {jitter_latency}")

                # latency = stats[0]['latency']
                # jitter = stats[0]['jitter']
                # task_info.info(f"{task_id}[{i}]: stats tx_bps: {tx_bps}")

                flow_record = {
                    'task_uuid': task_id,
                    'group_count': group_count,
                    'second': i,
                    'tag_id': 1,
                    'port_name': port_name,
                    'opackets': opackets,
                    'obytes': obytes,
                    'tx_bps': tx_bps,
                    'oerrors': oerrors,
                    'tx_pps': tx_pps,
                    'latency': latency,
                    'jitter': jitter,
                    'total_tx_L2': total_tx_L2,
                    'total_tx_L1': total_tx_L1,
                    'total_rx': total_rx,
                    'queue_full': queue_full,
                    'drop_rate': drop_rate,
                    'status': 0,
                    'record_time': task_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'create_time': now.strftime('%Y-%m-%d %H:%M:%S')
                }
                response, errors = TaskFlowRecordsSchema().load(flow_record, session=db.session)
                if errors:
                    task_info.error('create task flow records error：{}'.format(errors))
                    return {'code': sc.DataSerializationFailed, 'msg': errors[list(errors)[0]][0]}
                TaskFlowRecordsHandler.save(response)
            except Exception as e:
                task_info.error(f"stl_client get_stats error: {e}")
                break

            if load_lists and len(load_lists) > 0:
                load_size = len(load_lists)
                for load in load_lists:
                    if load.get("time") == (i - ((count - 1) * load_size)):
                        bandwidth = str(round(load.get("bandwidth"))) + "mbps"
                        task_info.debug(f"update bandwidth for {task_id} --> time:{i}, bandwidth:{bandwidth}")
                        # 动态更新带宽
                        stl_client.update(ports, mult=bandwidth)

                # 循环次数加1
                if (i % load_size) == 0:
                    count = count + 1

            time.sleep(1)
            i = i + 1
            task_time = task_time + offset
            now = now + offset
